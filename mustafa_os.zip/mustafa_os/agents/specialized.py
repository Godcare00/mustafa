"""
MUSTAFA OS - Specialized Agents
Planner, Research, Developer, Testing, and Critic agents.
"""

from __future__ import annotations

import json
from typing import Any, Dict, List, Optional

from agents.base import AgentResult, BaseAgent, TaskContext
from core.logging_config import get_logger

logger = get_logger("agents")


# ─── Planner Agent ────────────────────────────────────────────────────────────

class PlannerAgent(BaseAgent):
    """
    Decomposes complex goals into structured, executable step-by-step plans.
    Identifies dependencies, estimates durations, and maps tasks to agents.
    """

    def __init__(self) -> None:
        super().__init__(
            agent_id="planner",
            name="Planner Agent",
            capabilities=["task_planning", "dependency_analysis", "timeline_estimation"],
        )

    async def handle_task(self, task_type: str, context: TaskContext) -> AgentResult:
        handlers = {
            "create_plan": self._create_plan,
            "execute_step": self._execute_step,
        }
        handler = handlers.get(task_type)
        if not handler:
            return AgentResult.fail(f"Unknown task type: {task_type}")
        return await handler(context)

    async def _create_plan(self, context: TaskContext) -> AgentResult:
        """
        Generate a structured execution plan using the live agent and tool
        context injected by the Orchestrator. Never invents agent or tool names.
        """
        goal = context.goal
        self.logger.info("creating_plan", goal=goal[:100])

        # Extract live context injected by the Orchestrator
        available_agents = context.payload.get("available_agents", [])
        available_tools  = context.payload.get("available_tools", [])
        memory_context   = context.payload.get("memory_context", [])

        agent_list = "\n".join([
            f"  - {a['id']} ({a['name']}): capabilities={a['capabilities']}, available={a.get('available', True)}"
            for a in available_agents
        ]) or "  (no agent context provided — use: research, developer, testing, critic, memory_agent)"

        tool_list = "\n".join([
            f"  - {t['name']}: {t['description']}"
            for t in available_tools
        ]) or "  (no tool context provided — use: web_search, file_manager, code_executor, data_analysis)"

        memory_str = ""
        if memory_context:
            memory_str = "\nRELEVANT PAST EXPERIENCE:\n" + "\n".join([
                f"  - {m.get('content', '')[:150]}"
                for m in memory_context[:2]
            ])

        try:
            plan = await self.think_json(
                f"""You are a master planner for MUSTAFA OS. Create an execution plan for:

GOAL: {goal}
{memory_str}
AVAILABLE AGENTS (use ONLY these exact IDs — do NOT invent names):
{agent_list}

AVAILABLE TOOLS (use ONLY these exact names):
{tool_list}

Rules:
- Maximum 5 steps. Prefer fewer.
- Assign each step to the MOST CAPABLE agent from the list above.
- Only list tools that agent actually needs.
- steps with depends_on=[] can run concurrently.
- Do NOT assign steps to "orchestrator" — it dispatches, it does not execute.

Return ONLY this JSON (no markdown, no explanation):
{{
  "goal": "{goal}",
  "steps": [
    {{
      "step_id": 1,
      "description": "specific action",
      "agent": "agent_id_from_list",
      "tools": ["tool_name_from_list"],
      "depends_on": [],
      "timeout": 60
    }}
  ],
  "complexity": "low|medium|high"
}}"""
            )
            self.logger.info("plan_created", steps=len(plan.get("steps", [])))
            return AgentResult.ok(plan)
        except Exception as e:
            self.logger.error("plan_creation_failed", error=str(e))
            return AgentResult.fail(str(e))

    async def _execute_step(self, context: TaskContext) -> AgentResult:
        """Execute a delegated step."""
        goal = context.goal
        response = await self.think(f"Complete this task concisely: {goal}")
        return AgentResult.ok({"response": response})


# ─── Research Agent ───────────────────────────────────────────────────────────

class ResearchAgent(BaseAgent):
    """
    Gathers, synthesizes, and structures information from multiple sources.
    Supports web search, document analysis, and knowledge extraction.
    """

    def __init__(self) -> None:
        super().__init__(
            agent_id="research",
            name="Research Agent",
            capabilities=["web_research", "document_analysis", "summarization", "knowledge_extraction"],
            allowed_tools=["web_search", "api_request", "file_manager", "data_analysis"],
        )
        self._tool_engine = None

    async def on_start(self) -> None:
        """Initialize tool access."""
        from tools import get_tool_engine
        self._tool_engine = get_tool_engine()

    async def handle_task(self, task_type: str, context: TaskContext) -> AgentResult:
        handlers = {
            "research": self._do_research,
            "execute_step": self._do_research,
            "web_search": self._web_search,
            "summarize": self._summarize,
            "extract_knowledge": self._extract_knowledge,
        }
        handler = handlers.get(task_type)
        if not handler:
            return AgentResult.fail(f"Unknown task type: {task_type}")
        return await handler(context)

    async def _do_research(self, context: TaskContext) -> AgentResult:
        """Perform comprehensive research on a topic."""
        goal = context.goal
        self.logger.info("researching", goal=goal[:100])

        # Try web search first
        search_results = await self._perform_web_search(goal)

        # Synthesize findings
        synthesis_prompt = f"""Research Goal: {goal}

Web Search Results:
{search_results}

Please provide:
1. A comprehensive answer to the research goal
2. Key findings and facts
3. Confidence level (high/medium/low)
4. Any important caveats or limitations

Be thorough, accurate, and well-structured."""

        response = await self.think(synthesis_prompt)

        return AgentResult.ok({
            "research_goal": goal,
            "findings": response,
            "search_results": search_results,
        })

    async def _perform_web_search(self, query: str) -> str:
        """Execute a web search and return formatted results."""
        try:
            if self._tool_engine:
                result = await self._tool_engine.execute(
                    tool_name="web_search",
                    agent_id=self.agent_id,
                    params={"query": query, "max_results": 5},
                )
                if result.success:
                    results = result.data.get("results", [])
                    return "\n".join([
                        f"[{i+1}] {r.get('title', '')}\n{r.get('snippet', '')}\nURL: {r.get('url', '')}"
                        for i, r in enumerate(results)
                    ])
        except Exception as e:
            self.logger.warning("web_search_failed", error=str(e))

        return "Web search unavailable. Using knowledge from training data."

    async def _web_search(self, context: TaskContext) -> AgentResult:
        results = await self._perform_web_search(context.goal)
        return AgentResult.ok({"results": results})

    async def _summarize(self, context: TaskContext) -> AgentResult:
        content = context.payload.get("content", context.goal)
        summary = await self.think(f"Provide a concise, accurate summary:\n\n{content}")
        return AgentResult.ok({"summary": summary})

    async def _extract_knowledge(self, context: TaskContext) -> AgentResult:
        content = context.payload.get("content", context.goal)
        knowledge = await self.think_json(
            f"""Extract structured knowledge from this content:
{content}

Return JSON with:
{{
  "key_facts": ["fact1", "fact2"],
  "entities": {{"people": [], "organizations": [], "concepts": []}},
  "relationships": [],
  "summary": "brief summary"
}}"""
        )
        return AgentResult.ok(knowledge)


# ─── Developer Agent ──────────────────────────────────────────────────────────

class DeveloperAgent(BaseAgent):
    """
    Writes, modifies, and improves code with production standards.
    Supports Python code generation, module modification, and architecture proposals.
    """

    def __init__(self) -> None:
        super().__init__(
            agent_id="developer",
            name="Developer Agent",
            capabilities=["code_generation", "code_modification", "architecture", "debugging"],
            allowed_tools=["file_manager", "code_executor", "database_query"],
        )
        self._tool_engine = None

    async def on_start(self) -> None:
        from tools import get_tool_engine
        self._tool_engine = get_tool_engine()

    async def handle_task(self, task_type: str, context: TaskContext) -> AgentResult:
        handlers = {
            "write_code": self._write_code,
            "modify_code": self._modify_code,
            "execute_step": self._handle_step,
            "create_tool": self._create_tool,
            "debug": self._debug_code,
            "propose_improvement": self._propose_improvement,
        }
        handler = handlers.get(task_type)
        if not handler:
            return AgentResult.fail(f"Unknown task type: {task_type}")
        return await handler(context)

    async def _write_code(self, context: TaskContext) -> AgentResult:
        """Write production-quality Python code."""
        requirement = context.goal
        self.logger.info("writing_code", requirement=requirement[:100])

        code_spec = await self.think_json(
            f"""You are a senior Python engineer. Write production-quality code for:

REQUIREMENT: {requirement}

Requirements:
- Include type hints
- Add comprehensive docstrings
- Include error handling and logging
- Write clean, modular code
- Follow PEP 8

Return JSON:
{{
  "filename": "module_name.py",
  "code": "complete python code here",
  "description": "what this code does",
  "dependencies": ["package1", "package2"],
  "tests_needed": ["test description 1", "test description 2"]
}}"""
        )

        # Optionally save to file
        if context.payload.get("save_to_file") and self._tool_engine:
            file_path = f"./data/generated/{code_spec.get('filename', 'generated.py')}"
            await self._tool_engine.execute(
                tool_name="file_manager",
                agent_id=self.agent_id,
                params={
                    "operation": "write",
                    "path": file_path,
                    "content": code_spec.get("code", ""),
                },
            )
            code_spec["saved_to"] = file_path

        return AgentResult.ok(code_spec)

    async def _create_tool(self, context: TaskContext) -> AgentResult:
        """Create a new tool plugin for MUSTAFA OS."""
        tool_spec = context.payload.get("tool_spec", {})
        tool_name = tool_spec.get("name", "new_tool")

        code = await self.think(
            f"""Create a complete MUSTAFA OS tool plugin for:

Tool Name: {tool_name}
Description: {tool_spec.get('description', '')}
Inputs: {tool_spec.get('inputs', {})}
Outputs: {tool_spec.get('outputs', {})}

Write a complete Python class that inherits from BaseTool.
Include the execute() method, input validation, error handling, and docstrings.
Follow the exact same pattern as existing tools in tools/base.py."""
        )

        # Save to plugins directory
        if self._tool_engine:
            plugin_path = f"./plugins/{tool_name}.py"
            await self._tool_engine.execute(
                tool_name="file_manager",
                agent_id=self.agent_id,
                params={"operation": "write", "path": plugin_path, "content": code},
            )

        return AgentResult.ok({
            "tool_name": tool_name,
            "code": code,
            "plugin_path": f"./plugins/{tool_name}.py",
        })

    async def _modify_code(self, context: TaskContext) -> AgentResult:
        file_path = context.payload.get("file_path", "")
        change_request = context.goal

        # Read existing file
        existing_code = ""
        if self._tool_engine and file_path:
            result = await self._tool_engine.execute(
                tool_name="file_manager",
                agent_id=self.agent_id,
                params={"operation": "read", "path": file_path},
            )
            if result.success:
                existing_code = result.data.get("content", "")

        modified = await self.think(
            f"""Modify the following code as requested:

FILE: {file_path}
CHANGE REQUEST: {change_request}

EXISTING CODE:
{existing_code}

Provide the complete modified code. Maintain existing style and standards."""
        )

        return AgentResult.ok({"file_path": file_path, "modified_code": modified})

    async def _debug_code(self, context: TaskContext) -> AgentResult:
        code = context.payload.get("code", "")
        error = context.payload.get("error", "")

        fix = await self.think(
            f"""Debug and fix this Python code:

ERROR: {error}

CODE:
{code}

Identify the bug and provide the corrected code with explanation."""
        )

        return AgentResult.ok({"fix": fix})

    async def _propose_improvement(self, context: TaskContext) -> AgentResult:
        target = context.goal
        proposal = await self.think_json(
            f"""Propose a specific, measurable improvement for:
{target}

Return JSON:
{{
  "title": "improvement title",
  "description": "what to change and why",
  "expected_improvement_pct": 15,
  "implementation": "step by step how to implement",
  "risks": ["risk1"],
  "effort": "low|medium|high"
}}"""
        )
        return AgentResult.ok(proposal)

    async def _handle_step(self, context: TaskContext) -> AgentResult:
        """Handle a generic development step."""
        response = await self.think(
            f"""Complete this development task:
{context.goal}

Additional context: {context.payload}

Provide a complete, working solution with explanation."""
        )
        return AgentResult.ok({"response": response})


# ─── Testing Agent ────────────────────────────────────────────────────────────

class TestingAgent(BaseAgent):
    """
    Writes and executes unit tests, verifies code reliability, and generates coverage reports.
    """

    def __init__(self) -> None:
        super().__init__(
            agent_id="testing",
            name="Testing Agent",
            capabilities=["unit_testing", "code_verification", "load_testing", "coverage"],
            allowed_tools=["code_executor", "file_manager"],
        )
        self._tool_engine = None

    async def on_start(self) -> None:
        from tools import get_tool_engine
        self._tool_engine = get_tool_engine()

    async def handle_task(self, task_type: str, context: TaskContext) -> AgentResult:
        handlers = {
            "write_tests": self._write_tests,
            "run_tests": self._run_tests,
            "verify_code": self._verify_code,
            "execute_step": self._verify_code,
        }
        handler = handlers.get(task_type)
        if not handler:
            return AgentResult.fail(f"Unknown task type: {task_type}")
        return await handler(context)

    async def _write_tests(self, context: TaskContext) -> AgentResult:
        code = context.payload.get("code", "")
        function_name = context.payload.get("function_name", "")

        tests = await self.think(
            f"""Write comprehensive pytest unit tests for:

CODE TO TEST:
{code}

Requirements:
- Test happy path
- Test edge cases
- Test error conditions
- Use pytest fixtures
- Include type hints
- Aim for >80% coverage

Write complete, runnable test code."""
        )

        return AgentResult.ok({"tests": tests, "function_name": function_name})

    async def _run_tests(self, context: TaskContext) -> AgentResult:
        test_code = context.payload.get("test_code", "")

        if not self._tool_engine:
            return AgentResult.fail("Code executor not available")

        result = await self._tool_engine.execute(
            tool_name="code_executor",
            agent_id=self.agent_id,
            params={"code": test_code, "language": "python"},
        )

        return AgentResult.ok({
            "passed": result.success,
            "stdout": result.data.get("stdout", "") if result.success else "",
            "stderr": result.data.get("stderr", "") if result.success else result.error,
        })

    async def _verify_code(self, context: TaskContext) -> AgentResult:
        code = context.payload.get("code", context.goal)
        verification = await self.think_json(
            f"""Analyze this code for correctness and quality:

{code}

Return JSON:
{{
  "syntax_valid": true,
  "logic_issues": [],
  "security_concerns": [],
  "performance_issues": [],
  "quality_score": 0.85,
  "recommendations": []
}}"""
        )
        return AgentResult.ok(verification)


# ─── Critic Agent ─────────────────────────────────────────────────────────────

class CriticAgent(BaseAgent):
    """
    Evaluates agent outputs for quality, correctness, and completeness.
    Provides scored assessments and actionable feedback.
    """

    def __init__(self) -> None:
        super().__init__(
            agent_id="critic",
            name="Critic Agent",
            capabilities=["quality_evaluation", "logic_verification", "security_review", "scoring"],
        )

    async def handle_task(self, task_type: str, context: TaskContext) -> AgentResult:
        handlers = {
            "evaluate": self._evaluate,
            "score_code": self._score_code,
            "validate_plan": self._validate_plan,
            "execute_step": self._evaluate,
        }
        handler = handlers.get(task_type)
        if not handler:
            return AgentResult.fail(f"Unknown task type: {task_type}")
        return await handler(context)

    async def _evaluate(self, context: TaskContext) -> AgentResult:
        """Evaluate an agent output."""
        goal = context.payload.get("goal", context.goal)
        answer = context.payload.get("answer", "")

        evaluation = await self.think_json(
            f"""Critically evaluate this output:

ORIGINAL GOAL: {goal}

OUTPUT TO EVALUATE:
{answer}

Provide a rigorous, honest evaluation. Return JSON:
{{
  "score": 0.85,
  "correctness": 0.9,
  "completeness": 0.8,
  "clarity": 0.85,
  "safety": 1.0,
  "strengths": ["strength1", "strength2"],
  "weaknesses": ["weakness1"],
  "critical_issues": [],
  "suggestions": ["suggestion1"],
  "verdict": "accept|revise|reject"
}}"""
        )

        self.logger.info(
            "evaluation_complete",
            score=evaluation.get("score"),
            verdict=evaluation.get("verdict"),
        )

        return AgentResult.ok(evaluation)

    async def _score_code(self, context: TaskContext) -> AgentResult:
        code = context.payload.get("code", "")
        score = await self.think_json(
            f"""Score this Python code:

{code}

Return JSON:
{{
  "overall_score": 0.8,
  "readability": 0.9,
  "correctness": 0.85,
  "security": 0.9,
  "performance": 0.75,
  "test_coverage_estimate": 0.0,
  "issues": [],
  "passes_production_standards": true
}}"""
        )
        return AgentResult.ok(score)

    async def _validate_plan(self, context: TaskContext) -> AgentResult:
        plan = context.payload.get("plan", {})
        validation = await self.think_json(
            f"""Validate this execution plan:

{json.dumps(plan, indent=2)}

Return JSON:
{{
  "is_valid": true,
  "missing_dependencies": [],
  "circular_dependencies": [],
  "unreachable_steps": [],
  "agent_availability_issues": [],
  "estimated_success_probability": 0.85,
  "recommendations": []
}}"""
        )
        return AgentResult.ok(validation)


# ─── CyberSecurity Agent ──────────────────────────────────────────────────────

class CyberSecurityAgent(BaseAgent):
    """
    Specialist in cybersecurity, ethical hacking, and security analysis.

    Capabilities:
    - Vulnerability assessment and analysis
    - Network scanning and reconnaissance (ethical/authorized only)
    - Security code review and hardening recommendations
    - CTF challenge solving
    - Malware analysis (static)
    - OSINT gathering
    - Security report writing
    - Penetration testing guidance
    - CVE research and impact assessment

    All operations are conducted ethically and legally.
    The agent refuses requests targeting systems without authorization.
    """

    def __init__(self) -> None:
        super().__init__(
            agent_id="cybersecurity",
            name="CyberSecurity Agent",
            capabilities=[
                "vulnerability_assessment", "ethical_hacking", "security_analysis",
                "network_scanning", "osint", "malware_analysis", "security_review",
                "penetration_testing", "ctf", "cve_research",
            ],
            allowed_tools=[
                "shell_executor", "web_search", "file_manager",
                "api_request", "code_executor",
            ],
        )
        self._tool_engine = None

    async def on_start(self) -> None:
        from tools import get_tool_engine
        self._tool_engine = get_tool_engine()

    async def handle_task(self, task_type: str, context: TaskContext) -> AgentResult:
        handlers = {
            "security_analysis":       self._security_analysis,
            "vulnerability_scan":      self._vulnerability_scan,
            "osint":                   self._osint,
            "security_review":         self._security_review,
            "ctf":                     self._ctf_solve,
            "cve_research":            self._cve_research,
            "network_recon":           self._network_recon,
            "execute_step":            self._security_analysis,
        }
        handler = handlers.get(task_type)
        if not handler:
            return AgentResult.fail(f"Unknown task type: {task_type}")
        return await handler(context)

    async def _security_analysis(self, context: TaskContext) -> AgentResult:
        """General security analysis — routes to the most appropriate sub-handler."""
        goal = context.goal
        self.logger.info("security_analysis", goal=goal[:100])

        # Use shell tools for active tasks, LLM for advisory tasks
        shell_keywords = [
            "scan", "nmap", "enumerate", "probe", "test connectivity",
            "run", "execute", "check port", "traceroute", "ping",
            "nikto", "dirb", "gobuster", "sqlmap",
        ]
        needs_shell = any(kw in goal.lower() for kw in shell_keywords)

        if needs_shell and self._tool_engine:
            return await self._execute_security_command(context)

        # Web research for CVEs, threat intel, tool documentation
        search_keywords = ["cve", "vulnerability", "exploit", "latest", "research"]
        if any(kw in goal.lower() for kw in search_keywords):
            search_result = await self._tool_engine.execute(
                "web_search", self.agent_id,
                {"query": goal, "max_results": 5}
            ) if self._tool_engine else None

            web_context = ""
            if search_result and search_result.success:
                results = search_result.data.get("results", [])
                web_context = "\n".join([
                    f"- {r['title']}: {r['snippet']}"
                    for r in results[:5]
                ])

            analysis = await self.think(
                f"""You are an expert cybersecurity analyst and ethical hacker.

Task: {goal}

{f'Web Research Results:{chr(10)}{web_context}' if web_context else ''}

Provide a thorough, technically accurate security analysis. Include:
- Key findings and vulnerabilities
- Risk ratings (Critical/High/Medium/Low)
- Specific exploitation vectors (for educational/defensive purposes)
- Concrete remediation steps
- Relevant CVEs or references

Always emphasize ethical and legal use.""",
            )
            return AgentResult.ok({"analysis": analysis, "goal": goal})

        # Default: pure LLM advisory
        response = await self.think(
            f"""You are an expert cybersecurity specialist and ethical hacker with deep knowledge of:
- OWASP Top 10, MITRE ATT&CK, CVE database
- Network protocols and penetration testing
- Malware analysis and reverse engineering
- Secure coding practices
- Digital forensics

Task: {goal}

Provide expert, actionable guidance. Be technically precise.
For offensive techniques, always frame within ethical/authorized contexts."""
        )
        return AgentResult.ok({"response": response, "goal": goal})

    async def _execute_security_command(self, context: TaskContext) -> AgentResult:
        """Execute a security tool command via shell."""
        goal = context.goal
        payload = context.payload

        # Ask LLM to generate the appropriate command
        command_spec = await self.think_json(
            f"""You are a cybersecurity expert. Generate a safe, non-destructive shell command for:

TASK: {goal}

Rules:
- Only generate commands for reconnaissance, analysis, or testing
- No destructive commands (no rm, no overwrites of system files)
- Commands must be safe for authorized testing environments
- Prefer standard tools: nmap, curl, dig, whois, netstat, ss, openssl

Return JSON:
{{
  "command": "the shell command",
  "explanation": "what this does",
  "safe": true,
  "requires_authorization": false
}}"""
        )

        if not command_spec.get("safe", False):
            return AgentResult.fail(
                f"Command requires authorization or is potentially unsafe: "
                f"{command_spec.get('explanation', '')}"
            )

        command = command_spec.get("command", "")
        if not command:
            return AgentResult.fail("Could not generate a valid command")

        shell_result = await self._tool_engine.execute(
            "shell_executor", self.agent_id,
            {"command": command, "timeout": 30}
        )

        if shell_result.success:
            # Interpret the output
            interpretation = await self.think(
                f"""Interpret these security scan results:

Command: {command}
Output:
{shell_result.data.get('stdout', '')}
{shell_result.data.get('stderr', '')}

Provide a clear analysis of the findings, any security implications,
and recommended next steps."""
            )
            return AgentResult.ok({
                "command":        command,
                "raw_output":     shell_result.data,
                "interpretation": interpretation,
                "explanation":    command_spec.get("explanation", ""),
            })

        return AgentResult.ok({
            "command": command,
            "error":   shell_result.error,
            "note":    "Command failed — tool may not be installed or requires elevated privileges",
        })

    async def _vulnerability_scan(self, context: TaskContext) -> AgentResult:
        """Perform a vulnerability scan or assessment."""
        target = context.payload.get("target", context.goal)
        scan_type = context.payload.get("scan_type", "general")

        result = await self.think(
            f"""You are a penetration tester conducting an authorized vulnerability assessment.

Target/Subject: {target}
Scan Type: {scan_type}

Provide:
1. Methodology and approach
2. Likely attack surface and entry points
3. Common vulnerabilities to check (with CVSS scores where applicable)
4. Recommended scanning commands/tools
5. Remediation priorities

This is for authorized security testing only."""
        )
        return AgentResult.ok({"assessment": result, "target": target})

    async def _osint(self, context: TaskContext) -> AgentResult:
        """Open source intelligence gathering."""
        target = context.goal
        self.logger.info("osint_gathering", target=target[:80])

        # Search for OSINT data
        osint_data = {}
        if self._tool_engine:
            for query in [target, f"{target} security", f"{target} breach"]:
                result = await self._tool_engine.execute(
                    "web_search", self.agent_id,
                    {"query": query, "max_results": 3}
                )
                if result.success:
                    osint_data[query] = result.data.get("results", [])

        report = await self.think(
            f"""You are an OSINT specialist. Compile an intelligence report on:

Subject: {target}

Available data: {str(osint_data)[:2000]}

Provide:
1. Summary of findings
2. Exposed information and data points
3. Potential security implications
4. Recommendations for reducing exposure

Keep findings factual and relevant to security."""
        )
        return AgentResult.ok({"osint_report": report, "target": target})

    async def _security_review(self, context: TaskContext) -> AgentResult:
        """Review code or configuration for security issues."""
        code = context.payload.get("code", context.goal)
        lang = context.payload.get("language", "unknown")

        review = await self.think(
            f"""You are a senior application security engineer performing a security code review.

Language: {lang}
Code/Configuration:
{code}

Identify and report:
1. Critical vulnerabilities (injection, auth bypass, RCE, etc.)
2. High severity issues (sensitive data exposure, IDOR, etc.)
3. Medium/Low issues (missing headers, weak crypto, etc.)
4. Each finding: description, CWE/OWASP reference, impact, fix

Format as a structured security report."""
        )
        return AgentResult.ok({"security_review": review})

    async def _ctf_solve(self, context: TaskContext) -> AgentResult:
        """Help solve CTF (Capture The Flag) challenges."""
        challenge = context.goal
        category = context.payload.get("category", "general")

        solution = await self.think(
            f"""You are an expert CTF player. Solve or provide guidance for:

Challenge: {challenge}
Category: {category}

Provide:
1. Challenge analysis and identification
2. Approach and methodology
3. Tools to use
4. Step-by-step solution walkthrough
5. Key techniques demonstrated

Educational context for learning security concepts."""
        )
        return AgentResult.ok({"solution": solution, "challenge": challenge})

    async def _cve_research(self, context: TaskContext) -> AgentResult:
        """Research CVEs and vulnerabilities."""
        query = context.goal

        # Search for CVE info
        search_results = []
        if self._tool_engine:
            result = await self._tool_engine.execute(
                "web_search", self.agent_id,
                {"query": f"{query} CVE vulnerability", "max_results": 5}
            )
            if result.success:
                search_results = result.data.get("results", [])

        web_context = "\n".join([
            f"- {r['title']}: {r['snippet']}" for r in search_results
        ])

        analysis = await self.think(
            f"""You are a vulnerability researcher. Research and report on:

Query: {query}

Web findings:
{web_context}

Provide:
1. CVE details and CVSS score (if applicable)
2. Affected systems and versions
3. Technical details of the vulnerability
4. Proof-of-concept details (for defense understanding)
5. Patch/mitigation status
6. Exploitation in the wild"""
        )
        return AgentResult.ok({"cve_report": analysis, "query": query})

    async def _network_recon(self, context: TaskContext) -> AgentResult:
        """Network reconnaissance and enumeration guidance."""
        target = context.goal
        commands = await self.think_json(
            f"""Generate network reconnaissance commands for authorized testing of: {target}

Return JSON:
{{
  "passive_recon": ["command1", "command2"],
  "active_recon": ["command1", "command2"],
  "enumeration": ["command1", "command2"],
  "notes": "important notes about authorization requirements"
}}"""
        )
        return AgentResult.ok({"recon_plan": commands, "target": target})
