"""
MUSTAFA OS - System Agents
Memory, Tool Manager, Monitoring, and Evolution agents.
"""

from __future__ import annotations

import asyncio
import importlib
import inspect
import os
import time
from datetime import datetime, timedelta
from typing import Any, Dict, List, Optional

from agents.base import AgentResult, BaseAgent, TaskContext
from core.logging_config import get_logger
from core.registry import agent_registry

logger = get_logger("system_agents")


# ─── Memory Agent ─────────────────────────────────────────────────────────────

class MemoryAgent(BaseAgent):
    """
    Manages all system memory layers:
    - Short-term: Redis-based conversation context
    - Long-term: ChromaDB vector storage for knowledge
    - Experiment: Results from self-improvement runs
    """

    def __init__(self) -> None:
        super().__init__(
            agent_id="memory_agent",
            name="Memory Agent",
            capabilities=["memory_storage", "memory_retrieval", "knowledge_indexing"],
        )
        self._memory_layer = None

    async def on_start(self) -> None:
        from memory.long_term import LongTermMemory
        self._memory_layer = LongTermMemory()
        await self._memory_layer.initialize()

    async def handle_task(self, task_type: str, context: TaskContext) -> AgentResult:
        handlers = {
            "store_memory": self._store_memory,
            "retrieve_memory": self._retrieve_memory,
            "search_memory": self._search_memory,
            "store_experiment": self._store_experiment,
            "execute_step": self._retrieve_memory,
        }
        handler = handlers.get(task_type)
        if not handler:
            return AgentResult.fail(f"Unknown task type: {task_type}")
        return await handler(context)

    async def _store_memory(self, context: TaskContext) -> AgentResult:
        """Store a new memory entry."""
        collection = context.payload.get("collection", "general")
        content = context.payload.get("result") or context.goal
        metadata = {
            "goal": context.payload.get("goal", ""),
            "task_id": context.task_id,
            "agent": context.sender or "unknown",
            "timestamp": datetime.utcnow().isoformat(),
        }

        if self._memory_layer:
            mem_id = await self._memory_layer.store(
                content=str(content),
                metadata=metadata,
                collection=collection,
            )
            return AgentResult.ok({"memory_id": mem_id, "collection": collection})

        # Fallback: store in Redis short-term memory
        from core.messaging import message_bus
        key = f"memory:{collection}:{context.task_id}"
        await message_bus.set_value(key, {"content": content, "metadata": metadata}, ttl=86400)
        return AgentResult.ok({"stored": True, "backend": "redis"})

    async def _retrieve_memory(self, context: TaskContext) -> AgentResult:
        """Retrieve relevant memories for a query."""
        query = context.payload.get("query") or context.goal
        collection = context.payload.get("collection", "general")
        top_k = context.payload.get("top_k", 5)

        if self._memory_layer:
            results = await self._memory_layer.search(
                query=query,
                collection=collection,
                top_k=top_k,
            )
            return AgentResult.ok({"results": results, "query": query})

        return AgentResult.ok({"results": [], "query": query})

    async def _search_memory(self, context: TaskContext) -> AgentResult:
        return await self._retrieve_memory(context)

    async def _store_experiment(self, context: TaskContext) -> AgentResult:
        """Store experiment results."""
        experiment_data = context.payload.get("experiment", {})
        if self._memory_layer:
            mem_id = await self._memory_layer.store(
                content=str(experiment_data),
                metadata={"type": "experiment", "timestamp": datetime.utcnow().isoformat()},
                collection="experiments",
            )
            return AgentResult.ok({"memory_id": mem_id})
        return AgentResult.ok({"stored": False})


# ─── Tool Manager Agent ───────────────────────────────────────────────────────

class ToolManagerAgent(BaseAgent):
    """
    Manages the tool plugin ecosystem:
    - Registers and validates tools
    - Enforces permissions
    - Monitors tool health
    - Dynamically loads new plugins
    """

    def __init__(self) -> None:
        super().__init__(
            agent_id="tool_manager",
            name="Tool Manager Agent",
            capabilities=["tool_registration", "permission_management", "plugin_loading"],
        )
        self._tool_engine = None

    async def on_start(self) -> None:
        from tools import get_tool_engine
        self._tool_engine = get_tool_engine()
        await self._load_plugins()

    async def handle_task(self, task_type: str, context: TaskContext) -> AgentResult:
        handlers = {
            "list_tools": self._list_tools,
            "register_tool": self._register_tool,
            "load_plugin": self._load_plugin,
            "check_permissions": self._check_permissions,
            "tool_health": self._tool_health,
            "execute_step": self._list_tools,
        }
        handler = handlers.get(task_type)
        if not handler:
            return AgentResult.fail(f"Unknown task type: {task_type}")
        return await handler(context)

    async def _list_tools(self, context: TaskContext) -> AgentResult:
        """List all registered tools and their status."""
        if not self._tool_engine:
            return AgentResult.fail("Tool engine not initialized")

        tools = self._tool_engine.get_all_tools()
        return AgentResult.ok({
            "tools": [t.to_dict() for t in tools],
            "total": len(tools),
        })

    async def _register_tool(self, context: TaskContext) -> AgentResult:
        """Register a new tool. Delegates creation to Orchestrator → Developer."""
        tool_config = context.payload.get("tool_config", {})
        tool_name = tool_config.get("name")

        if not tool_name:
            return AgentResult.fail("Tool name required")

        # Route through the orchestrator — it will assign the task to Developer.
        try:
            from core.kernel import kernel
            orchestrator = kernel.get_orchestrator()
            if orchestrator:
                from agents.base import TaskContext as TC
                ctx = TC(
                    task_id=str(__import__("uuid").uuid4()),
                    goal=f"Create a new MUSTAFA OS tool plugin named '{tool_name}': {tool_config.get('description', '')}",
                    payload={"tool_spec": tool_config},
                    sender=self.agent_id,
                )
                asyncio.create_task(orchestrator.handle_task("execute_goal", ctx))
        except Exception as e:
            self.logger.warning("tool_creation_delegation_failed", error=str(e))

        return AgentResult.ok({"tool_name": tool_name, "status": "creation_requested_via_orchestrator"})

    async def _load_plugin(self, context: TaskContext) -> AgentResult:
        """Dynamically load a tool plugin."""
        plugin_path = context.payload.get("plugin_path", "")
        if not plugin_path:
            return AgentResult.fail("plugin_path required")

        try:
            await self._load_plugin_from_path(plugin_path)
            return AgentResult.ok({"loaded": True, "path": plugin_path})
        except Exception as e:
            return AgentResult.fail(f"Plugin load failed: {e}")

    async def _load_plugin_from_path(self, path: str) -> None:
        """Load a tool class from a Python file."""
        if not os.path.exists(path):
            raise FileNotFoundError(f"Plugin not found: {path}")

        spec_name = os.path.splitext(os.path.basename(path))[0]
        spec = importlib.util.spec_from_file_location(spec_name, path)
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)

        # Find tool classes in the module
        from tools.base import BaseTool
        for name, obj in inspect.getmembers(module, inspect.isclass):
            if issubclass(obj, BaseTool) and obj is not BaseTool:
                tool_instance = obj()
                if self._tool_engine:
                    self._tool_engine.register(tool_instance)
                self.logger.info("plugin_loaded", tool=tool_instance.name, path=path)

    async def _check_permissions(self, context: TaskContext) -> AgentResult:
        agent_id = context.payload.get("agent_id", "")
        tool_name = context.payload.get("tool_name", "")

        if self._tool_engine:
            allowed = self._tool_engine.check_permission(agent_id, tool_name)
            return AgentResult.ok({"allowed": allowed, "agent": agent_id, "tool": tool_name})

        return AgentResult.ok({"allowed": True})  # Default allow if no engine

    async def _tool_health(self, context: TaskContext) -> AgentResult:
        if not self._tool_engine:
            return AgentResult.fail("Tool engine not initialized")

        health = await self._tool_engine.health_check_all()
        return AgentResult.ok(health)

    async def _load_plugins(self) -> None:
        """Auto-load all plugins from the plugins directory."""
        from core.settings import settings
        plugins_dir = settings.plugins_dir

        if not os.path.exists(plugins_dir):
            os.makedirs(plugins_dir, exist_ok=True)
            return

        for filename in os.listdir(plugins_dir):
            if filename.endswith(".py") and not filename.startswith("_"):
                plugin_path = os.path.join(plugins_dir, filename)
                try:
                    await self._load_plugin_from_path(plugin_path)
                except Exception as e:
                    self.logger.warning("plugin_load_failed", path=plugin_path, error=str(e))


# ─── Monitoring Agent ─────────────────────────────────────────────────────────

class MonitoringAgent(BaseAgent):
    """
    Observes system health, collects metrics, and generates alerts.
    Tracks agent performance, error rates, and resource utilization.
    """

    def __init__(self) -> None:
        super().__init__(
            agent_id="monitoring_agent",
            name="Monitoring Agent",
            capabilities=["health_monitoring", "metrics_collection", "alerting", "reporting"],
        )
        self._metrics_history: List[Dict[str, Any]] = []
        self._alert_thresholds = {
            "error_rate": 0.1,
            "agent_failure_rate": 0.2,
            "response_time_seconds": 30.0,
        }
        self._monitor_task: Optional[asyncio.Task] = None

    async def on_start(self) -> None:
        """Start background monitoring loop."""
        self._monitor_task = asyncio.create_task(self._monitoring_loop())

    async def on_stop(self) -> None:
        if self._monitor_task:
            self._monitor_task.cancel()

    async def handle_task(self, task_type: str, context: TaskContext) -> AgentResult:
        handlers = {
            "get_health": self._get_health,
            "get_metrics": self._get_metrics,
            "get_agent_status": self._get_agent_status,
            "set_alert_threshold": self._set_threshold,
            "execute_step": self._get_health,
        }
        handler = handlers.get(task_type)
        if not handler:
            return AgentResult.fail(f"Unknown task type: {task_type}")
        return await handler(context)

    async def _monitoring_loop(self) -> None:
        """Background loop that collects metrics every 30 seconds."""
        while self._running:
            try:
                metrics = await self._collect_metrics()
                self._metrics_history.append(metrics)

                # Keep last 1000 metrics snapshots
                if len(self._metrics_history) > 1000:
                    self._metrics_history = self._metrics_history[-1000:]

                await self._check_alerts(metrics)
                await asyncio.sleep(30)
            except asyncio.CancelledError:
                break
            except Exception as e:
                self.logger.error("monitoring_loop_error", error=str(e))
                await asyncio.sleep(5)

    async def _collect_metrics(self) -> Dict[str, Any]:
        """Collect current system metrics."""
        import psutil
        summary = agent_registry.get_system_summary()

        metrics = {
            "timestamp": datetime.utcnow().isoformat(),
            "agents": summary,
        }

        try:
            metrics["system"] = {
                "cpu_percent": psutil.cpu_percent(interval=0.1),
                "memory_percent": psutil.virtual_memory().percent,
                "disk_percent": psutil.disk_usage("/").percent,
            }
        except ImportError:
            metrics["system"] = {}

        return metrics

    async def _check_alerts(self, metrics: Dict[str, Any]) -> None:
        """Check metrics against thresholds and log alerts.

        NOTE: We deliberately do NOT broadcast alerts via pub/sub.
        Alerts are logged as structured JSON for external monitoring systems
        to consume, and written to Redis for the /health endpoint to surface.
        """
        agents = metrics.get("agents", {})
        total_tasks = agents.get("total_tasks_completed", 0)
        success_rate = agents.get("overall_success_rate", 1.0)
        error_rate = 1.0 - success_rate

        # Don't fire alerts until the system has processed enough tasks to
        # have a meaningful error rate. At startup, 1 failed health-check
        # would produce error_rate=1.0, which is a false alarm.
        if total_tasks < 5:
            return

        if error_rate > self._alert_thresholds["error_rate"]:
            self.logger.warning(
                "alert_high_error_rate",
                error_rate=round(error_rate, 4),
                threshold=self._alert_thresholds["error_rate"],
                total_tasks=total_tasks,
                recommendation="Check LLM API key / rate limits",
            )
            try:
                from core.messaging import message_bus
                await message_bus.set_value(
                    "alerts:latest",
                    {
                        "alert_type": "high_error_rate",
                        "value": error_rate,
                        "threshold": self._alert_thresholds["error_rate"],
                        "timestamp": datetime.utcnow().isoformat(),
                    },
                    ttl=300,
                )
            except Exception:
                pass

    async def _get_health(self, context: TaskContext) -> AgentResult:
        """Get current system health status."""
        from core.messaging import message_bus

        redis_ok = await message_bus.health_check()
        summary = agent_registry.get_system_summary()

        overall_healthy = (
            redis_ok
            and summary["total_agents"] > 0
            and summary.get("overall_success_rate", 0) > 0.8
        )

        health = {
            "status": "healthy" if overall_healthy else "degraded",
            "timestamp": datetime.utcnow().isoformat(),
            "components": {
                "redis": "ok" if redis_ok else "error",
                "agents": "ok" if summary["total_agents"] > 0 else "error",
            },
            "agents": summary,
            "recent_metrics": self._metrics_history[-1] if self._metrics_history else {},
        }

        return AgentResult.ok(health)

    async def _get_metrics(self, context: TaskContext) -> AgentResult:
        """Get metrics history."""
        limit = context.payload.get("limit", 10)
        return AgentResult.ok({
            "metrics": self._metrics_history[-limit:],
            "total_collected": len(self._metrics_history),
        })

    async def _get_agent_status(self, context: TaskContext) -> AgentResult:
        agents = agent_registry.get_all_agents()
        return AgentResult.ok([a.to_dict() for a in agents])

    async def _set_threshold(self, context: TaskContext) -> AgentResult:
        metric = context.payload.get("metric")
        value = context.payload.get("value")
        if metric and value is not None:
            self._alert_thresholds[metric] = float(value)
        return AgentResult.ok({"thresholds": self._alert_thresholds})


# ─── Evolution Agent ──────────────────────────────────────────────────────────

class EvolutionAgent(BaseAgent):
    """
    Drives continuous system self-improvement:
    - Analyzes performance data
    - Proposes targeted improvements
    - Designs A/B experiments
    - Deploys successful upgrades
    - Rolls back failures
    """

    def __init__(self) -> None:
        super().__init__(
            agent_id="evolution",
            name="Evolution Agent",
            capabilities=["self_improvement", "experiment_design", "performance_analysis"],
        )
        self._experiments: List[Dict[str, Any]] = []

    async def handle_task(self, task_type: str, context: TaskContext) -> AgentResult:
        handlers = {
            "run_evolution_cycle": self._run_evolution_cycle,
            "propose_improvement": self._propose_improvement,
            "evaluate_experiment": self._evaluate_experiment,
            "deploy_improvement": self._deploy_improvement,
            "list_experiments": self._list_experiments,
            "execute_step": self._run_evolution_cycle,
        }
        handler = handlers.get(task_type)
        if not handler:
            return AgentResult.fail(f"Unknown task type: {task_type}")
        return await handler(context)

    async def _run_evolution_cycle(self, context: TaskContext) -> AgentResult:
        """
        Full evolution cycle:
        1. Collect performance data
        2. Identify weaknesses
        3. Propose improvements
        4. Simulate/test changes
        5. Deploy best improvement
        """
        self.logger.info("starting_evolution_cycle")

        # Step 1: Get performance data
        perf_data = await self._collect_performance_data()

        # Step 2: Analyze weaknesses
        weaknesses = await self._identify_weaknesses(perf_data)

        # Step 3: Propose improvement
        if not weaknesses:
            return AgentResult.ok({"status": "no_improvements_needed", "message": "System performing well"})

        improvement = await self._propose_targeted_improvement(weaknesses[0])

        # Step 4: Create experiment record
        experiment = {
            "id": f"exp_{int(time.time())}",
            "hypothesis": improvement.get("hypothesis", ""),
            "proposed_change": improvement,
            "baseline_metrics": perf_data,
            "status": "proposed",
            "created_at": datetime.utcnow().isoformat(),
        }
        self._experiments.append(experiment)

        # Delegate implementation to orchestrator (which assigns to Developer)
        try:
            from core.kernel import kernel
            orchestrator = kernel.get_orchestrator()
            if orchestrator:
                from agents.base import TaskContext as TC
                impl_ctx = TC(
                    task_id=str(__import__("uuid").uuid4()),
                    goal=f"Implement this system improvement: {improvement.get('title', '')}. {improvement.get('description', '')}",
                    payload={"improvement": improvement, "triggered_by": "evolution"},
                    sender=self.agent_id,
                )
                asyncio.create_task(orchestrator.handle_task("execute_goal", impl_ctx))
        except Exception as e:
            self.logger.warning("evolution_delegation_failed", error=str(e))

        # Store experiment directly in memory layer — no agent hop needed
        try:
            from memory.long_term import LongTermMemory
            mem = LongTermMemory()
            await mem.store(
                content=str(experiment),
                metadata={"type": "experiment", "timestamp": datetime.utcnow().isoformat()},
                collection="experiments",
            )
        except Exception as e:
            self.logger.warning("experiment_memory_store_failed", error=str(e))

        return AgentResult.ok({
            "cycle_completed": True,
            "weaknesses_found": len(weaknesses),
            "improvement_proposed": improvement.get("title"),
            "experiment_id": experiment["id"],
        })

    async def _collect_performance_data(self) -> Dict[str, Any]:
        """Collect current system performance metrics."""
        summary = agent_registry.get_system_summary()
        return {
            "agent_count": summary["total_agents"],
            "success_rate": summary["overall_success_rate"],
            "total_tasks": summary["total_tasks_completed"],
            "timestamp": datetime.utcnow().isoformat(),
        }

    async def _identify_weaknesses(self, perf_data: Dict[str, Any]) -> List[str]:
        """Use LLM to identify system weaknesses."""
        analysis = await self.think_json(
            f"""Analyze this system performance data and identify the top weaknesses:

{perf_data}

Return JSON:
{{
  "weaknesses": [
    "description of weakness 1",
    "description of weakness 2"
  ],
  "severity": ["high", "medium"],
  "root_causes": ["cause1", "cause2"]
}}"""
        )
        return analysis.get("weaknesses", [])

    async def _propose_targeted_improvement(self, weakness: str) -> Dict[str, Any]:
        """Propose a specific improvement for a identified weakness."""
        return await self.think_json(
            f"""Propose a specific, implementable improvement for this system weakness:

WEAKNESS: {weakness}

Return JSON:
{{
  "title": "improvement title",
  "hypothesis": "if we do X, then Y will improve by Z%",
  "description": "detailed description",
  "implementation_steps": ["step1", "step2"],
  "expected_improvement_pct": 15,
  "risk_level": "low|medium|high",
  "effort_hours": 2
}}"""
        )

    async def _evaluate_experiment(self, context: TaskContext) -> AgentResult:
        """Evaluate an experiment's results."""
        exp_id = context.payload.get("experiment_id")
        new_metrics = context.payload.get("new_metrics", {})

        exp = next((e for e in self._experiments if e["id"] == exp_id), None)
        if not exp:
            return AgentResult.fail(f"Experiment {exp_id} not found")

        baseline = exp.get("baseline_metrics", {})
        baseline_sr = baseline.get("success_rate", 1.0)
        new_sr = new_metrics.get("success_rate", baseline_sr)

        improvement_pct = ((new_sr - baseline_sr) / max(baseline_sr, 0.001)) * 100

        from core.settings import get_system_config
        threshold = get_system_config().get("self_improvement", {}).get("auto_deploy_threshold", 0.15)

        should_deploy = improvement_pct >= (threshold * 100)

        exp["status"] = "evaluated"
        exp["improvement_pct"] = improvement_pct
        exp["should_deploy"] = should_deploy

        return AgentResult.ok({
            "experiment_id": exp_id,
            "improvement_pct": improvement_pct,
            "should_deploy": should_deploy,
            "verdict": "deploy" if should_deploy else "rollback",
        })

    async def _deploy_improvement(self, context: TaskContext) -> AgentResult:
        """Deploy a validated improvement."""
        exp_id = context.payload.get("experiment_id")
        exp = next((e for e in self._experiments if e["id"] == exp_id), None)

        if not exp:
            return AgentResult.fail(f"Experiment {exp_id} not found")

        if not exp.get("should_deploy"):
            return AgentResult.fail("Experiment not approved for deployment")

        exp["status"] = "deployed"
        exp["deployed_at"] = datetime.utcnow().isoformat()

        self.logger.info(
            "improvement_deployed",
            experiment_id=exp_id,
            improvement_pct=exp.get("improvement_pct"),
        )

        return AgentResult.ok({
            "deployed": True,
            "experiment_id": exp_id,
            "improvement": exp.get("proposed_change", {}).get("title"),
        })

    async def _propose_improvement(self, context: TaskContext) -> AgentResult:
        target = context.goal
        improvement = await self._propose_targeted_improvement(target)
        return AgentResult.ok(improvement)

    async def _list_experiments(self, context: TaskContext) -> AgentResult:
        return AgentResult.ok({
            "experiments": self._experiments,
            "total": len(self._experiments),
        })
