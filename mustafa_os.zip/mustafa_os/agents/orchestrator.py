"""
MUSTAFA OS - Orchestrator Agent
The sole public-facing agent. Receives all user goals, builds intelligent
execution plans with full awareness of available agents and tools, assigns
tasks to the right agents, tracks progress, and returns synthesized results.
"""

from __future__ import annotations

import asyncio
import uuid
from datetime import datetime
from typing import Any, Dict, List, Optional, Tuple

from agents.base import AgentResult, BaseAgent, TaskContext
from core.database import TaskRecord, async_session_factory
from core.logging_config import get_logger
from core.registry import agent_registry
from sqlalchemy import select

logger = get_logger("orchestrator")


class OrchestratorAgent(BaseAgent):
    """
    The Orchestrator is the brain and sole entry point of MUSTAFA OS.

    It maintains live awareness of:
      - Every registered agent, its status, and its capabilities
      - Every registered tool, its permissions, and its description
      - Task history and past outcomes (via memory)

    It uses this context to:
      - Classify goals (simple vs complex)
      - Build grounded execution plans (no hallucinated agent names)
      - Route each step to the most capable available agent
      - Re-route on failure without crashing the pipeline
      - Synthesize a final answer from all step results
    """

    def __init__(self) -> None:
        super().__init__(
            agent_id="orchestrator",
            name="Orchestrator Agent",
            capabilities=[
                "goal_parsing", "task_assignment", "plan_coordination",
                "tool_awareness", "agent_routing", "conflict_resolution",
                "result_aggregation",
            ],
            allowed_tools=["*"],
        )
        self._active_tasks: Dict[str, Dict[str, Any]] = {}

    # ─── Public entry point ───────────────────────────────────────────────────

    async def handle_task(self, task_type: str, context: TaskContext) -> AgentResult:
        """Route incoming tasks. This is the only handler the system calls."""
        handlers = {
            "execute_goal": self._execute_goal,
            "task_status":  self._get_task_status,
            "system_status": self._get_system_status,
        }
        handler = handlers.get(task_type)
        if not handler:
            return AgentResult.fail(f"Unknown task type: {task_type}")
        return await handler(context)

    # ─── Main pipeline ────────────────────────────────────────────────────────

    async def _execute_goal(self, context: TaskContext) -> AgentResult:
        goal    = context.goal
        task_id = context.task_id
        self.logger.info("executing_goal", goal=goal[:100], task_id=task_id)
        await self._persist_task(task_id, goal, "running")

        try:
            # ── 1. Fast path: simple / conversational ──────────────────────
            if self._is_simple_query(goal):
                self.logger.info("fast_path", task_id=task_id)
                answer = await self.think(
                    goal,
                    system_prompt=(
                        "You are a helpful, direct assistant. Answer concisely. "
                        "Do not write code unless explicitly asked. "
                        "Do not explain your reasoning unless asked."
                    ),
                )
                await self._persist_task(task_id, goal, "completed", result={"answer": answer})
                return AgentResult.ok(data={"answer": answer}, task_id=task_id)

            # ── 2. Recall relevant past experience ────────────────────────
            memory_context = await self._recall_memory(goal)

            # ── 3. Build system context ────────────────────────────────────
            sys_ctx = self._build_system_context()
            self.logger.info(
                "system_context_built",
                agents=len(sys_ctx["agents"]),
                tools=len(sys_ctx["tools"]),
                memory_hits=len(memory_context),
            )

            # ── 3. Build an intelligent execution plan ─────────────────────
            await self._persist_task(task_id, goal, "planning")
            plan = await self._build_plan(goal, sys_ctx, task_id, memory_context)
            if not plan or not plan.get("steps"):
                return AgentResult.fail("Could not generate a valid execution plan")

            self.logger.info("plan_built", task_id=task_id, steps=len(plan["steps"]))
            await self._persist_task(task_id, goal, "executing", plan=plan)

            # ── 4. Execute each step ───────────────────────────────────────
            results = await self._execute_plan(plan, sys_ctx, task_id)

            # ── 5. Synthesize final answer ─────────────────────────────────
            final_answer = await self._synthesize(goal, results)

            # ── 6. Critic evaluation (non-blocking on failure) ─────────────
            critique = await self._evaluate(goal, final_answer, task_id)

            # ── 7. Persist to memory (fire-and-forget) ─────────────────────
            await self._store_memory(goal, final_answer, task_id)

            await self._persist_task(
                task_id, goal, "completed",
                result={"answer": final_answer, "critique": critique},
            )
            self.logger.info("goal_completed", task_id=task_id)
            return AgentResult.ok(
                data={"answer": final_answer, "plan": plan, "critique": critique},
                task_id=task_id,
            )

        except Exception as e:
            await self._persist_task(task_id, goal, "failed", error=str(e))
            self.logger.error("goal_failed", task_id=task_id, error=str(e))
            return AgentResult.fail(str(e), task_id=task_id)

    # ─── System context ───────────────────────────────────────────────────────

    def _build_system_context(self) -> Dict[str, Any]:
        """
        Assemble a live snapshot of every available agent and tool.
        This is injected into every plan-building and routing prompt so the
        LLM never hallucinates agent names or tool names.
        """
        agents = []
        for info in agent_registry.get_all_agents():
            if info.agent_id == "orchestrator":
                continue  # orchestrator doesn't assign tasks to itself
            agents.append({
                "id":           info.agent_id,
                "name":         info.name,
                "status":       info.status,
                "capabilities": info.capabilities,
                "available":    info.status == "idle",
            })

        tools = []
        try:
            from tools import get_tool_engine
            for t in get_tool_engine().get_all_tools():
                tools.append({
                    "name":        t.name,
                    "description": t.description,
                    "permissions": t.permissions,
                })
        except Exception:
            pass

        return {"agents": agents, "tools": tools}

    def _agent_ids(self, sys_ctx: Dict[str, Any]) -> List[str]:
        return [a["id"] for a in sys_ctx["agents"]]

    def _tool_names(self, sys_ctx: Dict[str, Any]) -> List[str]:
        return [t["name"] for t in sys_ctx["tools"]]

    # ─── Plan building ────────────────────────────────────────────────────────

    async def _build_plan(
        self, goal: str, sys_ctx: Dict[str, Any], task_id: str,
        memory_context: List[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """
        Ask the Planner to create a structured plan, injecting live agent
        and tool context so it cannot hallucinate names.
        Falls back to self-generated plan if Planner is unavailable.
        """
        planner = agent_registry.get_agent("planner")
        if planner and planner.instance and planner.status == "idle":
            try:
                ctx = TaskContext(
                    task_id=task_id,
                    goal=goal,
                    payload={
                        "goal":             goal,
                        "task_id":          task_id,
                        "available_agents": sys_ctx["agents"],
                        "available_tools":  sys_ctx["tools"],
                        "memory_context":   memory_context or [],
                    },
                    sender=self.agent_id,
                )
                result = await asyncio.wait_for(
                    planner.instance.handle_task("create_plan", ctx), timeout=60
                )
                if result.success and result.data and result.data.get("steps"):
                    plan = result.data
                    plan = self._validate_plan_agents(plan, sys_ctx)
                    return plan
            except Exception as e:
                self.logger.warning("planner_unavailable", error=str(e))

        return await self._self_plan(goal, sys_ctx, memory_context or [])

    async def _self_plan(
        self, goal: str, sys_ctx: Dict[str, Any],
        memory_context: List[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """
        Orchestrator builds the plan itself using real agent IDs, tool names,
        and relevant past memory.
        """
        agent_list = "\n".join([
            f"  - {a['id']} ({a['name']}): capabilities={a['capabilities']}, available={a.get('available', True)}"
            for a in sys_ctx["agents"]
        ]) or "  research, developer, testing, critic, memory_agent"

        tool_list = "\n".join([
            f"  - {t['name']}: {t['description']}"
            for t in sys_ctx["tools"]
        ]) or "  web_search, file_manager, code_executor, data_analysis"

        memory_str = ""
        if memory_context:
            memory_str = "\nRELEVANT PAST EXPERIENCE:\n" + "\n".join([
                f"  - {m.get('content', '')[:200]}"
                for m in memory_context[:3]
            ])

        plan = await self.think_json(f"""You are MUSTAFA OS Orchestrator building an execution plan.

GOAL: {goal}
{memory_str}
AVAILABLE AGENTS (use ONLY these exact IDs):
{agent_list}

AVAILABLE TOOLS (use ONLY these exact names):
{tool_list}

Rules:
- Use ONLY agent IDs listed above. Never invent names.
- Assign each step to the MOST capable agent.
- Include the tools each step actually needs.
- 1-4 steps maximum. Simpler is better.
- Do NOT assign steps to "orchestrator".

Return ONLY JSON (no markdown):
{{
  "goal": "{goal}",
  "steps": [
    {{
      "step_id": 1,
      "description": "specific concrete action",
      "agent": "agent_id",
      "tools": ["tool_name"],
      "depends_on": [],
      "timeout": 60
    }}
  ],
  "complexity": "low|medium|high"
}}""")
        return plan

    def _validate_plan_agents(
        self, plan: Dict[str, Any], sys_ctx: Dict[str, Any]
    ) -> Dict[str, Any]:
        """
        Replace any hallucinated agent IDs in the plan with the best real
        alternative based on the step description.
        """
        valid_ids = set(self._agent_ids(sys_ctx))
        for step in plan.get("steps", []):
            agent_id = step.get("agent", "")
            if agent_id not in valid_ids:
                replacement = self._pick_agent_for_step(step, sys_ctx)
                self.logger.warning(
                    "hallucinated_agent_replaced",
                    original=agent_id,
                    replacement=replacement,
                    step=step.get("step_id"),
                )
                step["agent"] = replacement
        return plan

    # ─── Intelligent routing ──────────────────────────────────────────────────

    def _pick_agent_for_step(
        self, step: Dict[str, Any], sys_ctx: Dict[str, Any]
    ) -> str:
        """
        Select the best available agent for a step based on its description
        and required tools. Uses keyword matching against agent capabilities.
        Falls back to research agent, then first available agent.
        """
        description = (step.get("description", "") + " " + step.get("agent", "")).lower()
        tools_needed = [t.lower() for t in step.get("tools", [])]

        # Capability keyword map → agent preference
        routing_rules: List[Tuple[List[str], str]] = [
            (["code", "script", "function", "python", "implement", "program",
              "debug", "module", "class", "api", "endpoint"],          "developer"),
            (["test", "unit test", "verify", "coverage", "pytest"],    "testing"),
            (["review", "evaluate", "critique", "quality", "score",
              "validate", "check"],                                     "critic"),
            (["research", "search", "web", "find", "look up", "fetch",
              "news", "information", "data", "article"],                "research"),
            (["memory", "store", "retrieve", "remember", "knowledge"],  "memory_agent"),
            (["tool", "plugin", "register", "permission"],              "tool_manager"),
            (["monitor", "metric", "health", "status", "alert"],        "monitoring_agent"),
            (["evolve", "improve", "experiment", "optimise", "optimize"], "evolution"),
            (["plan", "strategy", "steps", "workflow", "schedule"],     "planner"),
        ]

        available = {a["id"] for a in sys_ctx["agents"] if a["available"]}
        all_ids   = {a["id"] for a in sys_ctx["agents"]}

        # Also route based on tools requested
        tool_to_agent = {
            "web_search":     "research",
            "api_request":    "research",
            "code_executor":  "developer",
            "file_manager":   "developer",
            "database_query": "developer",
            "data_analysis":  "research",
            "memory_search":  "memory_agent",
            "system_metrics": "monitoring_agent",
        }
        for tool in tools_needed:
            candidate = tool_to_agent.get(tool)
            if candidate and candidate in all_ids:
                return candidate if candidate in available else candidate

        for keywords, agent_id in routing_rules:
            if agent_id in all_ids and any(kw in description for kw in keywords):
                return agent_id

        # Fallback chain
        for fallback in ("research", "developer", "planner"):
            if fallback in all_ids:
                return fallback

        return list(all_ids)[0] if all_ids else "research"

    # ─── Plan execution ───────────────────────────────────────────────────────

    async def _execute_plan(
        self, plan: Dict[str, Any], sys_ctx: Dict[str, Any], task_id: str
    ) -> List[Dict[str, Any]]:
        """Execute all plan steps respecting dependencies, with smart re-routing on failure."""
        steps = plan.get("steps", [])
        results: List[Dict[str, Any]] = []
        completed: Dict[int, Dict] = {}  # step_id → result

        for step in steps:
            step_id    = step.get("step_id", len(results) + 1)
            depends_on = step.get("depends_on", [])

            # Dependency check
            unmet = [d for d in depends_on if d not in completed]
            if unmet:
                self.logger.warning("step_skipped_unmet_deps", step_id=step_id, unmet=unmet)
                results.append({"step": step, "result": {"success": False, "error": "Unmet dependencies"}})
                continue

            # Resolve agent — re-validate at execution time (status may have changed)
            agent_id = step.get("agent", "")
            agent_info = agent_registry.get_agent(agent_id)
            if not agent_info:
                agent_id = self._pick_agent_for_step(step, sys_ctx)
                self.logger.info("agent_rerouted", from_agent=step.get("agent"), to_agent=agent_id)
                step["agent"] = agent_id

            result = await self._dispatch_step(step, task_id)
            results.append({"step": step, "result": result})
            completed[step_id] = result

            # If step failed and it's a hard dependency for later steps, log it
            if not result.get("success"):
                self.logger.warning(
                    "step_failed",
                    step_id=step_id,
                    agent=agent_id,
                    error=result.get("error", ""),
                )

        return results

    # ─── Agent → task type mapping ────────────────────────────────────────────

    # Maps agent_id → the task_type that triggers its strongest handler.
    # "execute_step" is a weak fallback — use the specific type whenever possible.
    _AGENT_TASK_TYPE: Dict[str, str] = {
        "research":        "research",
        "developer":       "write_code",
        "testing":         "write_tests",
        "critic":          "evaluate",
        "memory_agent":    "retrieve_memory",
        "planner":         "create_plan",
        "tool_manager":    "list_tools",
        "monitoring_agent": "get_health",
        "evolution":       "run_evolution_cycle",
    }

    async def _dispatch_step(
        self, step: Dict[str, Any], task_id: str
    ) -> Dict[str, Any]:
        """
        Dispatch a single step to its assigned agent using the correct task type.

        For steps that need web data, we call the web_search tool directly here
        and inject the results into the agent's context — so the agent focuses
        on reasoning, not retrieval.
        """
        agent_id    = step.get("agent", "research")
        description = step.get("description", "")
        tools_needed = step.get("tools", [])
        timeout     = step.get("timeout", 120)

        # Use the agent's strongest task type, not the generic "execute_step"
        task_type = self._AGENT_TASK_TYPE.get(agent_id, "execute_step")

        self.logger.info(
            "dispatching_step",
            step_id=step.get("step_id"),
            agent=agent_id,
            task_type=task_type,
            description=description[:80],
            tools=tools_needed,
        )

        from core.kernel import kernel
        agent_instance = kernel.get_agent(agent_id)
        if not agent_instance:
            self.logger.error("agent_instance_missing", agent_id=agent_id)
            return {"success": False, "error": f"Agent '{agent_id}' not found in kernel"}

        # Pre-fetch tool data when the step needs it, so the agent gets
        # enriched context rather than having to figure out retrieval itself
        enriched_context = description
        tool_results: Dict[str, Any] = {}

        if "web_search" in tools_needed or "api_request" in tools_needed:
            tool_results["web_search"] = await self._call_tool(
                "web_search", {"query": description, "max_results": 5}
            )
            web_data = tool_results["web_search"]
            if web_data.get("success") and web_data.get("data", {}).get("results"):
                snippets = "\n".join([
                    f"- {r.get('title','')}: {r.get('snippet','')}"
                    for r in web_data["data"]["results"][:5]
                ])
                enriched_context = f"{description}\n\nWeb search results:\n{snippets}"

        if "memory_search" in tools_needed:
            tool_results["memory"] = await self._call_tool(
                "memory_search", {"query": description, "top_k": 3}
            )

        if "data_analysis" in tools_needed:
            tool_results["data_analysis_available"] = True

        try:
            ctx = TaskContext(
                task_id=task_id,
                goal=enriched_context,
                payload={
                    "goal":         enriched_context,
                    "original_goal": description,
                    "task_id":      task_id,
                    "tools":        tools_needed,
                    "tool_results": tool_results,
                    "step":         step,
                    # Pass code/content fields that specific agents need
                    "code":         step.get("code", ""),
                    "answer":       step.get("answer", ""),
                },
                sender=self.agent_id,
            )
            result = await asyncio.wait_for(
                agent_instance.handle_task(task_type, ctx),
                timeout=timeout,
            )
            return result.to_dict()

        except asyncio.TimeoutError:
            self.logger.error("step_timeout", step_id=step.get("step_id"), timeout=timeout)
            return {"success": False, "error": f"Step timed out after {timeout}s"}
        except Exception as e:
            self.logger.error("step_dispatch_failed", error=str(e))
            return {"success": False, "error": str(e)}

    async def _call_tool(
        self, tool_name: str, params: Dict[str, Any]
    ) -> Dict[str, Any]:
        """Call a tool directly from the orchestrator."""
        try:
            from tools import get_tool_engine
            engine = get_tool_engine()
            result = await asyncio.wait_for(
                engine.execute(tool_name, self.agent_id, params),
                timeout=20,
            )
            return result.to_dict()
        except Exception as e:
            self.logger.warning("orchestrator_tool_call_failed", tool=tool_name, error=str(e))
            return {"success": False, "error": str(e)}

    # ─── Simple query classifier ──────────────────────────────────────────────

    def _is_simple_query(self, goal: str) -> bool:
        """
        Synchronous classifier — no LLM call, no latency.
        Returns True for conversational / trivial factual queries that
        should be answered in a single LLM call without spinning up the
        full agent pipeline.
        """
        g = goal.lower().strip()
        words = g.split()
        n = len(words)

        greetings = {"hi", "hello", "hey", "thanks", "thank you", "bye",
                     "ok", "okay", "cool", "great", "nice", "good"}
        if g in greetings or (n <= 2 and "?" not in g):
            return True

        # Hard complex signals — always full pipeline
        complex_signals = [
            "research", "search for", "find out", "look up", "web search",
            "write code", "write a script", "write a function", "write a program",
            "build", "implement", "create a", "develop", "make me a",
            "analyse", "analyze", "summarize", "summarise", "compare",
            "step by step", "step-by-step", "generate a", "automate",
            "scrape", "fetch data", "download", "monitor",
        ]
        if any(sig in g for sig in complex_signals):
            return False

        # Short factual questions — fast path
        simple_starters = [
            "what is", "what's", "what are", "who is", "who's", "who are",
            "when is", "when was", "where is", "where are",
            "how much", "how many", "how do you", "how does",
            "why is", "why are", "which is", "define ", "tell me what",
            "what time", "what date", "what day", "what year",
        ]
        if n <= 12 and any(g.startswith(s) for s in simple_starters):
            return True

        # Pure math / conversion
        if n <= 8 and any(op in g for op in ["+", "-", "×", "÷", "convert ", " to usd", " to eur", " in km", " in miles"]):
            return True

        # Short open-ended questions that don't need external data
        return n <= 5

    # ─── Post-processing ──────────────────────────────────────────────────────

    async def _recall_memory(self, goal: str) -> List[Dict[str, Any]]:
        """
        Query long-term memory for relevant past experience before planning.
        Returns empty list gracefully if memory is unavailable.
        """
        try:
            from memory.long_term import LongTermMemory
            mem = LongTermMemory()
            if not mem.is_available:
                await mem.initialize()
            results = await mem.search(query=goal, collection="task_history", top_k=3)
            if results:
                self.logger.debug("memory_recalled", hits=len(results))
            return results
        except Exception:
            return []

    async def _synthesize(self, goal: str, results: List[Dict[str, Any]]) -> str:
        """Synthesize all step outputs into a single coherent final answer."""
        summary_parts = []
        for i, r in enumerate(results):
            step   = r.get("step", {})
            res    = r.get("result", {})
            ok     = res.get("success", False)
            # Dig through nested result structures to get the actual content
            data   = res.get("data") or {}
            if isinstance(data, dict):
                content = (
                    data.get("findings") or
                    data.get("response") or
                    data.get("result") or
                    data.get("answer") or
                    data.get("summary") or
                    data.get("code") or
                    str(data)
                )
            else:
                content = str(data) if data else res.get("error", "no output")

            summary_parts.append(
                f"Step {i+1} [{step.get('agent','?')}] — "
                f"{'OK' if ok else 'FAILED'}: {str(content)[:500]}"
            )

        steps_text = "\n".join(summary_parts)

        return await self.think(
            f"""Synthesize the following execution results into a clear, direct answer.

ORIGINAL GOAL: {goal}

RESULTS:
{steps_text}

Instructions:
- Directly and fully answer the original goal.
- Be specific, accurate, and actionable.
- Present findings clearly — use formatting if it helps readability.
- If any steps failed, use what succeeded and note gaps.
- Do NOT describe your process. Just deliver the answer.""",
            system_prompt=(
                "You are MUSTAFA OS delivering a final result to a user. "
                "Be direct, clear, and complete. Avoid unnecessary preamble."
            ),
        )

    async def _evaluate(self, goal: str, answer: str, task_id: str) -> Dict[str, Any]:
        """Ask the Critic to evaluate the answer. Non-blocking — returns default on failure."""
        try:
            from core.kernel import kernel
            critic = kernel.get_agent("critic")
            if critic:
                ctx = TaskContext(
                    task_id=task_id, goal=goal,
                    payload={"goal": goal, "answer": answer, "task_id": task_id},
                    sender=self.agent_id,
                )
                result = await asyncio.wait_for(
                    critic.handle_task("evaluate", ctx), timeout=30
                )
                if result.success and result.data:
                    return result.data
        except Exception as e:
            self.logger.debug("critique_skipped", reason=str(e))
        return {"score": 0.8, "verdict": "accept"}

    async def _store_memory(self, goal: str, answer: str, task_id: str) -> None:
        """Fire-and-forget memory persistence."""
        try:
            from core.kernel import kernel
            mem = kernel.get_agent("memory_agent")
            if mem:
                ctx = TaskContext(
                    task_id=task_id, goal=goal,
                    payload={
                        "goal": goal, "result": answer,
                        "task_id": task_id, "collection": "task_history",
                    },
                    sender=self.agent_id,
                )
                asyncio.create_task(mem.handle_task("store_memory", ctx))
        except Exception:
            pass

    # ─── Status / utility handlers ────────────────────────────────────────────

    async def _get_task_status(self, context: TaskContext) -> AgentResult:
        task_id = context.payload.get("task_id")
        if not task_id:
            return AgentResult.fail("task_id required")
        async with async_session_factory() as session:
            result = await session.execute(
                select(TaskRecord).where(TaskRecord.id == task_id)
            )
            task = result.scalar_one_or_none()
        if not task:
            return AgentResult.fail(f"Task {task_id} not found")
        return AgentResult.ok({
            "task_id":    task.id,
            "status":     task.status,
            "goal":       task.goal,
            "result":     task.result,
            "created_at": task.created_at.isoformat(),
        })

    async def _get_system_status(self, context: TaskContext) -> AgentResult:
        ctx = self._build_system_context()
        ctx["registry"] = agent_registry.get_system_summary()
        return AgentResult.ok(ctx)

    async def _persist_task(
        self,
        task_id: str,
        goal: str,
        status: str,
        plan: Optional[Dict] = None,
        result: Optional[Dict] = None,
        error: Optional[str] = None,
    ) -> None:
        try:
            async with async_session_factory() as session:
                existing = await session.get(TaskRecord, task_id)
                if existing:
                    existing.status = status
                    if plan:   existing.plan  = plan
                    if result: existing.result = result
                    if error:  existing.error  = error
                    if status == "completed":
                        existing.completed_at = datetime.utcnow()
                else:
                    session.add(TaskRecord(
                        id=task_id, goal=goal, status=status,
                        assigned_agent=self.agent_id,
                        plan=plan, result=result, error=error,
                    ))
                await session.commit()
        except Exception as e:
            self.logger.error("task_persist_failed", error=str(e))
