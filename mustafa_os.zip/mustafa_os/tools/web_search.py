"""
MUSTAFA OS - Web Search Tool
Uses `ddgs` (the current package). Refuses the deprecated `duckduckgo_search`
which routes all queries to Bing and returns 0 results.
"""

from __future__ import annotations

import asyncio
import sys
from typing import Any, Dict, List, Optional

from tools.base import BaseTool, ToolResult
from core.logging_config import get_logger

logger = get_logger("web_search_tool")

_ddgs_ready: Optional[bool] = None   # None = untested, True = ready, False = failed


async def _ensure_ddgs() -> bool:
    """
    Ensure the `ddgs` package (not the deprecated duckduckgo_search) is available.
    Auto-installs if missing. Returns True only when `ddgs` is confirmed working.
    """
    global _ddgs_ready

    if _ddgs_ready is True:
        return True
    if _ddgs_ready is False:
        return False

    # Test for the NEW package only — the old duckduckgo_search returns 0 results
    try:
        import ddgs  # noqa: F401
        _ddgs_ready = True
        logger.info("ddgs_ready", source="pre-installed")
        return True
    except ImportError:
        pass

    # Not present — install it
    logger.info("ddgs_installing", message="Installing ddgs...")
    try:
        proc = await asyncio.create_subprocess_exec(
            sys.executable, "-m", "pip", "install", "ddgs",
            "--quiet", "--no-warn-script-location",
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
        _, stderr = await asyncio.wait_for(proc.communicate(), timeout=120)

        if proc.returncode == 0:
            import importlib
            importlib.invalidate_caches()
            try:
                import ddgs  # noqa: F401
                _ddgs_ready = True
                logger.info("ddgs_installed_successfully")
                return True
            except ImportError:
                logger.warning("ddgs_import_failed_after_install")
        else:
            logger.warning("ddgs_install_failed", stderr=stderr.decode()[:300])
    except Exception as e:
        logger.warning("ddgs_install_error", error=str(e))

    _ddgs_ready = False
    return False


class WebSearchTool(BaseTool):
    """Search the web using DuckDuckGo via the `ddgs` package."""

    name = "web_search"
    description = "Search the web for real, current information using DuckDuckGo"
    permissions = ["network.read"]
    timeout = 60
    params_schema = {
        "query":       "str — search query (required)",
        "max_results": "int — number of results to return, default 5 (optional)",
    }

    async def execute(self, params: Dict[str, Any]) -> ToolResult:
        query       = params.get("query", "").strip()
        max_results = int(params.get("max_results", 5))

        if not query:
            return ToolResult(success=False, error="query parameter required")

        available = await _ensure_ddgs()
        if not available:
            return ToolResult(
                success=False,
                error="ddgs package unavailable. Run: pip install ddgs",
            )

        try:
            from ddgs import DDGS

            def _search():
                with DDGS() as ddgs:
                    return list(ddgs.text(query, max_results=max_results))

            raw = await asyncio.get_event_loop().run_in_executor(None, _search)
            results = [
                {
                    "title":   r.get("title", ""),
                    "url":     r.get("href", ""),
                    "snippet": r.get("body", ""),
                }
                for r in (raw or [])
            ]

            logger.info("web_search_complete", query=query[:60], results=len(results))
            return ToolResult(success=True, data={"results": results, "query": query})

        except Exception as e:
            logger.error("web_search_failed", error=str(e))
            return ToolResult(success=False, error=f"Search failed: {e}")

    async def validate_params(self, params: Dict[str, Any]) -> Optional[str]:
        if not params.get("query", "").strip():
            return "query is required"
        return None
