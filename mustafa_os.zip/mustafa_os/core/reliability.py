"""
MUSTAFA OS - Reliability Primitives
Circuit breaker, retry logic, and timeout management.
"""
from __future__ import annotations

import asyncio
import functools
import time
from enum import Enum
from typing import Any, Callable, Optional, Type, Tuple

from core.logger import get_logger

logger = get_logger("reliability")


class CircuitState(Enum):
    CLOSED = "closed"       # Normal operation
    OPEN = "open"           # Failing, reject requests
    HALF_OPEN = "half_open" # Testing if recovered


class CircuitBreaker:
    """
    Circuit breaker pattern for protecting against cascading failures.
    Thread-safe async implementation.
    """

    def __init__(
        self,
        name: str,
        failure_threshold: int = 5,
        recovery_timeout: float = 60.0,
        half_open_max_calls: int = 3,
    ):
        self.name = name
        self.failure_threshold = failure_threshold
        self.recovery_timeout = recovery_timeout
        self.half_open_max_calls = half_open_max_calls

        self._state = CircuitState.CLOSED
        self._failure_count = 0
        self._last_failure_time: Optional[float] = None
        self._half_open_calls = 0
        self._lock: Optional[asyncio.Lock] = None  # Created lazily inside an event loop

    def _get_lock(self) -> asyncio.Lock:
        """Return (creating if needed) the asyncio lock. Safe to call inside a running loop."""
        if self._lock is None:
            self._lock = asyncio.Lock()
        return self._lock

    @property
    def state(self) -> CircuitState:
        return self._state

    @property
    def is_open(self) -> bool:
        return self._state == CircuitState.OPEN

    async def _try_reset(self) -> None:
        """Check if enough time has passed to try recovery."""
        if (
            self._state == CircuitState.OPEN
            and self._last_failure_time is not None
            and (time.monotonic() - self._last_failure_time) >= self.recovery_timeout
        ):
            self._state = CircuitState.HALF_OPEN
            self._half_open_calls = 0
            logger.info(
                "Circuit breaker transitioning to HALF_OPEN",
                agent=self.name,
            )

    async def call(self, func: Callable, *args: Any, **kwargs: Any) -> Any:
        """Execute a function through the circuit breaker."""
        async with self._get_lock():
            await self._try_reset()

            if self._state == CircuitState.OPEN:
                raise CircuitOpenError(f"Circuit breaker '{self.name}' is OPEN")

            if self._state == CircuitState.HALF_OPEN:
                if self._half_open_calls >= self.half_open_max_calls:
                    raise CircuitOpenError(
                        f"Circuit breaker '{self.name}' HALF_OPEN limit reached"
                    )
                self._half_open_calls += 1

        try:
            result = await func(*args, **kwargs) if asyncio.iscoroutinefunction(func) else func(*args, **kwargs)
            await self._on_success()
            return result
        except CircuitOpenError:
            raise
        except Exception as e:
            await self._on_failure(e)
            raise

    async def _on_success(self) -> None:
        async with self._get_lock():
            self._failure_count = 0
            if self._state == CircuitState.HALF_OPEN:
                self._state = CircuitState.CLOSED
                logger.info("Circuit breaker CLOSED (recovered)", agent=self.name)

    async def _on_failure(self, exc: Exception) -> None:
        async with self._get_lock():
            self._failure_count += 1
            self._last_failure_time = time.monotonic()
            logger.warning(
                "Circuit breaker failure recorded",
                agent=self.name,
                failure_count=self._failure_count,
                error=str(exc),
            )
            if self._failure_count >= self.failure_threshold:
                self._state = CircuitState.OPEN
                logger.error(
                    "Circuit breaker OPEN — failures exceeded threshold",
                    agent=self.name,
                    threshold=self.failure_threshold,
                )

    def get_status(self) -> dict:
        return {
            "name": self.name,
            "state": self._state.value,
            "failure_count": self._failure_count,
            "last_failure_time": self._last_failure_time,
        }


class CircuitOpenError(Exception):
    """Raised when a circuit breaker is open."""
    pass


def retry(
    max_attempts: int = 3,
    backoff: float = 2.0,
    exceptions: Tuple[Type[Exception], ...] = (Exception,),
    on_retry: Optional[Callable] = None,
):
    """
    Decorator for async retry with exponential backoff.

    Usage:
        @retry(max_attempts=3, backoff=2.0)
        async def flaky_function():
            ...
    """
    def decorator(func: Callable) -> Callable:
        @functools.wraps(func)
        async def wrapper(*args: Any, **kwargs: Any) -> Any:
            last_exc: Optional[Exception] = None
            for attempt in range(1, max_attempts + 1):
                try:
                    return await func(*args, **kwargs)
                except exceptions as e:
                    last_exc = e
                    if attempt < max_attempts:
                        wait = backoff ** (attempt - 1)
                        logger.warning(
                            f"Retry {attempt}/{max_attempts} for {func.__name__}",
                            error=str(e),
                            wait_seconds=wait,
                        )
                        if on_retry:
                            on_retry(attempt, e)
                        await asyncio.sleep(wait)
                    else:
                        logger.error(
                            f"All {max_attempts} attempts failed for {func.__name__}",
                            error=str(e),
                        )
            raise last_exc  # type: ignore
        return wrapper
    return decorator


async def with_timeout(
    coro: Any,
    timeout_seconds: float,
    operation_name: str = "operation",
) -> Any:
    """
    Execute a coroutine with a timeout.
    Raises asyncio.TimeoutError with a descriptive message on timeout.
    """
    try:
        return await asyncio.wait_for(coro, timeout=timeout_seconds)
    except asyncio.TimeoutError:
        logger.error(
            f"Timeout after {timeout_seconds}s",
            operation=operation_name,
        )
        raise asyncio.TimeoutError(
            f"{operation_name} timed out after {timeout_seconds} seconds"
        )


# Global circuit breaker registry
_circuit_breakers: dict[str, CircuitBreaker] = {}


def get_circuit_breaker(name: str, **kwargs: Any) -> CircuitBreaker:
    """Get or create a named circuit breaker."""
    if name not in _circuit_breakers:
        _circuit_breakers[name] = CircuitBreaker(name=name, **kwargs)
    return _circuit_breakers[name]


def get_all_circuit_breakers() -> dict[str, dict]:
    """Get status of all circuit breakers."""
    return {name: cb.get_status() for name, cb in _circuit_breakers.items()}
