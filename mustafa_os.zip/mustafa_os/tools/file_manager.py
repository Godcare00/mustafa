"""
MUSTAFA OS - File Manager Tool
Safe file operations restricted to the data directory.
"""

from __future__ import annotations

import os
from pathlib import Path
from typing import Any, Dict, List, Optional

from tools.base import BaseTool, ToolResult


ALLOWED_BASE_DIRS = [
    "./data",
    "./data/uploads",
    "./logs",
    "./experiments",
    "./plugins",
]


def _is_safe_path(path: str) -> bool:
    """Ensure path is within allowed directories."""
    abs_path = os.path.realpath(path)
    for base in ALLOWED_BASE_DIRS:
        abs_base = os.path.realpath(base)
        if abs_path.startswith(abs_base):
            return True
    return False


class FileManagerTool(BaseTool):
    """Read, write, and manage files in allowed directories."""

    name = "file_manager"
    description = "Read, write, list, and manage files in the data directory"
    permissions = ["filesystem.read", "filesystem.write"]
    timeout = 10
    params_schema = {
        "operation": "str — 'read', 'write', or 'list' (required)",
        "path":      "str — file or directory path under ./data, ./logs, ./plugins, ./experiments, ./data/uploads (required)",
        "content":   "str — content to write (required for operation='write')",
    }

    async def execute(self, params: Dict[str, Any]) -> ToolResult:
        operation = params.get("operation", "read")
        path = params.get("path", "")

        if not path:
            return ToolResult(success=False, error="path is required")

        if not _is_safe_path(path):
            return ToolResult(
                success=False,
                error=f"Access denied: '{path}' is outside allowed directories",
            )

        try:
            if operation == "read":
                return await self._read(path)
            elif operation == "write":
                return await self._write(path, params.get("content", ""))
            elif operation == "list":
                return await self._list(path)
            elif operation == "delete":
                return await self._delete(path)
            elif operation == "exists":
                return ToolResult(success=True, data={"exists": os.path.exists(path)})
            elif operation == "append":
                return await self._append(path, params.get("content", ""))
            else:
                return ToolResult(success=False, error=f"Unknown operation: {operation}")

        except Exception as e:
            return ToolResult(success=False, error=str(e))

    async def _read(self, path: str) -> ToolResult:
        if not os.path.exists(path):
            return ToolResult(success=False, error=f"File not found: {path}")
        with open(path, "r", encoding="utf-8") as f:
            content = f.read()
        return ToolResult(success=True, data={"content": content, "path": path})

    async def _write(self, path: str, content: str) -> ToolResult:
        os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
        with open(path, "w", encoding="utf-8") as f:
            f.write(content)
        return ToolResult(success=True, data={"written": True, "path": path, "bytes": len(content)})

    async def _append(self, path: str, content: str) -> ToolResult:
        os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
        with open(path, "a", encoding="utf-8") as f:
            f.write(content)
        return ToolResult(success=True, data={"appended": True, "path": path})

    async def _list(self, path: str) -> ToolResult:
        if not os.path.exists(path):
            return ToolResult(success=False, error=f"Directory not found: {path}")
        entries = []
        for entry in os.scandir(path):
            entries.append({
                "name": entry.name,
                "is_dir": entry.is_dir(),
                "size": entry.stat().st_size if entry.is_file() else 0,
            })
        return ToolResult(success=True, data={"entries": entries, "path": path})

    async def _delete(self, path: str) -> ToolResult:
        if not os.path.exists(path):
            return ToolResult(success=False, error=f"File not found: {path}")
        os.remove(path)
        return ToolResult(success=True, data={"deleted": True, "path": path})

    async def validate_params(self, params: Dict[str, Any]) -> Optional[str]:
        if not params.get("path"):
            return "path is required"
        if not params.get("operation"):
            return "operation is required"
        return None
