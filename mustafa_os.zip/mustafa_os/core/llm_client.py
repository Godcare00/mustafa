"""
MUSTAFA OS - LLM Client
Async OpenRouter client with retry, circuit breaker, and streaming support.
"""

from __future__ import annotations

import asyncio
import time
from typing import Any, AsyncGenerator, Dict, List, Optional

import httpx

from core.settings import settings
from core.reliability import CircuitBreaker, retry_async, with_timeout
from core.logging_config import get_logger

logger = get_logger("llm_client")


class LLMMessage:
    """Represents a single message in an LLM conversation."""
    __slots__ = ("role", "content")

    def __init__(self, role: str, content: str) -> None:
        self.role = role
        self.content = content

    def to_dict(self) -> Dict[str, str]:
        return {"role": self.role, "content": self.content}


class LLMResponse:
    """Parsed LLM response."""

    def __init__(self, raw: Dict[str, Any]) -> None:
        self._raw = raw

    @property
    def content(self) -> str:
        try:
            return self._raw["choices"][0]["message"]["content"]
        except (KeyError, IndexError):
            return ""

    @property
    def model(self) -> str:
        return self._raw.get("model", "unknown")

    @property
    def usage(self) -> Dict[str, int]:
        return self._raw.get("usage", {})

    @property
    def finish_reason(self) -> str:
        try:
            return self._raw["choices"][0]["finish_reason"]
        except (KeyError, IndexError):
            return "unknown"

    def __str__(self) -> str:
        return self.content


class LLMClient:
    """
    Async LLM client with:
    - OpenRouter API integration
    - Retry with exponential backoff
    - Circuit breaker protection
    - Request/response logging
    - Token counting
    """

    def __init__(self) -> None:
        self._client: Optional[httpx.AsyncClient] = None
        self._circuit_breaker = CircuitBreaker(
            name="llm_api",
            failure_threshold=5,
            recovery_timeout=60.0,
        )
        self._total_tokens_used = 0
        self._total_requests = 0
        self._failed_requests = 0

    async def __aenter__(self) -> "LLMClient":
        await self.connect()
        return self

    async def __aexit__(self, *args) -> None:
        await self.disconnect()

    async def connect(self) -> None:
        """Initialize the HTTP client."""
        self._client = httpx.AsyncClient(
            base_url=settings.openrouter_base_url,
            headers={
                "Authorization": f"Bearer {settings.openrouter_api_key}",
                "Content-Type": "application/json",
                "HTTP-Referer": "https://mustafa-os.ai",
                "X-Title": "MUSTAFA OS",
            },
            timeout=httpx.Timeout(120.0, connect=10.0),
        )
        logger.info("llm_client_connected", base_url=settings.openrouter_base_url)

    async def disconnect(self) -> None:
        if self._client:
            await self._client.aclose()
            logger.info("llm_client_disconnected")

    @retry_async(max_attempts=3, base_delay=2.0, max_delay=30.0)
    async def complete(
        self,
        messages: List[LLMMessage],
        model: Optional[str] = None,
        max_tokens: int = 4096,
        temperature: float = 0.7,
        system_prompt: Optional[str] = None,
        timeout: float = 120.0,
    ) -> LLMResponse:
        """
        Send a completion request to the LLM.
        
        Args:
            messages: Conversation history
            model: Model identifier (defaults to settings)
            max_tokens: Maximum tokens to generate
            temperature: Sampling temperature (0=deterministic, 1=creative)
            system_prompt: Optional system message
            timeout: Request timeout in seconds
        
        Returns:
            LLMResponse with generated content
        """
        if not self._client:
            raise RuntimeError("LLM client not connected. Call connect() first.")

        model = model or settings.openrouter_default_model

        # Build message list
        all_messages = []
        if system_prompt:
            all_messages.append({"role": "system", "content": system_prompt})
        all_messages.extend([m.to_dict() for m in messages])

        payload = {
            "model": model,
            "messages": all_messages,
            "max_tokens": max_tokens,
            "temperature": temperature,
        }

        start_time = time.monotonic()
        self._total_requests += 1

        try:
            response = await self._circuit_breaker.call(
                self._make_request, payload, timeout
            )

            elapsed = time.monotonic() - start_time
            llm_response = LLMResponse(response)
            tokens = llm_response.usage.get("total_tokens", 0)
            self._total_tokens_used += tokens

            logger.debug(
                "llm_request_complete",
                model=model,
                tokens=tokens,
                elapsed_seconds=round(elapsed, 2),
                finish_reason=llm_response.finish_reason,
            )

            return llm_response

        except Exception as e:
            self._failed_requests += 1
            logger.error("llm_request_failed", model=model, error=str(e))
            raise

    async def _make_request(self, payload: Dict[str, Any], timeout: float) -> Dict[str, Any]:
        """Internal method to make the HTTP request."""
        response = await self._client.post(
            "/chat/completions",
            json=payload,
            timeout=timeout,
        )

        if response.status_code == 429:
            # Rate limited - extract retry-after if available
            retry_after = int(response.headers.get("retry-after", 5))
            await asyncio.sleep(retry_after)
            raise httpx.HTTPStatusError(
                "Rate limited", request=response.request, response=response
            )

        response.raise_for_status()
        return response.json()

    async def complete_simple(
        self,
        prompt: str,
        model: Optional[str] = None,
        max_tokens: int = 2048,
        temperature: float = 0.7,
        system_prompt: Optional[str] = None,
    ) -> str:
        """Simplified completion for single-turn prompts."""
        messages = [LLMMessage(role="user", content=prompt)]
        response = await self.complete(
            messages=messages,
            model=model,
            max_tokens=max_tokens,
            temperature=temperature,
            system_prompt=system_prompt,
        )
        return response.content

    def get_stats(self) -> Dict[str, Any]:
        """Get client usage statistics."""
        return {
            "total_requests": self._total_requests,
            "failed_requests": self._failed_requests,
            "total_tokens_used": self._total_tokens_used,
            "circuit_breaker": self._circuit_breaker.get_stats(),
            "success_rate": (
                (self._total_requests - self._failed_requests) / max(self._total_requests, 1)
            ),
        }

    async def health_check(self) -> bool:
        """Verify LLM connectivity."""
        try:
            response = await self.complete_simple(
                "Reply with 'OK' only.",
                model=settings.openrouter_fast_model,
                max_tokens=10,
                temperature=0,
            )
            return "OK" in response.upper()
        except Exception as e:
            logger.error("llm_health_check_failed", error=str(e))
            return False


# Global singleton
llm_client = LLMClient()
