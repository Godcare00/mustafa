"""
MUSTAFA OS - Orchestrator Agent
The sole public-facing agent. Thinks autonomously about every goal,
decides routing and parallelism itself, dispatches agents, and synthesizes results.
"""

from __future__ import annotations

import asyncio
import uuid
from datetime import datetime
from typing import Any, Dict, List, Optional, Tuple

from agents.base import AgentResult, BaseAgent, TaskContext
from core.database import TaskRecord, async_session_factory
from core.logging_config import get_logger
from core.registry import agent_registry
from sqlalchemy import select

logger = get_logger("orchestrator")


class OrchestratorAgent(BaseAgent):
    """
    The Orchestrator is the brain and sole entry point of MUSTAFA OS.

    Design principles:
    - No hardcoded classifiers. The LLM decides everything about routing.
    - Full system awareness: live agents, tools, and past memory injected
      into every decision prompt.
    - Parallel execution: independent steps run concurrently via asyncio.gather.
    - The orchestrator decides which steps are independent and which must be
      sequential based on dependency analysis.
    - Smart dispatch: each agent receives its strongest task type, not a generic
      "execute_step" call.
    - Pre-fetches tool data (web search results) before dispatching to agents
      so agents focus on reasoning, not retrieval.
    """

    def __init__(self) -> None:
        super().__init__(
            agent_id="orchestrator",
            name="Orchestrator Agent",
            capabilities=[
                "goal_parsing", "task_assignment", "plan_coordination",
                "tool_awareness", "agent_routing", "parallel_execution",
                "conflict_resolution", "result_aggregation",
            ],
            allowed_tools=["*"],
        )
        self._active_tasks: Dict[str, Dict[str, Any]] = {}

    # ─── Public entry point ───────────────────────────────────────────────────

    async def handle_task(self, task_type: str, context: TaskContext) -> AgentResult:
        handlers = {
            "execute_goal":  self._execute_goal,
            "task_status":   self._get_task_status,
            "system_status": self._get_system_status,
        }
        handler = handlers.get(task_type)
        if not handler:
            return AgentResult.fail(f"Unknown task type: {task_type}")
        return await handler(context)

    # ─── Main pipeline ────────────────────────────────────────────────────────

    async def _execute_goal(self, context: TaskContext) -> AgentResult:
        goal    = context.goal
        task_id = context.task_id
        self.logger.info("executing_goal", goal=goal[:100], task_id=task_id)
        await self._persist_task(task_id, goal, "running")

        try:
            # 1. Recall relevant memory
            memory_context = await self._recall_memory(goal)

            # 2. Build live system context (agents + tools)
            sys_ctx = self._build_system_context()
            self.logger.info(
                "system_context_built",
                agents=len(sys_ctx["agents"]),
                tools=len(sys_ctx["tools"]),
                memory_hits=len(memory_context),
            )

            # 3. Orchestrator decides: direct answer vs full plan
            routing = await self._decide_routing(goal, sys_ctx, memory_context)

            if routing["mode"] == "direct":
                # Orchestrator answers directly — no agents needed
                self.logger.info("direct_answer", task_id=task_id, reason=routing.get("reason", ""))
                answer = await self.think(
                    goal,
                    system_prompt=(
                        "You are MUSTAFA OS, a helpful AI assistant. "
                        "Answer directly, clearly, and concisely. "
                        "Use the user's language and be conversational when appropriate."
                    ),
                )
                await self._persist_task(task_id, goal, "completed", result={"answer": answer})
                return AgentResult.ok(data={"answer": answer}, task_id=task_id)

            # 4. Build execution plan
            await self._persist_task(task_id, goal, "planning")
            plan = await self._build_plan(goal, sys_ctx, task_id, memory_context)
            if not plan or not plan.get("steps"):
                return AgentResult.fail("Could not generate a valid execution plan")

            self.logger.info(
                "plan_built",
                task_id=task_id,
                steps=len(plan["steps"]),
                parallel_groups=plan.get("parallel_groups", []),
            )
            await self._persist_task(task_id, goal, "executing", plan=plan)

            # 5. Execute — respecting parallelism from plan
            results = await self._execute_plan(plan, sys_ctx, task_id)

            # 6. Synthesize
            final_answer = await self._synthesize(goal, results)

            # 7. Critic (non-blocking)
            critique = await self._evaluate(goal, final_answer, task_id)

            # 8. Store to memory (fire-and-forget)
            await self._store_memory(goal, final_answer, task_id)

            await self._persist_task(
                task_id, goal, "completed",
                result={"answer": final_answer, "critique": critique},
            )
            self.logger.info("goal_completed", task_id=task_id)
            return AgentResult.ok(
                data={"answer": final_answer, "plan": plan, "critique": critique},
                task_id=task_id,
            )

        except Exception as e:
            await self._persist_task(task_id, goal, "failed", error=str(e))
            self.logger.error("goal_failed", task_id=task_id, error=str(e))
            return AgentResult.fail(str(e), task_id=task_id)

    # ─── Routing decision ─────────────────────────────────────────────────────

    async def _decide_routing(
        self,
        goal: str,
        sys_ctx: Dict[str, Any],
        memory_context: List[Dict[str, Any]],
    ) -> Dict[str, Any]:
        """
        The orchestrator decides autonomously:
          - "direct": answer without agents (conversation, simple facts)
          - "plan": build and execute a multi-agent plan

        No hardcoded rules. The LLM reads the goal, available agents,
        and memory, then makes the call.
        """
        agent_list = ", ".join(a["id"] for a in sys_ctx["agents"])
        tool_list  = ", ".join(t["name"] for t in sys_ctx["tools"])
        mem_summary = "; ".join([m.get("content", "")[:100] for m in memory_context[:2]])

        decision = await self.think_json(
            f"""You are MUSTAFA OS Orchestrator. Decide how to handle this goal.

GOAL: {goal}

AVAILABLE AGENTS: {agent_list}
AVAILABLE TOOLS: {tool_list}
RELEVANT PAST EXPERIENCE: {mem_summary or "none"}

Choose routing mode:
- "direct": use when the goal is conversational (greeting, chitchat), a simple factual
  question answerable from knowledge (no tools needed), or a clarification request.
- "plan": use when the goal requires action (create, build, write, search, scan,
  analyze, execute, install, research), produces a file/code/report, needs tools,
  or requires multiple steps.

Return ONLY JSON:
{{
  "mode": "direct" | "plan",
  "reason": "one sentence explanation",
  "estimated_steps": 0
}}"""
        )
        return decision

    # ─── System context ───────────────────────────────────────────────────────

    def _build_system_context(self) -> Dict[str, Any]:
        """Live snapshot of every available agent and tool."""
        agents = []
        for info in agent_registry.get_all_agents():
            if info.agent_id == "orchestrator":
                continue
            agents.append({
                "id":           info.agent_id,
                "name":         info.name,
                "status":       info.status,
                "capabilities": info.capabilities,
                "available":    info.status == "idle",
            })

        tools = []
        try:
            from tools import get_tool_engine
            for t in get_tool_engine().get_all_tools():
                tools.append({
                    "name":        t.name,
                    "description": t.description,
                    "permissions": t.permissions,
                })
        except Exception:
            pass

        return {"agents": agents, "tools": tools}

    def _agent_ids(self, sys_ctx: Dict[str, Any]) -> List[str]:
        return [a["id"] for a in sys_ctx["agents"]]

    # ─── Plan building ────────────────────────────────────────────────────────

    async def _build_plan(
        self,
        goal: str,
        sys_ctx: Dict[str, Any],
        task_id: str,
        memory_context: List[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """
        Ask the Planner to build a plan with full context.
        Falls back to self-planning if Planner is unavailable.
        The plan includes parallel_groups — lists of step_ids that can run
        concurrently because they have no dependencies on each other.
        """
        planner = agent_registry.get_agent("planner")
        if planner and planner.instance and planner.status == "idle":
            try:
                ctx = TaskContext(
                    task_id=task_id,
                    goal=goal,
                    payload={
                        "goal":             goal,
                        "task_id":          task_id,
                        "available_agents": sys_ctx["agents"],
                        "available_tools":  sys_ctx["tools"],
                        "memory_context":   memory_context or [],
                    },
                    sender=self.agent_id,
                )
                result = await asyncio.wait_for(
                    planner.instance.handle_task("create_plan", ctx), timeout=60
                )
                if result.success and result.data and result.data.get("steps"):
                    plan = self._validate_and_annotate_plan(result.data, sys_ctx)
                    return plan
            except Exception as e:
                self.logger.warning("planner_unavailable", error=str(e))

        return await self._self_plan(goal, sys_ctx, memory_context or [])

    async def _self_plan(
        self,
        goal: str,
        sys_ctx: Dict[str, Any],
        memory_context: List[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """Orchestrator builds the plan itself with full context."""
        agent_list = "\n".join([
            f"  - {a['id']} ({a['name']}): capabilities={a['capabilities']}"
            for a in sys_ctx["agents"]
        ])
        tool_list = "\n".join([
            f"  - {t['name']}: {t['description']}"
            for t in sys_ctx["tools"]
        ])
        memory_str = ""
        if memory_context:
            memory_str = "\nRELEVANT PAST EXPERIENCE:\n" + "\n".join([
                f"  - {m.get('content', '')[:150]}"
                for m in memory_context[:3]
            ])

        plan = await self.think_json(f"""You are MUSTAFA OS Orchestrator. Build an execution plan.

GOAL: {goal}
{memory_str}
AVAILABLE AGENTS (use ONLY these exact IDs):
{agent_list}

AVAILABLE TOOLS (use ONLY these exact names):
{tool_list}

Rules:
- Use ONLY the agent IDs listed above. Never invent names.
- Assign each step to the most capable agent for that work.
- Steps with empty depends_on=[] are independent and WILL run in parallel.
- Steps that need results from other steps must list those step_ids in depends_on.
- Do NOT assign steps to "orchestrator".
- 1-6 steps maximum.

Return ONLY JSON (no markdown):
{{
  "goal": "{goal}",
  "steps": [
    {{
      "step_id": 1,
      "description": "specific concrete action",
      "agent": "agent_id",
      "tools": ["tool_name"],
      "depends_on": [],
      "timeout": 90
    }}
  ],
  "parallel_groups": [[1, 2], [3]],
  "complexity": "low|medium|high"
}}

parallel_groups: group step_ids that can run at the same time.
Example: [[1,2],[3]] means steps 1 and 2 run in parallel, then step 3 runs after both complete.""")
        return self._validate_and_annotate_plan(plan, sys_ctx)

    def _validate_and_annotate_plan(
        self, plan: Dict[str, Any], sys_ctx: Dict[str, Any]
    ) -> Dict[str, Any]:
        """
        1. Replace hallucinated agent IDs with real ones.
        2. If parallel_groups is missing, compute it from depends_on.
        """
        valid_ids = set(self._agent_ids(sys_ctx))
        for step in plan.get("steps", []):
            agent_id = step.get("agent", "")
            if agent_id not in valid_ids:
                replacement = self._pick_agent_for_step(step, sys_ctx)
                self.logger.warning(
                    "hallucinated_agent_replaced",
                    original=agent_id,
                    replacement=replacement,
                    step=step.get("step_id"),
                )
                step["agent"] = replacement

        # Compute parallel_groups if not provided by planner
        if not plan.get("parallel_groups"):
            plan["parallel_groups"] = self._compute_parallel_groups(plan.get("steps", []))

        return plan

    def _compute_parallel_groups(
        self, steps: List[Dict[str, Any]]
    ) -> List[List[int]]:
        """
        Derive execution groups from depends_on relationships.
        Steps with no dependencies or whose dependencies are all in
        earlier groups can run in the same wave.

        Returns: [[step_ids in wave 0], [step_ids in wave 1], ...]
        """
        if not steps:
            return []

        step_map = {s["step_id"]: s for s in steps}
        assigned: Dict[int, int] = {}  # step_id → wave index

        def wave_of(step_id: int) -> int:
            if step_id in assigned:
                return assigned[step_id]
            step = step_map.get(step_id)
            if not step or not step.get("depends_on"):
                assigned[step_id] = 0
                return 0
            w = max(wave_of(dep) for dep in step["depends_on"]) + 1
            assigned[step_id] = w
            return w

        for s in steps:
            wave_of(s["step_id"])

        max_wave = max(assigned.values(), default=0)
        groups = []
        for w in range(max_wave + 1):
            group = [sid for sid, wv in assigned.items() if wv == w]
            if group:
                groups.append(sorted(group))
        return groups

    # ─── Intelligent routing ──────────────────────────────────────────────────

    def _pick_agent_for_step(
        self, step: Dict[str, Any], sys_ctx: Dict[str, Any]
    ) -> str:
        """Fallback router when an agent ID is invalid or unavailable."""
        description = (step.get("description", "") + " " + step.get("agent", "")).lower()
        tools_needed = [t.lower() for t in step.get("tools", [])]
        all_ids = {a["id"] for a in sys_ctx["agents"]}

        routing_rules: List[Tuple[List[str], str]] = [
            (["secur", "hack", "pentest", "exploit", "vulnerab", "malware",
              "ctf", "cve", "osint", "nmap", "scan", "recon"],          "cybersecurity"),
            (["code", "script", "function", "python", "implement",
              "program", "debug", "module", "class", "api"],            "developer"),
            (["test", "unit test", "verify", "coverage", "pytest"],     "testing"),
            (["review", "evaluate", "critique", "quality", "score",
              "validate"],                                               "critic"),
            (["research", "search", "web", "find", "look up", "fetch",
              "news", "information", "data", "article"],                 "research"),
            (["memory", "store", "retrieve", "remember", "knowledge"],  "memory_agent"),
            (["monitor", "metric", "health", "status", "alert"],        "monitoring_agent"),
            (["evolve", "improve", "experiment", "optimise"],           "evolution"),
            (["plan", "strategy", "steps", "workflow"],                 "planner"),
        ]

        tool_to_agent = {
            "web_search":      "research",
            "api_request":     "research",
            "code_executor":   "developer",
            "file_manager":    "developer",
            "database_query":  "developer",
            "data_analysis":   "research",
            "memory_search":   "memory_agent",
            "system_metrics":  "monitoring_agent",
            "shell_executor":  "developer",
        }

        for tool in tools_needed:
            candidate = tool_to_agent.get(tool)
            if candidate and candidate in all_ids:
                return candidate

        for keywords, agent_id in routing_rules:
            if agent_id in all_ids and any(kw in description for kw in keywords):
                return agent_id

        for fallback in ("research", "developer", "planner"):
            if fallback in all_ids:
                return fallback

        return list(all_ids)[0] if all_ids else "research"

    # ─── Plan execution with parallelism ─────────────────────────────────────

    async def _execute_plan(
        self, plan: Dict[str, Any], sys_ctx: Dict[str, Any], task_id: str
    ) -> List[Dict[str, Any]]:
        """
        Execute steps in parallel waves.

        Each wave = a group of steps with no inter-dependencies within the group.
        Steps in the same wave run concurrently via asyncio.gather.
        The next wave only starts when all steps in the current wave complete.
        """
        steps     = {s["step_id"]: s for s in plan.get("steps", [])}
        groups    = plan.get("parallel_groups") or self._compute_parallel_groups(list(steps.values()))
        results: List[Dict[str, Any]] = []
        completed: Dict[int, Dict[str, Any]] = {}

        self.logger.info(
            "executing_plan",
            total_steps=len(steps),
            parallel_groups=groups,
            task_id=task_id,
        )

        for wave_idx, group in enumerate(groups):
            wave_steps = [steps[sid] for sid in group if sid in steps]

            # Validate all depends_on are satisfied
            runnable = []
            for step in wave_steps:
                unmet = [d for d in step.get("depends_on", []) if d not in completed]
                if unmet:
                    self.logger.warning(
                        "step_skipped_unmet_deps",
                        step_id=step["step_id"], unmet=unmet
                    )
                    results.append({
                        "step": step,
                        "result": {"success": False, "error": f"Unmet dependencies: {unmet}"},
                    })
                else:
                    # Validate agent exists, re-route if not
                    agent_id = step.get("agent", "")
                    if not agent_registry.get_agent(agent_id):
                        new_id = self._pick_agent_for_step(step, sys_ctx)
                        self.logger.info("agent_rerouted", from_agent=agent_id, to_agent=new_id)
                        step["agent"] = new_id
                    runnable.append(step)

            if not runnable:
                continue

            if len(runnable) == 1:
                # Sequential — no overhead
                self.logger.info(
                    "wave_sequential",
                    wave=wave_idx,
                    step_id=runnable[0]["step_id"],
                    agent=runnable[0]["agent"],
                )
                result = await self._dispatch_step(runnable[0], task_id)
                results.append({"step": runnable[0], "result": result})
                completed[runnable[0]["step_id"]] = result
            else:
                # Parallel — run all steps in wave concurrently
                self.logger.info(
                    "wave_parallel",
                    wave=wave_idx,
                    step_ids=[s["step_id"] for s in runnable],
                    agents=[s["agent"] for s in runnable],
                )
                wave_results = await asyncio.gather(
                    *[self._dispatch_step(step, task_id) for step in runnable],
                    return_exceptions=True,
                )
                for step, result in zip(runnable, wave_results):
                    if isinstance(result, Exception):
                        result = {"success": False, "error": str(result)}
                    results.append({"step": step, "result": result})
                    completed[step["step_id"]] = result

            # Log wave completion
            wave_success = sum(1 for r in results[-len(runnable):] if r["result"].get("success"))
            self.logger.info(
                "wave_complete",
                wave=wave_idx,
                succeeded=wave_success,
                total=len(runnable),
            )

        return results

    # ─── Agent → task type mapping ────────────────────────────────────────────

    _AGENT_TASK_TYPE: Dict[str, str] = {
        "research":         "research",
        "developer":        "write_code",
        "testing":          "write_tests",
        "critic":           "evaluate",
        "memory_agent":     "retrieve_memory",
        "planner":          "create_plan",
        "tool_manager":     "list_tools",
        "monitoring_agent": "get_health",
        "evolution":        "run_evolution_cycle",
        "cybersecurity":    "security_analysis",
    }

    async def _dispatch_step(
        self, step: Dict[str, Any], task_id: str
    ) -> Dict[str, Any]:
        """
        Dispatch a step to its agent using the correct task type.
        Pre-fetches web data if the step needs it.
        """
        agent_id     = step.get("agent", "research")
        description  = step.get("description", "")
        tools_needed = step.get("tools", [])
        timeout      = max(step.get("timeout", 120), 90)
        task_type    = self._AGENT_TASK_TYPE.get(agent_id, "execute_step")

        self.logger.info(
            "dispatching_step",
            step_id=step.get("step_id"),
            agent=agent_id,
            task_type=task_type,
            description=description[:80],
            tools=tools_needed,
        )

        from core.kernel import kernel
        agent_instance = kernel.get_agent(agent_id)
        if not agent_instance:
            return {"success": False, "error": f"Agent '{agent_id}' not found"}

        # Pre-fetch tool data so agents get enriched context
        enriched_context = description
        tool_results: Dict[str, Any] = {}

        if "web_search" in tools_needed or "api_request" in tools_needed:
            tool_results["web_search"] = await self._call_tool(
                "web_search", {"query": description, "max_results": 5}
            )
            web_data = tool_results["web_search"]
            if web_data.get("success") and web_data.get("data", {}).get("results"):
                snippets = "\n".join([
                    f"- {r.get('title','')}: {r.get('snippet','')}"
                    for r in web_data["data"]["results"][:5]
                ])
                enriched_context = f"{description}\n\nWeb search results:\n{snippets}"

        if "memory_search" in tools_needed:
            tool_results["memory"] = await self._call_tool(
                "memory_search", {"query": description, "top_k": 3}
            )

        try:
            ctx = TaskContext(
                task_id=task_id,
                goal=enriched_context,
                payload={
                    "goal":          enriched_context,
                    "original_goal": description,
                    "task_id":       task_id,
                    "tools":         tools_needed,
                    "tool_results":  tool_results,
                    "step":          step,
                    "code":          step.get("code", ""),
                    "answer":        step.get("answer", ""),
                    "target":        step.get("target", ""),
                },
                sender=self.agent_id,
            )
            result = await asyncio.wait_for(
                agent_instance.handle_task(task_type, ctx),
                timeout=timeout,
            )
            return result.to_dict()

        except asyncio.TimeoutError:
            self.logger.error("step_timeout", step_id=step.get("step_id"), timeout=timeout)
            return {"success": False, "error": f"Step timed out after {timeout}s"}
        except Exception as e:
            self.logger.error("step_dispatch_failed", error=str(e))
            return {"success": False, "error": str(e)}

    async def _call_tool(
        self, tool_name: str, params: Dict[str, Any]
    ) -> Dict[str, Any]:
        """Call a tool directly from the orchestrator."""
        try:
            from tools import get_tool_engine
            result = await asyncio.wait_for(
                get_tool_engine().execute(tool_name, self.agent_id, params),
                timeout=20,
            )
            return result.to_dict()
        except Exception as e:
            return {"success": False, "error": str(e)}

    # ─── Memory ───────────────────────────────────────────────────────────────

    async def _recall_memory(self, goal: str) -> List[Dict[str, Any]]:
        try:
            from memory.long_term import LongTermMemory
            mem = LongTermMemory()
            if not mem.is_available:
                await mem.initialize()
            results = await mem.search(query=goal, collection="task_history", top_k=3)
            if results:
                self.logger.debug("memory_recalled", hits=len(results))
            return results
        except Exception:
            return []

    # ─── Synthesis ────────────────────────────────────────────────────────────

    async def _synthesize(self, goal: str, results: List[Dict[str, Any]]) -> str:
        summary_parts = []
        for i, r in enumerate(results):
            step   = r.get("step", {})
            res    = r.get("result", {})
            ok     = res.get("success", False)
            data   = res.get("data") or {}
            if isinstance(data, dict):
                content = (
                    data.get("analysis") or
                    data.get("findings") or
                    data.get("response") or
                    data.get("result") or
                    data.get("answer") or
                    data.get("summary") or
                    data.get("code") or
                    data.get("osint_report") or
                    data.get("security_review") or
                    data.get("assessment") or
                    data.get("cve_report") or
                    data.get("interpretation") or
                    str(data)
                )
            else:
                content = str(data) if data else res.get("error", "no output")

            summary_parts.append(
                f"Step {i+1} [{step.get('agent','?')}] — "
                f"{'OK' if ok else 'FAILED'}: {str(content)[:600]}"
            )

        return await self.think(
            f"""Synthesize the following results into a complete, user-facing answer.

ORIGINAL GOAL: {goal}

RESULTS:
{chr(10).join(summary_parts)}

Instructions:
- Directly and fully address the original goal.
- Be specific, accurate, and actionable.
- Use formatting (lists, code blocks) where it improves clarity.
- If steps failed, work with what succeeded and note any gaps.
- Do NOT describe your process. Just deliver the answer.""",
            system_prompt=(
                "You are MUSTAFA OS delivering a final result. "
                "Be direct, complete, and helpful."
            ),
        )

    async def _evaluate(self, goal: str, answer: str, task_id: str) -> Dict[str, Any]:
        try:
            from core.kernel import kernel
            critic = kernel.get_agent("critic")
            if critic:
                ctx = TaskContext(
                    task_id=task_id, goal=goal,
                    payload={"goal": goal, "answer": answer, "task_id": task_id},
                    sender=self.agent_id,
                )
                result = await asyncio.wait_for(
                    critic.handle_task("evaluate", ctx), timeout=45
                )
                if result.success and result.data:
                    return result.data
        except Exception as e:
            self.logger.debug("critique_skipped", reason=str(e))
        return {"score": 0.8, "verdict": "accept"}

    async def _store_memory(self, goal: str, answer: str, task_id: str) -> None:
        try:
            from core.kernel import kernel
            mem = kernel.get_agent("memory_agent")
            if mem:
                ctx = TaskContext(
                    task_id=task_id, goal=goal,
                    payload={
                        "goal": goal, "result": answer,
                        "task_id": task_id, "collection": "task_history",
                    },
                    sender=self.agent_id,
                )
                asyncio.create_task(mem.handle_task("store_memory", ctx))
        except Exception:
            pass

    # ─── Status / utility ─────────────────────────────────────────────────────

    async def _get_task_status(self, context: TaskContext) -> AgentResult:
        task_id = context.payload.get("task_id")
        if not task_id:
            return AgentResult.fail("task_id required")
        async with async_session_factory() as session:
            result = await session.execute(
                select(TaskRecord).where(TaskRecord.id == task_id)
            )
            task = result.scalar_one_or_none()
        if not task:
            return AgentResult.fail(f"Task {task_id} not found")
        return AgentResult.ok({
            "task_id":    task.id,
            "status":     task.status,
            "goal":       task.goal,
            "result":     task.result,
            "created_at": task.created_at.isoformat(),
        })

    async def _get_system_status(self, context: TaskContext) -> AgentResult:
        ctx = self._build_system_context()
        ctx["registry"] = agent_registry.get_system_summary()
        return AgentResult.ok(ctx)

    async def _persist_task(
        self, task_id: str, goal: str, status: str,
        plan: Optional[Dict] = None,
        result: Optional[Dict] = None,
        error: Optional[str] = None,
    ) -> None:
        try:
            async with async_session_factory() as session:
                existing = await session.get(TaskRecord, task_id)
                if existing:
                    existing.status = status
                    if plan:   existing.plan   = plan
                    if result: existing.result = result
                    if error:  existing.error  = error
                    if status == "completed":
                        existing.completed_at = datetime.utcnow()
                else:
                    session.add(TaskRecord(
                        id=task_id, goal=goal, status=status,
                        assigned_agent=self.agent_id,
                        plan=plan, result=result, error=error,
                    ))
                await session.commit()
        except Exception as e:
            self.logger.error("task_persist_failed", error=str(e))
