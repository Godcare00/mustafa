"""
MUSTAFA OS - Data Analysis Tool
Statistical analysis and data transformation operations.
"""

from __future__ import annotations

import json
import statistics
from typing import Any, Dict, List, Optional, Union

from tools.base import BaseTool, ToolResult


class DataAnalysisTool(BaseTool):
    name = "data_analysis"
    description = "Perform statistical analysis and data transformations"
    permissions = ["compute"]
    timeout = 60

    async def execute(self, params: Dict[str, Any]) -> ToolResult:
        operation = params.get("operation", "stats")
        data = params.get("data", [])
        extra = params.get("params", {})

        try:
            if operation == "stats":
                return self._compute_stats(data)
            elif operation == "aggregate":
                return self._aggregate(data, extra)
            elif operation == "transform":
                return self._transform(data, extra)
            elif operation == "correlate":
                return self._correlate(data)
            elif operation == "filter":
                return self._filter_data(data, extra)
            else:
                return ToolResult(success=False, error=f"Unknown operation: {operation}")
        except Exception as e:
            return ToolResult(success=False, error=str(e))

    def _compute_stats(self, data: Union[List, Dict]) -> ToolResult:
        """Compute descriptive statistics."""
        if isinstance(data, dict):
            nums = [v for v in data.values() if isinstance(v, (int, float))]
        elif isinstance(data, list):
            nums = [x for x in data if isinstance(x, (int, float))]
        else:
            return ToolResult(success=False, error="Data must be list or dict of numbers")

        if not nums:
            return ToolResult(success=False, error="No numeric data found")

        result = {
            "count": len(nums),
            "min": min(nums),
            "max": max(nums),
            "mean": statistics.mean(nums),
            "median": statistics.median(nums),
            "sum": sum(nums),
        }
        if len(nums) > 1:
            result["stdev"] = statistics.stdev(nums)
            result["variance"] = statistics.variance(nums)

        return ToolResult(success=True, data={"stats": result})

    def _aggregate(self, data: List[Dict], params: Dict) -> ToolResult:
        """Group and aggregate data."""
        group_by = params.get("group_by")
        agg_field = params.get("field")
        agg_func = params.get("func", "sum")

        if not group_by or not agg_field:
            return ToolResult(success=False, error="group_by and field required")

        groups: Dict[str, List] = {}
        for row in data:
            key = str(row.get(group_by, "unknown"))
            val = row.get(agg_field, 0)
            groups.setdefault(key, []).append(val)

        result = {}
        for key, vals in groups.items():
            nums = [v for v in vals if isinstance(v, (int, float))]
            if agg_func == "sum":
                result[key] = sum(nums)
            elif agg_func == "mean":
                result[key] = statistics.mean(nums) if nums else 0
            elif agg_func == "count":
                result[key] = len(nums)
            elif agg_func == "max":
                result[key] = max(nums) if nums else 0
            elif agg_func == "min":
                result[key] = min(nums) if nums else 0

        return ToolResult(success=True, data={"aggregated": result})

    def _transform(self, data: List, params: Dict) -> ToolResult:
        """Apply transformations to data."""
        transform_type = params.get("type", "normalize")

        if transform_type == "normalize" and data:
            nums = [x for x in data if isinstance(x, (int, float))]
            if nums:
                mn, mx = min(nums), max(nums)
                rng = mx - mn or 1
                normalized = [(x - mn) / rng for x in nums]
                return ToolResult(success=True, data={"transformed": normalized})

        elif transform_type == "flatten" and isinstance(data, list):
            flat = []
            for item in data:
                if isinstance(item, list):
                    flat.extend(item)
                else:
                    flat.append(item)
            return ToolResult(success=True, data={"transformed": flat})

        return ToolResult(success=True, data={"transformed": data})

    def _correlate(self, data: Dict[str, List]) -> ToolResult:
        """Compute correlation between two series."""
        keys = list(data.keys())
        if len(keys) < 2:
            return ToolResult(success=False, error="Need at least 2 data series")

        x = data[keys[0]]
        y = data[keys[1]]

        if len(x) != len(y):
            return ToolResult(success=False, error="Series must have equal length")

        n = len(x)
        mean_x = sum(x) / n
        mean_y = sum(y) / n
        num = sum((xi - mean_x) * (yi - mean_y) for xi, yi in zip(x, y))
        den_x = (sum((xi - mean_x) ** 2 for xi in x)) ** 0.5
        den_y = (sum((yi - mean_y) ** 2 for yi in y)) ** 0.5
        corr = num / (den_x * den_y) if den_x * den_y != 0 else 0

        return ToolResult(success=True, data={"correlation": round(corr, 4), "series": keys})

    def _filter_data(self, data: List[Dict], params: Dict) -> ToolResult:
        """Filter data rows by condition."""
        field = params.get("field")
        operator = params.get("operator", "eq")
        value = params.get("value")

        filtered = []
        for row in data:
            row_val = row.get(field)
            if operator == "eq" and row_val == value:
                filtered.append(row)
            elif operator == "gt" and isinstance(row_val, (int, float)) and row_val > value:
                filtered.append(row)
            elif operator == "lt" and isinstance(row_val, (int, float)) and row_val < value:
                filtered.append(row)
            elif operator == "contains" and isinstance(row_val, str) and value in row_val:
                filtered.append(row)

        return ToolResult(success=True, data={"filtered": filtered, "count": len(filtered)})


# ─── Code Executor Tool ───────────────────────────────────────────────────────

class CodeExecutorTool(BaseTool):
    """Execute sandboxed Python code safely."""

    name = "code_executor"
    description = "Execute sandboxed Python code with safety restrictions"
    permissions = ["compute", "sandbox"]
    timeout = 30

    # Safe builtins allowed in sandbox
    SAFE_BUILTINS = {
        "abs", "all", "any", "bin", "bool", "chr", "dict", "dir",
        "divmod", "enumerate", "filter", "float", "format", "frozenset",
        "getattr", "hasattr", "hash", "hex", "int", "isinstance",
        "issubclass", "iter", "len", "list", "map", "max", "min",
        "next", "oct", "ord", "pow", "print", "range", "repr",
        "reversed", "round", "set", "slice", "sorted", "str", "sum",
        "tuple", "type", "zip", "None", "True", "False",
    }

    async def execute(self, params: Dict[str, Any]) -> ToolResult:
        import asyncio, io, sys, time as t

        code = params.get("code", "")
        if not code:
            return ToolResult(success=False, error="code is required")

        from core.settings import settings
        if not settings.enable_code_sandbox:
            return ToolResult(success=False, error="Code execution is disabled")

        # Capture stdout
        old_stdout = sys.stdout
        sys.stdout = buffer = io.StringIO()

        start = t.monotonic()
        return_value = None
        stderr_output = ""

        try:
            # Build restricted globals
            safe_globals: Dict[str, Any] = {
                "__builtins__": {k: getattr(__builtins__, k, None) if isinstance(__builtins__, object) else __builtins__.get(k) 
                                 for k in self.SAFE_BUILTINS},
                "math": __import__("math"),
                "json": __import__("json"),
                "re": __import__("re"),
                "datetime": __import__("datetime"),
                "statistics": __import__("statistics"),
                "collections": __import__("collections"),
                "itertools": __import__("itertools"),
                "random": __import__("random"),
            }

            local_vars: Dict[str, Any] = {}
            exec(compile(code, "<sandbox>", "exec"), safe_globals, local_vars)  # noqa: S102
            return_value = local_vars.get("result") or local_vars.get("output")

        except Exception as e:
            stderr_output = str(e)
        finally:
            sys.stdout = old_stdout

        elapsed = t.monotonic() - start
        stdout_output = buffer.getvalue()

        success = not stderr_output
        return ToolResult(
            success=success,
            data={
                "stdout": stdout_output,
                "stderr": stderr_output,
                "return_value": str(return_value) if return_value is not None else None,
                "execution_time": round(elapsed, 4),
            },
            error=stderr_output if stderr_output else None,
        )

    async def validate_params(self, params: Dict[str, Any]) -> Optional[str]:
        if not params.get("code"):
            return "code is required"

        # Dangerous pattern check
        dangerous = [
            "__import__", "import os", "import sys", "subprocess",
            "open(", "exec(", "eval(", "compile(", "globals()", "locals()",
            "__class__", "__bases__", "__subclasses__",
        ]
        code = params.get("code", "")
        for pattern in dangerous:
            if pattern in code:
                return f"Code contains disallowed pattern: {pattern}"
        return None
