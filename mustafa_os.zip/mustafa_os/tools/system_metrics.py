"""
MUSTAFA OS - System Metrics Tool
Exposes live system health and performance metrics to agents.
"""
from __future__ import annotations
from datetime import datetime
from typing import Any, Dict, Optional
from tools.base import BaseTool, ToolResult


class SystemMetricsTool(BaseTool):
    name = "system_metrics"
    description = "Retrieve system performance and health metrics"
    permissions = ["monitoring.read"]
    timeout = 5

    async def execute(self, params: Dict[str, Any]) -> ToolResult:
        metric_type = params.get("metric_type", "all")

        try:
            from core.registry import agent_registry
            from core.llm_client import llm_client

            metrics: Dict[str, Any] = {"timestamp": datetime.utcnow().isoformat()}

            if metric_type in ("agents", "all"):
                metrics["agents"] = agent_registry.get_system_summary()

            if metric_type in ("llm", "all"):
                metrics["llm"] = llm_client.get_stats()

            if metric_type in ("system", "all"):
                try:
                    import psutil
                    metrics["system"] = {
                        "cpu_percent": psutil.cpu_percent(interval=0.1),
                        "memory_percent": psutil.virtual_memory().percent,
                        "memory_available_mb": psutil.virtual_memory().available // (1024 * 1024),
                        "disk_percent": psutil.disk_usage("/").percent,
                    }
                except ImportError:
                    metrics["system"] = {"note": "psutil not installed"}

            if metric_type in ("tasks", "all"):
                try:
                    from api.app import _active_tasks
                    task_counts = {"total": len(_active_tasks)}
                    for s in ("pending", "running", "completed", "failed"):
                        task_counts[s] = sum(1 for t in _active_tasks.values() if t.get("status") == s)
                    metrics["tasks"] = task_counts
                except Exception:
                    metrics["tasks"] = {}

            return ToolResult(success=True, data=metrics)

        except Exception as e:
            return ToolResult(success=False, error=str(e))
