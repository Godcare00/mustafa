"""
MUSTAFA OS - Monitoring & Observability
Collects system metrics, tracks agent performance,
and generates structured health reports.
"""
from __future__ import annotations

import asyncio
import time
from dataclasses import dataclass, field, asdict
from typing import Any, Dict, List, Optional

from core.database import get_db
from core.logger import get_logger
from core.reliability import get_all_circuit_breakers

logger = get_logger("monitoring")


@dataclass
class AgentMetrics:
    """Performance metrics for a single agent."""
    agent_name: str
    tasks_completed: int = 0
    tasks_failed: int = 0
    avg_latency_ms: float = 0.0
    p95_latency_ms: float = 0.0
    error_rate: float = 0.0
    last_active: Optional[float] = None
    status: str = "idle"


@dataclass
class ToolMetrics:
    """Performance metrics for a single tool."""
    tool_name: str
    calls: int = 0
    successes: int = 0
    failures: int = 0
    avg_latency_ms: float = 0.0
    success_rate: float = 0.0


@dataclass
class SystemSnapshot:
    """Complete system metrics snapshot."""
    timestamp: float = field(default_factory=time.time)
    overall_status: str = "healthy"
    uptime_seconds: float = 0.0
    total_tasks: int = 0
    completed_tasks: int = 0
    failed_tasks: int = 0
    pending_tasks: int = 0
    task_success_rate: float = 0.0
    agents: List[Dict] = field(default_factory=list)
    tools: List[Dict] = field(default_factory=list)
    circuit_breakers: Dict = field(default_factory=dict)
    alerts: List[str] = field(default_factory=list)


class MetricsCollector:
    """
    Collects and aggregates system metrics from all components.
    Runs as a background task, writing to the database.
    """

    def __init__(self, collection_interval: float = 60.0):
        self._interval = collection_interval
        self._running = False
        self._task: Optional[asyncio.Task] = None
        self._start_time = time.time()

    async def start(self) -> None:
        """Start background metrics collection."""
        self._running = True
        self._task = asyncio.create_task(self._collection_loop())
        logger.info("Metrics collector started", interval=self._interval)

    async def stop(self) -> None:
        """Stop background collection."""
        self._running = False
        if self._task:
            self._task.cancel()
            try:
                await self._task
            except asyncio.CancelledError:
                pass
        logger.info("Metrics collector stopped")

    async def _collection_loop(self) -> None:
        """Background loop that collects metrics on an interval."""
        while self._running:
            try:
                await self._collect_and_store()
            except Exception as e:
                logger.error("Metrics collection error", error=str(e))
            await asyncio.sleep(self._interval)

    async def _collect_and_store(self) -> None:
        """Collect all metrics and write to database."""
        db = await get_db()
        now = time.time()

        try:
            # Task metrics
            tasks = await db.list_tasks(limit=1000)
            total = len(tasks)
            completed = sum(1 for t in tasks if t["status"] == "completed")
            failed = sum(1 for t in tasks if t["status"] == "failed")
            pending = sum(1 for t in tasks if t["status"] in ("pending", "running"))

            await db.record_metric("system.tasks.total", float(total))
            await db.record_metric("system.tasks.completed", float(completed))
            await db.record_metric("system.tasks.failed", float(failed))
            await db.record_metric("system.tasks.pending", float(pending))

            if total > 0:
                success_rate = completed / total * 100
                await db.record_metric("system.tasks.success_rate", success_rate)

            # Circuit breaker states
            cbs = get_all_circuit_breakers()
            open_count = sum(1 for cb in cbs.values() if cb["state"] == "open")
            await db.record_metric("system.circuit_breakers.open", float(open_count))

            logger.debug(
                "Metrics collected",
                tasks=total,
                success_rate=round(completed / max(total, 1) * 100, 1),
                circuit_breakers_open=open_count,
            )
        except Exception as e:
            logger.error("Metrics store failed", error=str(e))

    async def get_snapshot(self, kernel: Any = None) -> SystemSnapshot:
        """Generate a complete system metrics snapshot."""
        db = await get_db()
        now = time.time()

        # Task stats
        tasks = await db.list_tasks(limit=500)
        total = len(tasks)
        completed = sum(1 for t in tasks if t["status"] == "completed")
        failed = sum(1 for t in tasks if t["status"] == "failed")
        pending = sum(1 for t in tasks if t["status"] in ("pending", "running"))
        success_rate = round(completed / max(total, 1) * 100, 1)

        # Agent stats
        agents_data = []
        if kernel and kernel._registry:
            for a in kernel._registry.list_agents():
                stats = a.get("stats", {})
                agents_data.append({
                    "name": a["name"],
                    "status": a["status"],
                    "tasks_completed": stats.get("tasks_completed", 0),
                    "tasks_failed": stats.get("tasks_failed", 0),
                    "avg_latency_ms": stats.get("avg_latency_ms", 0),
                })

        # Circuit breakers
        cbs = get_all_circuit_breakers()

        # Determine overall status
        alerts = []
        overall = "healthy"

        if failed > 0 and total > 0 and (failed / total) > 0.3:
            alerts.append(f"High task failure rate: {round(failed/total*100,1)}%")
            overall = "degraded"

        open_cbs = [name for name, cb in cbs.items() if cb["state"] == "open"]
        if open_cbs:
            alerts.append(f"Circuit breakers OPEN: {', '.join(open_cbs)}")
            overall = "degraded"

        uptime = now - self._start_time

        snapshot = SystemSnapshot(
            timestamp=now,
            overall_status=overall,
            uptime_seconds=round(uptime, 1),
            total_tasks=total,
            completed_tasks=completed,
            failed_tasks=failed,
            pending_tasks=pending,
            task_success_rate=success_rate,
            agents=agents_data,
            circuit_breakers=cbs,
            alerts=alerts,
        )
        return snapshot

    async def generate_report(self, kernel: Any = None) -> Dict[str, Any]:
        """Generate a human-readable monitoring report."""
        snapshot = await self.get_snapshot(kernel)

        report = {
            "report_time": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime(snapshot.timestamp)),
            "overall_status": snapshot.overall_status,
            "uptime": f"{snapshot.uptime_seconds:.0f}s",
            "tasks": {
                "total": snapshot.total_tasks,
                "completed": snapshot.completed_tasks,
                "failed": snapshot.failed_tasks,
                "pending": snapshot.pending_tasks,
                "success_rate": f"{snapshot.task_success_rate}%",
            },
            "agents": snapshot.agents,
            "circuit_breakers": snapshot.circuit_breakers,
            "alerts": snapshot.alerts,
        }
        return report


# Singleton
_collector: Optional[MetricsCollector] = None


def get_metrics_collector() -> MetricsCollector:
    """Get or create the global metrics collector."""
    global _collector
    if _collector is None:
        _collector = MetricsCollector(collection_interval=60.0)
    return _collector
