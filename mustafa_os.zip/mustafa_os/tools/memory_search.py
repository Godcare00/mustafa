"""
MUSTAFA OS - Memory Search Tool
Semantic search over the vector memory store.
"""
from __future__ import annotations
from typing import Any, Dict, Optional
from tools.base import BaseTool, ToolResult


class MemorySearchTool(BaseTool):
    name = "memory_search"
    description = "Search the vector memory store for relevant knowledge"
    permissions = ["memory.read"]
    timeout = 10

    async def execute(self, params: Dict[str, Any]) -> ToolResult:
        query = params.get("query", "")
        collection = params.get("collection", "general")
        top_k = int(params.get("top_k", 5))

        if not query:
            return ToolResult(success=False, error="query is required")

        try:
            from memory.long_term import LongTermMemory
            mem = LongTermMemory()
            if not mem.is_available:
                await mem.initialize()

            results = await mem.search(query=query, collection=collection, top_k=top_k)
            return ToolResult(success=True, data={"results": results, "query": query, "collection": collection})
        except Exception as e:
            return ToolResult(success=False, error=str(e))

    async def validate_params(self, params: Dict[str, Any]) -> Optional[str]:
        if not params.get("query"):
            return "query is required"
        return None
