"""
MUSTAFA OS - Orchestrator Agent

The orchestrator is the sole decision-maker in MUSTAFA OS.
It receives every message and decides independently what to do with it —
whether that means replying directly, calling a tool, delegating to an agent,
creating a new capability, or asking the user for more information.

The system does not guide it. It guides the system.

Architecture:
- The orchestrator receives the message plus full awareness of available agents and tools.
- It reasons freely and produces a structured decision.
- The runtime executes that decision faithfully and reports results back.
- The orchestrator then decides the next step — or declares it is done.
- All agents report back to the orchestrator.
- All tools return to the agent that called them (including the orchestrator itself).
"""
from __future__ import annotations

import asyncio
import json
import re
import uuid
from typing import Any, Dict, List, Optional

from agents.base import BaseAgent
from core.llm_client import LLMMessage
from core.logger import get_logger
from core.tool_engine import ToolEngine, get_tool_engine

logger = get_logger("orchestrator")


class OrchestratorAgent(BaseAgent):
    """
    The central intelligence of MUSTAFA OS.

    Receives every user message with full visibility of:
      - All registered agents and their capabilities
      - All available tools and their schemas
      - Results from previous steps in the current conversation
      - Relevant memories from past interactions

    From that, it decides everything. The code only executes what the
    orchestrator decides — it never overrides, nudges, or pre-classifies.
    """

    agent_name = "orchestrator"
    agent_description = (
        "Central intelligence. Receives every message and decides how to handle it — "
        "directly, via agents, via tools, or by creating new capabilities."
    )

    def __init__(self, agent_registry: "AgentRegistry", **kwargs):
        super().__init__(**kwargs)
        self._registry = agent_registry
        self._tool_engine: ToolEngine = get_tool_engine()
        self._max_iterations = 10

    # ─── Core execution loop ──────────────────────────────────────────────────

    async def execute(
        self,
        task: str,
        context: Optional[Dict] = None,
        task_id: Optional[str] = None,
    ) -> Any:
        """
        Main entry point. The orchestrator receives the message and runs its
        reasoning loop until it decides the task is complete or needs user input.
        """
        tid = task_id or str(uuid.uuid4())
        ctx = context or {}
        iteration = 0
        step_results: List[Dict] = []

        self._log.info("Orchestrator received message", task_id=tid, message=task[:150])

        # Give the orchestrator full awareness of the system on every call
        agents_manifest = await self._registry.get_agents_manifest()
        tools_manifest = await self._tool_engine.get_tools_manifest()

        # Surface relevant memories so the orchestrator can draw on past context
        memories = await self.recall_memory(task, top_k=5)
        memory_section = ""
        if memories:
            memory_section = "\n\nRELEVANT PAST CONTEXT:\n" + "\n".join(
                f"- {m.content[:200]}" for m in memories
            )

        system_prompt = self._build_system_prompt(
            agents_manifest, tools_manifest, memory_section
        )

        while iteration < self._max_iterations:
            iteration += 1
            self._log.info("Orchestrator thinking", task_id=tid, iteration=iteration)

            messages = self._build_turn(task, ctx, step_results, iteration)

            try:
                decision = await self.llm_complete_json(
                    messages=messages,
                    system_prompt=system_prompt,
                )
            except Exception as e:
                self._log.error("Orchestrator LLM call failed", error=str(e), task_id=tid)
                return {
                    "status": "error",
                    "error": f"Orchestrator reasoning failed: {e}",
                    "task_id": tid,
                    "steps": step_results,
                }

            self._log.info(
                "Orchestrator decision",
                task_id=tid,
                iteration=iteration,
                reasoning=str(decision.get("reasoning", ""))[:200],
            )

            # The orchestrator says it is done
            if decision.get("done"):
                answer = decision.get("response")
                self._log.info("Orchestrator completed", task_id=tid, iterations=iteration)

                await self.store_memory(
                    content=f"Message: {task}\nResponse: {str(answer)[:500]}",
                    memory_type="task_result",
                    metadata={"task_id": tid},
                )

                return {
                    "status": "completed",
                    "result": answer,
                    "task_id": tid,
                    "iterations": iteration,
                    "steps": step_results,
                }

            # The orchestrator needs more information from the user
            if decision.get("needs_user_input"):
                return {
                    "status": "needs_input",
                    "message": decision.get("response", "Could you provide more detail?"),
                    "alternatives": decision.get("alternatives", []),
                    "task_id": tid,
                    "steps": step_results,
                }

            # Execute whatever the orchestrator decided to do
            acted = False

            # Agent delegations — run in parallel where same priority
            delegations = decision.get("delegate", [])
            if delegations:
                acted = True
                results = await self._run_delegations(delegations, tid)
                step_results.extend(results)

            # Direct tool calls by the orchestrator itself
            tool_calls = decision.get("use_tools", [])
            if tool_calls:
                acted = True
                results = await self._run_tool_calls(tool_calls, tid)
                step_results.extend(results)

            # New capability creation
            if decision.get("create_capability"):
                acted = True
                spec = decision.get("capability_spec", {})
                result = await self._create_capability(spec, tid)
                step_results.append(result)
                # Refresh tool awareness after creation
                tools_manifest = await self._tool_engine.get_tools_manifest()
                system_prompt = self._build_system_prompt(
                    agents_manifest, tools_manifest, memory_section
                )

            # If the orchestrator took no action and didn't mark done,
            # it has stalled — return what we have
            if not acted:
                self._log.warning(
                    "Orchestrator took no action — returning current state",
                    task_id=tid,
                    iteration=iteration,
                )
                return {
                    "status": "completed",
                    "result": decision.get("response", "Done."),
                    "task_id": tid,
                    "iterations": iteration,
                    "steps": step_results,
                }

        # Iteration ceiling reached
        self._log.warning("Orchestrator hit iteration ceiling", task_id=tid)
        return {
            "status": "incomplete",
            "message": (
                f"Reached the maximum of {self._max_iterations} reasoning steps. "
                "You can continue by providing more specific instructions."
            ),
            "task_id": tid,
            "steps": step_results,
        }

    # ─── Prompt construction ──────────────────────────────────────────────────

    def _build_system_prompt(
        self,
        agents_manifest: str,
        tools_manifest: str,
        memory_section: str,
    ) -> str:
        """
        The system prompt is the orchestrator's complete situational awareness.
        It includes the system instructions from config plus live agent/tool state.
        """
        return (
            f"{self._system_prompt}\n\n"
            f"{'=' * 48}\n"
            f"AVAILABLE AGENTS\n"
            f"{'=' * 48}\n"
            f"{agents_manifest}\n\n"
            f"{'=' * 48}\n"
            f"AVAILABLE TOOLS\n"
            f"{'=' * 48}\n"
            f"{tools_manifest}"
            f"{memory_section}"
        )

    def _build_turn(
        self,
        message: str,
        context: Dict,
        step_results: List[Dict],
        iteration: int,
    ) -> List[LLMMessage]:
        """
        Build the user turn. On the first iteration it is just the message.
        On subsequent iterations the orchestrator also sees what has been done.
        """
        if iteration == 1 and not step_results:
            content = f"MESSAGE: {message}"
            if context:
                content += f"\n\nCONTEXT: {json.dumps(context, default=str)}"
        else:
            content = (
                f"MESSAGE: {message}\n\n"
                f"STEP RESULTS SO FAR:\n{self._summarise_results(step_results)}"
            )
        return [LLMMessage.user(content)]

    def _summarise_results(self, step_results: List[Dict]) -> str:
        """Compact summary of completed steps — keeps context lean."""
        lines = []
        for r in step_results[-8:]:
            source = r.get("agent") or r.get("tool") or "unknown"
            status = r.get("status", "?")
            data = r.get("result") or r.get("output") or r.get("error") or r.get("message", "")
            if isinstance(data, dict):
                snippet = json.dumps(data, default=str)[:400]
            else:
                snippet = str(data)[:400]
            lines.append(f"[{source}] {status}: {snippet}")
        return "\n".join(lines) if lines else "None."

    # ─── Delegation ───────────────────────────────────────────────────────────

    async def _run_delegations(
        self, delegations: List[Dict], task_id: str
    ) -> List[Dict]:
        """
        Run agent delegations. Same-priority delegations run in parallel.
        All results are returned to the orchestrator.
        """
        results: List[Dict] = []
        groups: Dict[int, List[Dict]] = {}
        for d in delegations:
            groups.setdefault(int(d.get("priority", 5)), []).append(d)

        for _, group in sorted(groups.items()):
            coros = []
            for delegation in group:
                agent_name = delegation.get("agent", "")
                agent = self._registry.get_agent(agent_name)
                if agent:
                    coros.append(
                        self._safe_agent_run(
                            agent,
                            delegation.get("task", ""),
                            delegation.get("context", {}),
                            task_id,
                            agent_name,
                        )
                    )
                else:
                    results.append({
                        "agent": agent_name,
                        "status": "error",
                        "error": f"Agent '{agent_name}' not registered",
                    })
            if coros:
                group_results = await asyncio.gather(*coros, return_exceptions=True)
                for r in group_results:
                    results.append(
                        r if not isinstance(r, Exception)
                        else {"status": "error", "error": str(r)}
                    )
        return results

    async def _safe_agent_run(
        self,
        agent: Any,
        task: str,
        context: Dict,
        task_id: str,
        agent_name: str,
    ) -> Dict:
        """Run an agent. Its result is returned to the orchestrator."""
        try:
            result = await asyncio.wait_for(
                agent.run(task=task, context=context, task_id=task_id),
                timeout=120.0,
            )
            return {"agent": agent_name, "status": "success", "result": result}
        except asyncio.TimeoutError:
            return {"agent": agent_name, "status": "timeout", "error": "Agent timed out after 120s"}
        except Exception as e:
            self._log.error("Agent run failed", agent=agent_name, error=str(e))
            return {"agent": agent_name, "status": "error", "error": str(e)}

    # ─── Tool calls ───────────────────────────────────────────────────────────

    async def _run_tool_calls(
        self, tool_calls: List[Dict], task_id: str
    ) -> List[Dict]:
        """
        Run tools called directly by the orchestrator.
        Tools always return to the caller — here, the orchestrator itself.
        Runs in parallel.
        """
        coros = [
            self._safe_tool_call(tc.get("tool", ""), tc.get("params", {}), task_id)
            for tc in tool_calls
        ]
        raw = await asyncio.gather(*coros, return_exceptions=True)
        return [
            r if not isinstance(r, Exception)
            else {"tool": tool_calls[i].get("tool"), "status": "error", "error": str(r)}
            for i, r in enumerate(raw)
        ]

    async def _safe_tool_call(
        self, tool_name: str, params: Dict, task_id: str
    ) -> Dict:
        """Execute one tool. Returns result to the orchestrator."""
        try:
            result = await self._tool_engine.execute(
                tool_name=tool_name,
                params=params,
                task_id=task_id,
                agent_name=self.agent_name,
            )
            return {
                "tool": tool_name,
                "status": "success" if result.success else "failed",
                "result": result.output,
                "error": result.error,
                "duration_ms": result.duration_ms,
            }
        except Exception as e:
            return {"tool": tool_name, "status": "error", "error": str(e)}

    # ─── Capability creation ──────────────────────────────────────────────────

    async def _create_capability(self, spec: Dict, task_id: str) -> Dict:
        """
        When the orchestrator identifies a missing capability,
        it delegates to the developer agent to build the tool,
        then registers it immediately.
        """
        self._log.info("Creating new capability", spec=spec, task_id=task_id)
        try:
            developer = self._registry.get_agent("developer")
            if not developer:
                return {"status": "error", "error": "Developer agent not available"}

            dev_result = await developer.run(
                task=(
                    f"Create a new MUSTAFA OS tool.\n"
                    f"Name: {spec.get('name', 'custom_tool')}\n"
                    f"Description: {spec.get('description', '')}\n"
                    f"Required behaviour: {spec.get('required_behavior', '')}\n\n"
                    "Output JSON: tool_name, description, code (async Python), "
                    "json_schema (input/output), permissions, dependencies."
                ),
                task_id=task_id,
            )

            # Unwrap standard agent result envelope
            if isinstance(dev_result, dict) and "result" in dev_result and not dev_result.get("tool_name"):
                dev_result = dev_result.get("result", dev_result)

            if isinstance(dev_result, dict) and dev_result.get("tool_name"):
                tool_spec = dev_result
            elif isinstance(dev_result, str):
                match = re.search(r'\{.*\}', dev_result, re.DOTALL)
                tool_spec = json.loads(match.group()) if match else None
            else:
                tool_spec = None

            if not tool_spec:
                return {"status": "error", "error": "Could not parse tool spec from developer agent"}

            success = await self._tool_engine.register_dynamic_tool(
                tool_name=tool_spec["tool_name"],
                description=tool_spec["description"],
                code=tool_spec["code"],
                json_schema=tool_spec["json_schema"],
                permissions=tool_spec.get("permissions", []),
                dependencies=tool_spec.get("dependencies", []),
            )

            return {
                "status": "created" if success else "failed",
                "tool_name": tool_spec.get("tool_name"),
                "message": (
                    f"Tool '{tool_spec.get('tool_name')}' registered."
                    if success else "Tool creation failed."
                ),
            }

        except Exception as e:
            self._log.error("Capability creation failed", error=str(e), task_id=task_id)
            return {"status": "error", "error": str(e)}


# ─── Agent Registry ───────────────────────────────────────────────────────────

class AgentRegistry:
    """
    Registry of all agents in MUSTAFA OS.
    The orchestrator queries this to discover what is available.
    """

    def __init__(self):
        self._agents: Dict[str, BaseAgent] = {}
        self._log = logger.bind(component="agent_registry")

    def register(self, agent: BaseAgent) -> None:
        self._agents[agent.agent_name] = agent
        self._log.info("Agent registered", agent=agent.agent_name)

    def get_agent(self, name: str) -> Optional[BaseAgent]:
        return self._agents.get(name)

    def list_agents(self) -> List[Dict]:
        return [
            {
                "name": a.agent_name,
                "description": a.agent_description,
                "status": a._status,
                "stats": a.get_stats(),
            }
            for a in self._agents.values()
        ]

    async def get_agents_manifest(self) -> str:
        """JSON manifest of all agents except the orchestrator itself."""
        return json.dumps(
            [
                {
                    "name": a["name"],
                    "description": a["description"],
                    "status": a["status"],
                }
                for a in self.list_agents()
                if a["name"] != "orchestrator"
            ],
            indent=2,
        )

    async def startup_all(self) -> None:
        for agent in self._agents.values():
            try:
                await agent.on_startup()
            except Exception as e:
                self._log.error("Agent startup failed", agent=agent.agent_name, error=str(e))

    async def shutdown_all(self) -> None:
        for agent in self._agents.values():
            try:
                await agent.on_shutdown()
            except Exception as e:
                self._log.error("Agent shutdown failed", agent=agent.agent_name, error=str(e))
