"""
MUSTAFA OS - Core Settings
Centralized configuration management using pydantic-settings.
"""

from __future__ import annotations

import os
from functools import lru_cache
from pathlib import Path
from typing import List, Optional

import yaml
from pydantic import Field, field_validator
from pydantic_settings import BaseSettings

BASE_DIR = Path(__file__).parent.parent


class Settings(BaseSettings):
    """Production settings for MUSTAFA OS."""

    # System
    system_name: str = "MUSTAFA_OS"
    system_version: str = "1.0.0"
    environment: str = Field(default="production", env="ENVIRONMENT")
    debug: bool = Field(default=False, env="API_DEBUG")

    # API
    api_host: str = Field(default="0.0.0.0", env="API_HOST")
    api_port: int = Field(default=8000, env="API_PORT")
    api_secret_key: str = Field(default="change-me-in-production", env="API_SECRET_KEY")
    api_debug: bool = Field(default=False, env="API_DEBUG")

    # LLM
    openrouter_api_key: str = Field(default="", env="OPENROUTER_API_KEY")
    openrouter_base_url: str = Field(
        default="https://openrouter.ai/api/v1", env="OPENROUTER_BASE_URL"
    )
    openrouter_default_model: str = Field(
        default="anthropic/claude-3.5-sonnet", env="OPENROUTER_DEFAULT_MODEL"
    )
    openrouter_fast_model: str = Field(
        default="anthropic/claude-3-haiku", env="OPENROUTER_FAST_MODEL"
    )
    openrouter_research_model: str = Field(
        default="anthropic/claude-3.5-sonnet", env="OPENROUTER_RESEARCH_MODEL"
    )

    # Database
    database_url: str = Field(
        default="postgresql+asyncpg://mustafa_os:password@localhost:5432/mustafa_os",
        env="DATABASE_URL",
    )
    postgres_host: str = Field(default="localhost", env="POSTGRES_HOST")
    postgres_port: int = Field(default=5432, env="POSTGRES_PORT")
    postgres_db: str = Field(default="mustafa_os", env="POSTGRES_DB")
    postgres_user: str = Field(default="mustafa_os", env="POSTGRES_USER")
    postgres_password: str = Field(default="password", env="POSTGRES_PASSWORD")

    # Redis
    redis_url: str = Field(default="redis://localhost:6379/0", env="REDIS_URL")
    redis_host: str = Field(default="localhost", env="REDIS_HOST")
    redis_port: int = Field(default=6379, env="REDIS_PORT")
    redis_password: Optional[str] = Field(default=None, env="REDIS_PASSWORD")
    redis_db: int = Field(default=0, env="REDIS_DB")

    # Celery
    celery_broker_url: str = Field(
        default="redis://localhost:6379/1", env="CELERY_BROKER_URL"
    )
    celery_result_backend: str = Field(
        default="redis://localhost:6379/2", env="CELERY_RESULT_BACKEND"
    )

    # ChromaDB
    chroma_persist_dir: str = Field(default="./data/chroma", env="CHROMA_PERSIST_DIR")
    chroma_host: str = Field(default="localhost", env="CHROMA_HOST")
    chroma_port: int = Field(default=8001, env="CHROMA_PORT")

    # Telegram
    telegram_bot_token: str = Field(default="", env="TELEGRAM_BOT_TOKEN")
    telegram_authorized_users: str = Field(default="", env="TELEGRAM_AUTHORIZED_USERS")

    # Monitoring
    prometheus_port: int = Field(default=9090, env="PROMETHEUS_PORT")
    log_level: str = Field(default="INFO", env="LOG_LEVEL")
    log_format: str = Field(default="json", env="LOG_FORMAT")
    metrics_enabled: bool = Field(default=True, env="METRICS_ENABLED")

    # Security
    code_execution_timeout: int = Field(default=30, env="CODE_EXECUTION_TIMEOUT")
    max_memory_per_agent_mb: int = Field(default=512, env="MAX_MEMORY_PER_AGENT_MB")
    enable_code_sandbox: bool = Field(default=True, env="ENABLE_CODE_SANDBOX")

    # Paths
    data_dir: str = Field(default="./data", env="DATA_DIR")
    logs_dir: str = Field(default="./logs", env="LOGS_DIR")
    experiments_dir: str = Field(default="./experiments", env="EXPERIMENTS_DIR")
    plugins_dir: str = Field(default="./plugins", env="PLUGINS_DIR")

    # Agent settings
    max_concurrent_agents: int = Field(default=10, env="MAX_CONCURRENT_AGENTS")
    task_timeout_seconds: int = Field(default=300, env="TASK_TIMEOUT_SECONDS")
    agent_heartbeat_interval: int = Field(default=30, env="AGENT_HEARTBEAT_INTERVAL")

    class Config:
        env_file = ".env"
        env_file_encoding = "utf-8"
        case_sensitive = False
        extra = "ignore"  # Unknown env vars are silently ignored, never crash startup

    @field_validator("telegram_authorized_users")
    @classmethod
    def parse_telegram_users(cls, v: str) -> str:
        return v

    @property
    def telegram_user_ids(self) -> List[int]:
        """Parse comma-separated Telegram user IDs."""
        if not self.telegram_authorized_users:
            return []
        return [
            int(uid.strip())
            for uid in self.telegram_authorized_users.split(",")
            if uid.strip().isdigit()
        ]

    @property
    def is_production(self) -> bool:
        return self.environment == "production" and not self.api_debug

    @property
    def config_dir(self) -> Path:
        return BASE_DIR / "config"


def load_yaml_config(filename: str) -> dict:
    """Load a YAML configuration file."""
    config_path = BASE_DIR / "config" / filename
    if not config_path.exists():
        return {}
    with open(config_path) as f:
        return yaml.safe_load(f) or {}


@lru_cache()
def get_settings() -> Settings:
    """Get cached settings instance."""
    return Settings()


@lru_cache()
def get_agents_config() -> dict:
    return load_yaml_config("agents.yaml")


@lru_cache()
def get_tools_config() -> dict:
    return load_yaml_config("tools.yaml")


@lru_cache()
def get_models_config() -> dict:
    return load_yaml_config("models.yaml")


@lru_cache()
def get_system_config() -> dict:
    return load_yaml_config("system.yaml")


# Singleton
settings = get_settings()
