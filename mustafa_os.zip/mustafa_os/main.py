"""
MUSTAFA OS - Main Entry Point

Usage:
    python main.py              # Start FastAPI server
    python main.py cli          # Start CLI chat interface
    python main.py telegram     # Start Telegram bot
    python main.py health       # Run health check and exit
    python main.py test         # Run test suite
"""
from __future__ import annotations

import asyncio
import sys
from pathlib import Path

# Ensure project root is on path
sys.path.insert(0, str(Path(__file__).parent))


def run_server() -> None:
    """Start the FastAPI server."""
    import uvicorn
    from core.config import get_settings

    settings = get_settings()
    print(f"""
╔══════════════════════════════════════════════╗
║           MUSTAFA OS  v1.0.0                 ║
║  Starting API server on port {settings.server.port}          ║
╚══════════════════════════════════════════════╝
""")
    uvicorn.run(
        "api.app:app",
        host=settings.server.host,
        port=settings.server.port,
        workers=1,  # Single worker for shared state
        log_level=settings.server.log_level,
        access_log=False,  # We handle logging ourselves
    )


def run_cli() -> None:
    """Start the CLI chat interface."""
    from cli.chat import main
    main()


def run_telegram() -> None:
    """Start the Telegram bot."""
    from telegram_bot.bot import main
    main()


async def run_health_check() -> None:
    """Run a health check and print results."""
    from core.kernel import get_kernel
    import json

    print("Booting MUSTAFA OS for health check...")
    kernel = get_kernel()
    try:
        await kernel.boot()
        health = await kernel.health_check()
        print(json.dumps(health, indent=2, default=str))
        overall = health.get("overall", "unknown")
        print(f"\nOverall: {overall.upper()}")
        await kernel.shutdown()
        sys.exit(0 if overall == "healthy" else 1)
    except Exception as e:
        print(f"Health check failed: {e}")
        sys.exit(1)


def run_tests() -> None:
    """Run the test suite."""
    import subprocess
    result = subprocess.run(
        [sys.executable, "-m", "pytest", "tests/", "-v", "--tb=short"],
        cwd=Path(__file__).parent,
    )
    sys.exit(result.returncode)


def print_usage() -> None:
    print(__doc__)
    sys.exit(1)


if __name__ == "__main__":
    command = sys.argv[1].lower() if len(sys.argv) > 1 else "server"

    if command in ("server", "api", ""):
        run_server()
    elif command == "cli":
        run_cli()
    elif command == "telegram":
        run_telegram()
    elif command == "health":
        asyncio.run(run_health_check())
    elif command == "test":
        run_tests()
    else:
        print(f"Unknown command: {command}")
        print_usage()
