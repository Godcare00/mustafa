"""
MUSTAFA OS - Unit Tests
Tests for core components: config, logger, reliability, database, tool engine.
Run with: python -m pytest tests/ -v
"""
from __future__ import annotations

import asyncio
import json
import os
import sys
import tempfile
import time
import unittest
from pathlib import Path
from typing import Any
from unittest.mock import AsyncMock, MagicMock, patch

# Add project root to path
sys.path.insert(0, str(Path(__file__).parent.parent))

# ─── Config Tests ─────────────────────────────────────────────────────────────

class TestConfig(unittest.TestCase):
    """Test configuration loading."""

    def test_settings_load(self):
        """Settings should load without errors."""
        from core.config import get_settings
        settings = get_settings()
        self.assertIsNotNone(settings)
        self.assertIsNotNone(settings.llm)
        self.assertIsNotNone(settings.redis)
        self.assertIsNotNone(settings.database)

    def test_llm_config_has_model(self):
        """LLM config must have a default model."""
        from core.config import get_settings
        settings = get_settings()
        self.assertTrue(len(settings.llm.default_model) > 0)

    def test_agent_config_retrieval(self):
        """Agent config should be retrievable by name."""
        from core.config import get_settings
        settings = get_settings()
        orchestrator_cfg = settings.get_agent_config("orchestrator")
        self.assertIsInstance(orchestrator_cfg, dict)


# ─── Logger Tests ─────────────────────────────────────────────────────────────

class TestLogger(unittest.TestCase):
    """Test JSON structured logger."""

    def test_logger_creation(self):
        """Logger should be created without errors."""
        from core.logger import get_logger
        log = get_logger("test")
        self.assertIsNotNone(log)

    def test_logger_info(self):
        """Logger.info() should not raise."""
        from core.logger import get_logger
        log = get_logger("test_info")
        try:
            log.info("Test message", key="value")
        except Exception as e:
            self.fail(f"Logger raised exception: {e}")

    def test_logger_bind(self):
        """Logger.bind() should return a new logger with context."""
        from core.logger import get_logger
        log = get_logger("test_bind")
        bound = log.bind(agent="test_agent", task_id="abc123")
        self.assertIsNotNone(bound)
        self.assertIn("test_agent", bound._context.values())


# ─── Reliability Tests ────────────────────────────────────────────────────────

class TestCircuitBreaker(unittest.IsolatedAsyncioTestCase):
    """Test circuit breaker behavior."""

    async def test_closed_state_passes_through(self):
        """Circuit breaker in CLOSED state should pass calls through."""
        from core.reliability import CircuitBreaker

        cb = CircuitBreaker("test_cb_pass", failure_threshold=3)

        async def success_fn():
            return "ok"

        result = await cb.call(success_fn)
        self.assertEqual(result, "ok")
        self.assertEqual(cb.state.value, "closed")

    async def test_opens_after_threshold(self):
        """Circuit breaker should OPEN after failure_threshold failures."""
        from core.reliability import CircuitBreaker, CircuitOpenError

        cb = CircuitBreaker("test_cb_open", failure_threshold=3, recovery_timeout=60)

        async def failing_fn():
            raise ValueError("Simulated failure")

        for _ in range(3):
            try:
                await cb.call(failing_fn)
            except ValueError:
                pass

        self.assertEqual(cb.state.value, "open")

        # Next call should be rejected immediately
        with self.assertRaises(CircuitOpenError):
            await cb.call(failing_fn)

    async def test_retry_decorator(self):
        """Retry decorator should retry on failure."""
        from core.reliability import retry

        call_count = 0

        @retry(max_attempts=3, backoff=0.01)
        async def flaky():
            nonlocal call_count
            call_count += 1
            if call_count < 3:
                raise ValueError("Not yet")
            return "success"

        result = await flaky()
        self.assertEqual(result, "success")
        self.assertEqual(call_count, 3)

    async def test_with_timeout_raises(self):
        """with_timeout should raise TimeoutError on slow coroutines."""
        from core.reliability import with_timeout

        async def slow_fn():
            await asyncio.sleep(10)

        with self.assertRaises(asyncio.TimeoutError):
            await with_timeout(slow_fn(), timeout_seconds=0.05, operation_name="test")


# ─── Database Tests ───────────────────────────────────────────────────────────

class TestDatabase(unittest.IsolatedAsyncioTestCase):
    """Test database operations."""

    async def asyncSetUp(self):
        """Create a temporary database for each test."""
        from core.database import Database
        self.db_file = tempfile.mktemp(suffix=".db")
        self.db = Database(self.db_file)
        await self.db.connect()

    async def asyncTearDown(self):
        """Clean up temporary database."""
        await self.db.disconnect()
        if os.path.exists(self.db_file):
            os.unlink(self.db_file)

    async def test_create_task(self):
        """Should create a task and return an ID."""
        task_id = await self.db.create_task("Test goal")
        self.assertIsNotNone(task_id)
        self.assertTrue(len(task_id) > 0)

    async def test_get_task(self):
        """Should retrieve a created task."""
        task_id = await self.db.create_task("Retrieve test")
        task = await self.db.get_task(task_id)
        self.assertIsNotNone(task)
        self.assertEqual(task["goal"], "Retrieve test")
        self.assertEqual(task["status"], "pending")

    async def test_update_task_status(self):
        """Should update task status correctly."""
        task_id = await self.db.create_task("Update test")
        await self.db.update_task(task_id, "completed", result={"answer": 42})
        task = await self.db.get_task(task_id)
        self.assertEqual(task["status"], "completed")

    async def test_register_and_get_tool(self):
        """Should register a tool and retrieve it."""
        schema = {"input": {"type": "object", "properties": {"x": {"type": "integer"}}, "required": ["x"]}}
        await self.db.register_tool(
            name="test_tool",
            description="A test tool",
            json_schema=schema,
            category="test",
            is_builtin=False,
        )
        tool = await self.db.get_tool("test_tool")
        self.assertIsNotNone(tool)
        self.assertEqual(tool["name"], "test_tool")
        self.assertEqual(tool["description"], "A test tool")

    async def test_record_metric(self):
        """Should record a metric without error."""
        await self.db.record_metric("test.metric", 42.5, labels={"agent": "test"})
        summary = await self.db.get_metrics_summary("test.metric", window_seconds=60)
        self.assertIsNotNone(summary)

    async def test_list_tasks_empty(self):
        """list_tasks on empty DB should return empty list."""
        tasks = await self.db.list_tasks()
        self.assertIsInstance(tasks, list)

    async def test_log_event(self):
        """Should log a system event without error."""
        try:
            await self.db.log_event("test_event", "Test description", severity="info")
        except Exception as e:
            self.fail(f"log_event raised: {e}")


# ─── Tool Engine Tests ────────────────────────────────────────────────────────

class TestToolEngine(unittest.IsolatedAsyncioTestCase):
    """Test tool execution engine."""

    async def asyncSetUp(self):
        """Set up a test database and tool engine."""
        import tempfile, os
        from core.database import Database
        self.db_file = tempfile.mktemp(suffix=".db")
        self.db = Database(self.db_file)
        await self.db.connect()

        # Patch get_db to return our test db
        self.patcher = patch("core.tool_engine.get_db", return_value=self.db)
        self.patcher.start()

        # Also patch the global getter used elsewhere
        import core.database
        self._orig = core.database._db_instance
        core.database._db_instance = self.db

    async def asyncTearDown(self):
        import core.database
        core.database._db_instance = self._orig
        self.patcher.stop()
        await self.db.disconnect()
        if os.path.exists(self.db_file):
            os.unlink(self.db_file)

    async def test_web_search_returns_results(self):
        """web_search builtin should return a dict with results."""
        from core.tool_engine import _tool_web_search
        result = await _tool_web_search("Python programming language", max_results=3)
        self.assertIsInstance(result, dict)
        self.assertIn("results", result)
        self.assertIn("query", result)

    async def test_read_file_nonexistent(self):
        """read_file on nonexistent path should return error gracefully."""
        from core.tool_engine import _tool_read_file
        result = await _tool_read_file("/nonexistent/path/file.txt")
        self.assertIsInstance(result, dict)
        self.assertIn("error", result)

    async def test_write_and_read_file(self):
        """write_file then read_file should round-trip correctly."""
        from core.tool_engine import _tool_read_file, _tool_write_file
        import tempfile
        tmp = tempfile.mktemp(suffix=".txt")
        try:
            write_result = await _tool_write_file(tmp, "Hello MUSTAFA OS!")
            self.assertTrue(write_result["success"])

            read_result = await _tool_read_file(tmp)
            self.assertEqual(read_result["content"], "Hello MUSTAFA OS!")
        finally:
            if os.path.exists(tmp):
                os.unlink(tmp)

    async def test_python_eval_success(self):
        """python_eval should execute simple code."""
        from core.tool_engine import _tool_python_eval
        result = await _tool_python_eval("print(2 + 2)")
        self.assertIsInstance(result, dict)
        self.assertTrue(result["success"])
        self.assertIn("4", result["stdout"])

    async def test_python_eval_error(self):
        """python_eval should handle syntax errors gracefully."""
        from core.tool_engine import _tool_python_eval
        result = await _tool_python_eval("this is not valid python !!!")
        self.assertIsInstance(result, dict)
        self.assertFalse(result["success"])

    async def test_http_request_success(self):
        """http_request should handle a real HTTP call."""
        from core.tool_engine import _tool_http_request
        result = await _tool_http_request("https://httpbin.org/get", method="GET")
        self.assertIsInstance(result, dict)
        # May fail if httpbin is down, but should not crash
        self.assertIn("status_code", result)

    async def test_list_directory(self):
        """list_directory should return entries for /tmp."""
        from core.tool_engine import _tool_list_directory
        result = await _tool_list_directory("/tmp")
        self.assertIsInstance(result, dict)
        self.assertIn("entries", result)


# ─── Memory Tests ─────────────────────────────────────────────────────────────

class TestLongTermMemory(unittest.IsolatedAsyncioTestCase):
    """Test long-term vector memory."""

    async def asyncSetUp(self):
        import tempfile
        self.tmp_dir = tempfile.mkdtemp()

    async def test_memory_init_graceful_without_chromadb(self):
        """Memory should initialize gracefully even without chromadb."""
        from memory.memory_system import LongTermMemory
        mem = LongTermMemory(
            chroma_path=self.tmp_dir,
            collection_name="test_collection",
        )
        # Should not raise even if chromadb missing
        result = await mem.initialize()
        # True if chromadb installed, False if not — both are valid
        self.assertIsInstance(result, bool)

    async def test_memory_store_and_search(self):
        """Memory store/search cycle should work if chromadb available."""
        from memory.memory_system import LongTermMemory
        mem = LongTermMemory(self.tmp_dir, "test_col")
        available = await mem.initialize()
        if not available:
            self.skipTest("ChromaDB not installed")

        mid = await mem.store("Python is a programming language", memory_type="knowledge")
        self.assertIsNotNone(mid)

        results = await mem.search("programming language", top_k=1)
        self.assertTrue(len(results) >= 1)
        self.assertIn("Python", results[0].content)


# ─── Integration: Agent Base ──────────────────────────────────────────────────

class TestBaseAgent(unittest.IsolatedAsyncioTestCase):
    """Test base agent scaffolding."""

    async def test_base_agent_instantiates(self):
        """BaseAgent subclass should instantiate correctly."""
        from agents.base import BaseAgent

        class TestAgent(BaseAgent):
            agent_name = "test_agent"
            agent_description = "Test"

            async def execute(self, task, context=None, task_id=None):
                return {"result": f"processed: {task}"}

        mock_llm = MagicMock()
        agent = TestAgent(llm_client=mock_llm)
        self.assertEqual(agent.agent_name, "test_agent")
        self.assertEqual(agent._status, "idle")

    async def test_agent_get_stats(self):
        """get_stats should return a valid dict."""
        from agents.base import BaseAgent

        class StatsAgent(BaseAgent):
            agent_name = "stats_agent"
            agent_description = "Stats test"

            async def execute(self, task, context=None, task_id=None):
                return {}

        agent = StatsAgent(llm_client=MagicMock())
        stats = agent.get_stats()
        self.assertIn("agent_name", stats)
        self.assertIn("tasks_completed", stats)
        self.assertIn("tasks_failed", stats)
        self.assertIn("avg_latency_ms", stats)


# ─── Run Tests ────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    unittest.main(verbosity=2)
