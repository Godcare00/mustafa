"""
MUSTAFA OS - Redis Message Bus
Pub/Sub messaging for agent-to-agent communication with async support.
"""
from __future__ import annotations

import asyncio
import json
import time
import uuid
from dataclasses import asdict, dataclass, field
from typing import Any, Callable, Dict, List, Optional

import redis.asyncio as aioredis

from core.logger import get_logger

logger = get_logger("message_bus")


@dataclass
class AgentMessage:
    """Structured message for agent-to-agent communication."""

    sender: str
    recipient: str
    message_type: str  # task, result, error, broadcast, ping
    payload: Dict[str, Any]
    message_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    task_id: Optional[str] = None
    timestamp: float = field(default_factory=time.time)
    reply_to: Optional[str] = None
    ttl: int = 300  # seconds

    def to_json(self) -> str:
        return json.dumps(asdict(self), default=str)

    @classmethod
    def from_json(cls, data: str) -> "AgentMessage":
        d = json.loads(data)
        return cls(**d)


class MessageBus:
    """
    Async Redis pub/sub message bus for agent communication.
    Supports direct messaging, broadcast, and request/reply patterns.
    """

    BROADCAST_CHANNEL = "mustafa:broadcast"
    CHANNEL_PREFIX = "mustafa:agent:"

    def __init__(self, host: str = "localhost", port: int = 6379, db: int = 0, password: Optional[str] = None):
        self._host = host
        self._port = port
        self._db = db
        self._password = password
        self._redis: Optional[aioredis.Redis] = None
        self._pubsub: Optional[aioredis.client.PubSub] = None
        self._subscribers: Dict[str, List[Callable]] = {}
        self._pending_replies: Dict[str, asyncio.Future] = {}
        self._listen_task: Optional[asyncio.Task] = None
        self._connected = False

    async def connect(self) -> None:
        """Connect to Redis."""
        self._redis = aioredis.Redis(
            host=self._host,
            port=self._port,
            db=self._db,
            password=self._password,
            decode_responses=True,
            socket_timeout=5,
            socket_connect_timeout=5,
            retry_on_timeout=True,
            max_connections=50,
        )
        await self._redis.ping()
        self._connected = True
        logger.info("Message bus connected to Redis", host=self._host, port=self._port)

    async def disconnect(self) -> None:
        """Disconnect from Redis gracefully."""
        self._connected = False
        if self._listen_task and not self._listen_task.done():
            self._listen_task.cancel()
            try:
                await self._listen_task
            except asyncio.CancelledError:
                pass
        if self._pubsub:
            try:
                await self._pubsub.close()
            except Exception:
                pass
        if self._redis:
            try:
                await self._redis.aclose()
            except Exception:
                pass
        logger.info("Message bus disconnected")

    @property
    def is_connected(self) -> bool:
        return self._connected

    def _channel_for(self, agent_name: str) -> str:
        return f"{self.CHANNEL_PREFIX}{agent_name}"

    async def subscribe(self, agent_name: str, callback: Callable) -> None:
        """Subscribe an agent to receive messages."""
        channel = self._channel_for(agent_name)
        if channel not in self._subscribers:
            self._subscribers[channel] = []
        self._subscribers[channel].append(callback)

        # Also subscribe to broadcast
        broadcast = self.BROADCAST_CHANNEL
        if broadcast not in self._subscribers:
            self._subscribers[broadcast] = []
        if callback not in self._subscribers[broadcast]:
            self._subscribers[broadcast].append(callback)

        if self._pubsub is None:
            self._pubsub = self._redis.pubsub()
            await self._pubsub.subscribe(**{channel: self._route_message, broadcast: self._route_broadcast})
            self._listen_task = asyncio.create_task(self._listen_loop())
        else:
            await self._pubsub.subscribe(**{channel: self._route_message})

        logger.info("Agent subscribed", agent=agent_name, channel=channel)

    async def _route_message(self, message: Dict) -> None:
        """Route incoming messages to registered callbacks."""
        if message["type"] != "message":
            return
        try:
            msg = AgentMessage.from_json(message["data"])
            channel = message["channel"]
            callbacks = self._subscribers.get(channel, [])
            for cb in callbacks:
                asyncio.create_task(cb(msg))
        except Exception as e:
            logger.error("Message routing error", error=str(e))

    async def _route_broadcast(self, message: Dict) -> None:
        """Route broadcast messages to all subscribers."""
        await self._route_message(message)

    async def _listen_loop(self) -> None:
        """Background loop listening for messages."""
        try:
            async for message in self._pubsub.listen():
                if message["type"] == "message":
                    channel = message["channel"]
                    callbacks = self._subscribers.get(channel, [])
                    try:
                        msg = AgentMessage.from_json(message["data"])
                        # Check for pending replies
                        if msg.reply_to and msg.reply_to in self._pending_replies:
                            future = self._pending_replies.pop(msg.reply_to)
                            if not future.done():
                                future.set_result(msg)
                        else:
                            for cb in callbacks:
                                asyncio.create_task(cb(msg))
                    except Exception as e:
                        logger.error("Listen loop error", error=str(e))
        except asyncio.CancelledError:
            pass
        except Exception as e:
            logger.error("Listen loop crashed", error=str(e))

    async def publish(self, message: AgentMessage) -> None:
        """Publish a message to a specific agent."""
        if not self._connected:
            raise RuntimeError("Message bus not connected")
        channel = self._channel_for(message.recipient)
        await self._redis.publish(channel, message.to_json())
        logger.debug(
            "Message published",
            sender=message.sender,
            recipient=message.recipient,
            type=message.message_type,
            message_id=message.message_id,
        )

    async def broadcast(self, sender: str, message_type: str, payload: Dict) -> None:
        """Broadcast a message to all agents."""
        if not self._connected:
            return
        msg = AgentMessage(
            sender=sender,
            recipient="all",
            message_type=message_type,
            payload=payload,
        )
        await self._redis.publish(self.BROADCAST_CHANNEL, msg.to_json())

    async def request(
        self,
        sender: str,
        recipient: str,
        message_type: str,
        payload: Dict,
        timeout: float = 30.0,
        task_id: Optional[str] = None,
    ) -> Optional[AgentMessage]:
        """Send a request and wait for a reply."""
        msg = AgentMessage(
            sender=sender,
            recipient=recipient,
            message_type=message_type,
            payload=payload,
            task_id=task_id,
        )
        future: asyncio.Future = asyncio.get_running_loop().create_future()
        self._pending_replies[msg.message_id] = future

        await self.publish(msg)

        try:
            reply = await asyncio.wait_for(future, timeout=timeout)
            return reply
        except asyncio.TimeoutError:
            self._pending_replies.pop(msg.message_id, None)
            logger.warning(
                "Request timeout",
                sender=sender,
                recipient=recipient,
                message_id=msg.message_id,
            )
            return None

    async def set_cache(self, key: str, value: Any, ttl: int = 300) -> None:
        """Store a value in Redis cache."""
        if self._redis:
            await self._redis.setex(f"mustafa:cache:{key}", ttl, json.dumps(value, default=str))

    async def get_cache(self, key: str) -> Optional[Any]:
        """Retrieve a value from Redis cache."""
        if self._redis:
            data = await self._redis.get(f"mustafa:cache:{key}")
            return json.loads(data) if data else None
        return None

    async def ping(self) -> bool:
        """Test Redis connectivity."""
        try:
            if self._redis:
                await self._redis.ping()
                return True
        except Exception:
            pass
        return False


# Singleton
_bus_instance: Optional[MessageBus] = None


async def get_message_bus() -> MessageBus:
    """Get the global message bus instance."""
    global _bus_instance
    if _bus_instance is None:
        from core.config import get_settings
        settings = get_settings()
        _bus_instance = MessageBus(
            host=settings.redis.host,
            port=settings.redis.port,
            db=settings.redis.db,
            password=settings.redis.password,
        )
    return _bus_instance
