"""MUSTAFA OS - Core Package"""
