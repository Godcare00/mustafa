"""
MUSTAFA OS - Base Agent
Abstract base class. Provides the ReAct tool-calling loop so agents
actually execute tools instead of describing what they would do.
"""

from __future__ import annotations

import asyncio
import json
import re
import uuid
from abc import ABC, abstractmethod
from datetime import datetime
from typing import Any, Dict, List, Optional, Tuple

from core.llm_client import LLMMessage, llm_client
from core.messaging import AgentMessage, message_bus
from core.registry import AgentStatus, agent_registry
from core.reliability import with_timeout
from core.logging_config import AgentLogger
from core.settings import get_agents_config

AUTHORIZED_SENDERS = {"orchestrator", "kernel", "evolution", "monitoring_agent"}

# Identity prefix injected into every agent system prompt so the model
# never defaults to its training-time identity ("I'm created by Arcee AI")
MUSTAFA_OS_IDENTITY = (
    "You are an agent inside MUSTAFA OS (Modular Unified System for Task "
    "Automation and Autonomous Intelligence), a production multi-agent AI OS. "
    "You are NOT a standalone AI assistant. You report to the Orchestrator. "
    "Never identify yourself as a product of any LLM provider. "
    "You are a MUSTAFA OS agent.\n\n"
)


class TaskContext:
    def __init__(
        self,
        task_id: str,
        goal: str,
        payload: Dict[str, Any],
        correlation_id: Optional[str] = None,
        sender: Optional[str] = None,
    ) -> None:
        self.task_id = task_id
        self.goal = goal
        self.payload = payload
        self.correlation_id = correlation_id
        self.sender = sender
        self.created_at = datetime.utcnow()
        self.artifacts: Dict[str, Any] = {}

    def add_artifact(self, name: str, value: Any) -> None:
        self.artifacts[name] = value


class AgentResult:
    def __init__(
        self,
        success: bool,
        data: Any = None,
        error: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> None:
        self.success = success
        self.data = data
        self.error = error
        self.metadata = metadata or {}
        self.timestamp = datetime.utcnow().isoformat()

    def to_dict(self) -> Dict[str, Any]:
        return {
            "success": self.success,
            "data": self.data,
            "error": self.error,
            "metadata": self.metadata,
            "timestamp": self.timestamp,
        }

    @classmethod
    def ok(cls, data: Any, **metadata) -> "AgentResult":
        return cls(success=True, data=data, metadata=metadata)

    @classmethod
    def fail(cls, error: str, **metadata) -> "AgentResult":
        return cls(success=False, error=error, metadata=metadata)


class BaseAgent(ABC):
    """
    Abstract base agent with:
    - Lifecycle management
    - Authorization enforcement (orchestrator-only)
    - think() — single LLM call
    - think_with_tools() — ReAct loop: LLM reasons → calls tool → sees result → reasons again
    """

    def __init__(
        self,
        agent_id: str,
        name: str,
        capabilities: List[str],
        allowed_tools: Optional[List[str]] = None,
    ) -> None:
        self.agent_id = agent_id
        self.name = name
        self.capabilities = capabilities
        self.allowed_tools = allowed_tools or []
        self.logger = AgentLogger(agent_id, name)

        self._config = get_agents_config().get("agents", {}).get(agent_id, {})
        self._model = self._config.get("model", "arcee-ai/trinity-large-preview:free")
        self._max_tokens = self._config.get("max_tokens", 4096)
        self._temperature = self._config.get("temperature", 0.7)
        # Prepend identity to every agent's system prompt
        raw_prompt = self._config.get("system_prompt", "")
        self._system_prompt = MUSTAFA_OS_IDENTITY + raw_prompt

        self._running = False
        self._task_loop: Optional[asyncio.Task] = None
        self._heartbeat_loop: Optional[asyncio.Task] = None
        self._message_queue: asyncio.Queue = asyncio.Queue(maxsize=100)

    # ─── Lifecycle ────────────────────────────────────────────────────────────

    async def start(self) -> None:
        await agent_registry.register(
            agent_id=self.agent_id,
            name=self.name,
            capabilities=self.capabilities,
            instance=self,
        )
        await agent_registry.update_status(self.agent_id, AgentStatus.IDLE)
        await message_bus.subscribe(self.agent_id, self._on_message)

        self._running = True
        self._task_loop = asyncio.create_task(self._process_loop())
        self._heartbeat_loop = asyncio.create_task(self._heartbeat())

        await self.on_start()
        self.logger.info("agent_started", capabilities=self.capabilities)

    async def stop(self) -> None:
        self._running = False
        for task in [self._task_loop, self._heartbeat_loop]:
            if task and not task.done():
                task.cancel()
                try:
                    await task
                except asyncio.CancelledError:
                    pass
        await agent_registry.update_status(self.agent_id, AgentStatus.STOPPED)
        await agent_registry.unregister(self.agent_id)
        await self.on_stop()
        self.logger.info("agent_stopped")

    async def on_start(self) -> None:
        pass

    async def on_stop(self) -> None:
        pass

    # ─── Authorization ────────────────────────────────────────────────────────

    async def _on_message(self, message: AgentMessage) -> None:
        if not self._running:
            return
        if (
            self.agent_id not in AUTHORIZED_SENDERS
            and message.sender not in AUTHORIZED_SENDERS
            and message.message_type not in ("heartbeat", "ping")
        ):
            self.logger.warning(
                "unauthorized_sender_blocked",
                sender=message.sender,
                message_type=message.message_type,
            )
            return
        try:
            await self._message_queue.put_nowait(message)
        except asyncio.QueueFull:
            self.logger.warning("message_queue_full")

    async def _process_loop(self) -> None:
        while self._running:
            try:
                try:
                    message = self._message_queue.get_nowait()
                    await self._handle_message(message)
                    continue
                except asyncio.QueueEmpty:
                    pass
                message = await message_bus.dequeue(self.agent_id, timeout=1)
                if message:
                    if (
                        self.agent_id not in AUTHORIZED_SENDERS
                        and message.sender not in AUTHORIZED_SENDERS
                        and message.message_type not in ("heartbeat", "ping")
                    ):
                        self.logger.warning("unauthorized_queued_message_blocked", sender=message.sender)
                    else:
                        await self._handle_message(message)
                else:
                    await asyncio.sleep(0.1)
            except asyncio.CancelledError:
                break
            except Exception as e:
                self.logger.error("process_loop_error", error=str(e))
                await asyncio.sleep(1)

    async def _handle_message(self, message: AgentMessage) -> None:
        await agent_registry.update_status(
            self.agent_id, AgentStatus.BUSY,
            current_task=message.payload.get("task_id"),
        )
        try:
            context = TaskContext(
                task_id=message.payload.get("task_id", str(uuid.uuid4())),
                goal=message.payload.get("goal", ""),
                payload=message.payload,
                correlation_id=message.correlation_id,
                sender=message.sender,
            )
            result = await with_timeout(
                self.handle_task(message.message_type, context),
                timeout_seconds=self._config.get("timeout", 300),
                error_message=f"Agent {self.agent_id} task timeout",
            )
            await agent_registry.record_task_result(self.agent_id, True)
            if message.correlation_id and message.sender:
                await self._send_result(message, result)
        except Exception as e:
            self.logger.error("task_failed", error=str(e), task_type=message.message_type)
            await agent_registry.record_task_result(self.agent_id, False)
            await agent_registry.update_status(self.agent_id, AgentStatus.IDLE, current_task=None)
            if message.correlation_id and message.sender:
                await self._send_result(message, AgentResult.fail(str(e)))
        finally:
            await agent_registry.update_status(self.agent_id, AgentStatus.IDLE, current_task=None)

    async def _send_result(self, original_message: AgentMessage, result: AgentResult) -> None:
        response = AgentMessage(
            sender=self.agent_id,
            recipient=original_message.sender,
            message_type=f"{original_message.message_type}_result",
            payload={
                "result": result.to_dict(),
                "original_task_id": original_message.payload.get("task_id"),
            },
            correlation_id=original_message.correlation_id,
        )
        await message_bus.publish(response)

    async def _heartbeat(self) -> None:
        from core.settings import settings
        while self._running:
            try:
                await agent_registry.heartbeat(self.agent_id)
                await asyncio.sleep(settings.agent_heartbeat_interval)
            except asyncio.CancelledError:
                break
            except Exception as e:
                self.logger.error("heartbeat_failed", error=str(e))
                await asyncio.sleep(5)

    # ─── Core LLM: single call ────────────────────────────────────────────────

    async def think(
        self,
        prompt: str,
        conversation: Optional[List[LLMMessage]] = None,
        model: Optional[str] = None,
        max_tokens: Optional[int] = None,
        temperature: Optional[float] = None,
        system_prompt: Optional[str] = None,
    ) -> str:
        messages = list(conversation or [])
        messages.append(LLMMessage(role="user", content=prompt))
        response = await llm_client.complete(
            messages=messages,
            model=model or self._model,
            max_tokens=max_tokens or self._max_tokens,
            temperature=temperature if temperature is not None else self._temperature,
            system_prompt=system_prompt if system_prompt is not None else self._system_prompt,
        )
        return response.content

    async def think_json(
        self,
        prompt: str,
        conversation: Optional[List[LLMMessage]] = None,
        model: Optional[str] = None,
    ) -> Dict[str, Any]:
        json_prompt = (
            f"{prompt}\n\n"
            "IMPORTANT: Respond ONLY with valid JSON. "
            "No markdown, no explanation, no code blocks. Pure JSON only."
        )
        response = await self.think(json_prompt, conversation, model)
        cleaned = re.sub(r"```(?:json)?\s*", "", response).strip()
        cleaned = re.sub(r"```\s*$", "", cleaned).strip()
        try:
            return json.loads(cleaned)
        except json.JSONDecodeError as e:
            self.logger.error("json_parse_failed", error=str(e), response_preview=cleaned[:200])
            match = re.search(r"\{.*\}", cleaned, re.DOTALL)
            if match:
                return json.loads(match.group())
            raise ValueError(f"Could not parse JSON from LLM response: {cleaned[:200]}")

    # ─── ReAct tool-calling loop ──────────────────────────────────────────────

    async def think_with_tools(
        self,
        task: str,
        available_tools: List[Dict[str, Any]],
        system_prompt: Optional[str] = None,
        max_iterations: int = 6,
        context_messages: Optional[List[LLMMessage]] = None,
    ) -> Tuple[str, List[Dict[str, Any]]]:
        """
        ReAct (Reasoning + Acting) loop.

        The LLM reasons about the task, optionally calls a tool, sees the real
        result, and reasons again. This repeats until the LLM outputs a final
        answer or max_iterations is reached.

        Protocol: the LLM must output ONLY one of:
          {"action": "tool_call", "tool": "<name>", "params": {...}, "thought": "..."}
          {"action": "answer",    "content": "...",  "thought": "..."}

        Returns:
          (final_answer: str, tool_calls_made: List[dict])
        """
        tool_descriptions = "\n".join([
            f"  - {t['name']}: {t['description']} | params: {t.get('params_hint', 'see tool docs')}"
            for t in available_tools
        ])
        tool_names = [t["name"] for t in available_tools]

        sys = (system_prompt or self._system_prompt) + f"""

TOOL-CALLING PROTOCOL:
You have access to real tools. Use them to complete the task — do NOT simulate or imagine results.

Available tools:
{tool_descriptions}

For EVERY response, output ONLY valid JSON in one of these two forms:

To call a tool:
{{"action": "tool_call", "tool": "<tool_name>", "params": {{...}}, "thought": "why I'm calling this tool"}}

To give the final answer (only when you have all the information needed):
{{"action": "answer", "content": "<your complete answer>", "thought": "I have all the information needed"}}

RULES:
- Always call tools when you need real data — NEVER guess or fabricate results.
- After a tool returns results, analyse them in your next response.
- Only output "answer" when the task is fully complete.
"""
        messages: List[LLMMessage] = list(context_messages or [])
        messages.append(LLMMessage(role="user", content=f"TASK: {task}"))

        tool_calls_made: List[Dict[str, Any]] = []

        for iteration in range(max_iterations):
            response_text = await llm_client.complete(
                messages=messages,
                model=self._model,
                max_tokens=self._max_tokens,
                temperature=self._temperature,
                system_prompt=sys,
            )
            raw = response_text.content

            # Parse JSON response
            decision = self._parse_react_response(raw)

            if not decision:
                # LLM broke protocol — treat as final answer
                self.logger.warning("react_protocol_broken", iteration=iteration, preview=raw[:100])
                return raw, tool_calls_made

            action = decision.get("action")

            if action == "answer":
                return decision.get("content", raw), tool_calls_made

            if action == "tool_call":
                tool_name = decision.get("tool", "")
                params = decision.get("params", {})
                thought = decision.get("thought", "")

                if tool_name not in tool_names:
                    self.logger.warning("react_unknown_tool", tool=tool_name)
                    messages.append(LLMMessage(role="assistant", content=raw))
                    messages.append(LLMMessage(
                        role="user",
                        content=f"TOOL_ERROR: Tool '{tool_name}' does not exist. Available: {tool_names}"
                    ))
                    continue

                # Execute the real tool
                self.logger.info(
                    "react_tool_call",
                    agent=self.agent_id,
                    tool=tool_name,
                    iteration=iteration,
                )
                tool_result = await self._execute_tool(tool_name, params)
                tool_calls_made.append({
                    "tool": tool_name,
                    "params": params,
                    "result": tool_result,
                    "thought": thought,
                })

                # Inject result back into conversation
                messages.append(LLMMessage(role="assistant", content=raw))
                result_text = json.dumps(tool_result, indent=2)[:3000]
                messages.append(LLMMessage(
                    role="user",
                    content=f"TOOL_RESULT ({tool_name}):\n{result_text}\n\nContinue with the task."
                ))
            else:
                # Unknown action
                self.logger.warning("react_unknown_action", action=action)
                return raw, tool_calls_made

        # Max iterations reached — ask for final answer with what we have
        self.logger.warning("react_max_iterations", task=task[:80])
        messages.append(LLMMessage(
            role="user",
            content='Max tool calls reached. Output {"action": "answer", "content": "<your best answer based on gathered data>", "thought": "summarizing"}'
        ))
        final_raw = await llm_client.complete(
            messages=messages, model=self._model,
            max_tokens=self._max_tokens, temperature=self._temperature,
            system_prompt=sys,
        )
        decision = self._parse_react_response(final_raw.content)
        if decision and decision.get("action") == "answer":
            return decision.get("content", final_raw.content), tool_calls_made
        return final_raw.content, tool_calls_made

    def _parse_react_response(self, text: str) -> Optional[Dict[str, Any]]:
        """Extract JSON from LLM response, handling markdown fences."""
        cleaned = re.sub(r"```(?:json)?\s*", "", text).strip()
        cleaned = re.sub(r"```\s*$", "", cleaned).strip()
        try:
            return json.loads(cleaned)
        except json.JSONDecodeError:
            match = re.search(r"\{.*\}", cleaned, re.DOTALL)
            if match:
                try:
                    return json.loads(match.group())
                except json.JSONDecodeError:
                    pass
        return None

    async def _execute_tool(
        self, tool_name: str, params: Dict[str, Any]
    ) -> Dict[str, Any]:
        """Execute a tool via the tool engine."""
        try:
            from tools import get_tool_engine
            engine = get_tool_engine()
            result = await asyncio.wait_for(
                engine.execute(tool_name, self.agent_id, params),
                timeout=60,
            )
            return result.to_dict()
        except asyncio.TimeoutError:
            return {"success": False, "error": f"Tool '{tool_name}' timed out"}
        except Exception as e:
            self.logger.error("tool_execution_failed", tool=tool_name, error=str(e))
            return {"success": False, "error": str(e)}

    def _get_tool_specs(self) -> List[Dict[str, Any]]:
        """Get tool specs for tools this agent is allowed to use."""
        try:
            from tools import get_tool_engine
            engine = get_tool_engine()
            specs = []
            for tool_info in engine.get_all_tools():
                name = tool_info.name
                if "*" in self.allowed_tools or name in self.allowed_tools:
                    specs.append({
                        "name": name,
                        "description": tool_info.description,
                        "params_hint": "see tool documentation",
                    })
            return specs
        except Exception:
            return []

    # ─── Abstract ─────────────────────────────────────────────────────────────

    @abstractmethod
    async def handle_task(self, task_type: str, context: TaskContext) -> AgentResult:
        """Handle an incoming task assigned by the Orchestrator."""
        ...
