"""
MUSTAFA OS - Telegram Bot Interface
Secure Telegram bot with authorized-user-only access to MUSTAFA OS.
"""

from __future__ import annotations

import asyncio
import uuid
from datetime import datetime
from functools import wraps
from typing import Callable, Optional

from core.logging_config import get_logger
from core.settings import settings

logger = get_logger("telegram_bot")


def authorized_only(func: Callable) -> Callable:
    """
    Decorator to restrict bot commands to authorized Telegram users.
    Must handle `self` as first argument because it wraps instance methods —
    PTB calls bound methods as func(self, update, context).
    """
    @wraps(func)
    async def wrapper(self, update, context, *args, **kwargs):
        if update is None or update.effective_user is None:
            return
        user_id = update.effective_user.id
        if user_id not in settings.telegram_user_ids:
            await update.message.reply_text(
                "⛔ Access denied. You are not authorized to use MUSTAFA OS."
            )
            logger.warning(
                "unauthorized_telegram_access",
                user_id=user_id,
                username=update.effective_user.username,
            )
            return
        return await func(self, update, context, *args, **kwargs)
    return wrapper


class MustafaOSTelegramBot:
    """
    Telegram bot interface for MUSTAFA OS.
    Only allows access from pre-authorized Telegram user IDs.
    """

    def __init__(self) -> None:
        self._app = None
        self._kernel = None

    def _check_configured(self) -> bool:
        return bool(settings.telegram_bot_token and
                    settings.telegram_bot_token != "your_telegram_bot_token_here")

    async def start(self, kernel) -> None:
        """Start the Telegram bot."""
        if not self._check_configured():
            logger.warning("telegram_bot_not_configured", message="Set TELEGRAM_BOT_TOKEN in .env")
            return

        if not settings.telegram_user_ids:
            logger.warning("no_authorized_telegram_users", message="Set TELEGRAM_AUTHORIZED_USERS in .env")
            return

        try:
            from telegram import Update
            from telegram.ext import (
                Application,
                CommandHandler,
                MessageHandler,
                filters,
            )

            self._kernel = kernel

            self._app = Application.builder().token(settings.telegram_bot_token).build()

            # Register handlers
            self._app.add_handler(CommandHandler("start", self._cmd_start))
            self._app.add_handler(CommandHandler("help", self._cmd_help))
            self._app.add_handler(CommandHandler("status", self._cmd_status))
            self._app.add_handler(CommandHandler("agents", self._cmd_agents))
            self._app.add_handler(CommandHandler("tasks", self._cmd_tasks))
            self._app.add_handler(CommandHandler("evolve", self._cmd_evolve))
            self._app.add_handler(
                MessageHandler(filters.TEXT & ~filters.COMMAND, self._handle_goal)
            )

            # Start polling in background
            await self._app.initialize()
            await self._app.start()
            await self._app.updater.start_polling(drop_pending_updates=True)

            logger.info(
                "telegram_bot_started",
                authorized_users=settings.telegram_user_ids,
            )

        except ImportError:
            logger.warning("python_telegram_bot_not_installed",
                          message="Run: pip install python-telegram-bot")
        except Exception as e:
            logger.error("telegram_bot_start_failed", error=str(e))

    async def stop(self) -> None:
        if self._app:
            try:
                await self._app.updater.stop()
                await self._app.stop()
                await self._app.shutdown()
            except Exception as e:
                logger.error("telegram_bot_stop_failed", error=str(e))

    @authorized_only
    async def _cmd_start(self, update, context) -> None:
        user = update.effective_user.first_name
        await update.message.reply_text(
            f"👋 Welcome, {user}!\n\n"
            f"*MUSTAFA OS* is ready.\n\n"
            f"Just send me any goal and I'll execute it autonomously.\n\n"
            f"Commands:\n"
            f"/help - Show help\n"
            f"/status - System status\n"
            f"/agents - List agents\n"
            f"/tasks - Recent tasks\n"
            f"/evolve - Trigger self-improvement",
            parse_mode="Markdown",
        )

    @authorized_only
    async def _cmd_help(self, update, context) -> None:
        await update.message.reply_text(
            "*MUSTAFA OS Commands*\n\n"
            "/start - Welcome message\n"
            "/status - System health\n"
            "/agents - All agent statuses\n"
            "/tasks - Recent task history\n"
            "/evolve - Run evolution cycle\n\n"
            "Or just send any text as a goal!",
            parse_mode="Markdown",
        )

    @authorized_only
    async def _cmd_status(self, update, context) -> None:
        if not self._kernel:
            await update.message.reply_text("⚠️ Kernel not available")
            return

        status = self._kernel.get_status()
        summary = status.get("registry_summary", {})

        text = (
            f"*MUSTAFA OS Status*\n\n"
            f"🟢 Running: {'Yes' if status['running'] else 'No'}\n"
            f"⏱ Uptime: {int(status['uptime_seconds'])}s\n"
            f"🤖 Agents: {status['agent_count']}\n"
            f"✅ Idle: {summary.get('idle', 0)}\n"
            f"⚡ Busy: {summary.get('busy', 0)}\n"
            f"❌ Error: {summary.get('error', 0)}\n"
            f"📊 Success Rate: {summary.get('overall_success_rate', 0):.0%}"
        )
        await update.message.reply_text(text, parse_mode="Markdown")

    @authorized_only
    async def _cmd_agents(self, update, context) -> None:
        from core.registry import agent_registry
        agents = agent_registry.get_all_agents()

        if not agents:
            await update.message.reply_text("No agents registered")
            return

        status_emoji = {"idle": "🟢", "busy": "🟡", "error": "🔴", "stopped": "⚫"}
        lines = ["*Registered Agents*\n"]
        for a in agents:
            emoji = status_emoji.get(a.status, "⚪")
            lines.append(f"{emoji} *{a.name}* — {a.status} | {a.task_count} tasks")

        await update.message.reply_text("\n".join(lines), parse_mode="Markdown")

    @authorized_only
    async def _cmd_tasks(self, update, context) -> None:
        try:
            from api.app import _active_tasks
            if not _active_tasks:
                await update.message.reply_text("No tasks this session")
                return

            lines = ["*Recent Tasks*\n"]
            for task in list(_active_tasks.values())[-5:]:
                status_emoji = {"completed": "✅", "failed": "❌", "running": "⏳"}.get(task["status"], "⚪")
                lines.append(
                    f"{status_emoji} `{task['task_id'][:8]}...`\n"
                    f"   {task['goal'][:60]}"
                )
            await update.message.reply_text("\n".join(lines), parse_mode="Markdown")
        except Exception as e:
            await update.message.reply_text(f"Error: {e}")

    @authorized_only
    async def _cmd_evolve(self, update, context) -> None:
        await update.message.reply_text("🧬 Triggering evolution cycle via Orchestrator...")
        try:
            if self._kernel and self._kernel.is_running:
                orchestrator = self._kernel.get_orchestrator()
                if orchestrator:
                    from agents.base import TaskContext
                    ctx = TaskContext(
                        task_id=str(uuid.uuid4()),
                        goal="Run a self-improvement evolution cycle: analyse system performance, identify weaknesses, and propose improvements.",
                        payload={"triggered_by": "telegram"},
                    )
                    asyncio.create_task(orchestrator.handle_task("execute_goal", ctx))
                    await update.message.reply_text("✅ Evolution cycle triggered.")
                else:
                    await update.message.reply_text("⚠️ Orchestrator not available")
            else:
                await update.message.reply_text("⚠️ System not running")
        except Exception as e:
            await update.message.reply_text(f"❌ Failed: {e}")

    @authorized_only
    async def _handle_goal(self, update, context) -> None:
        """Handle a text message as a goal."""
        goal = update.message.text
        task_id = str(uuid.uuid4())

        await update.message.reply_text(
            f"🤔 Processing goal...\n`{goal[:100]}`",
            parse_mode="Markdown",
        )

        try:
            if self._kernel and self._kernel.is_running:
                from agents.base import TaskContext
                orchestrator = self._kernel.get_orchestrator()
                if orchestrator:
                    ctx = TaskContext(
                        task_id=task_id,
                        goal=goal,
                        payload={"goal": goal, "task_id": task_id},
                    )
                    result = await orchestrator.handle_task("execute_goal", ctx)

                    if result.success:
                        answer = result.data.get("answer", str(result.data)) if isinstance(result.data, dict) else str(result.data)
                        # Telegram message limit is 4096 chars
                        if len(answer) > 3800:
                            answer = answer[:3800] + "\n\n[...truncated]"
                        await update.message.reply_text(
                            f"✅ *Result:*\n\n{answer}",
                            parse_mode="Markdown",
                        )
                    else:
                        await update.message.reply_text(f"❌ *Error:* {result.error}", parse_mode="Markdown")
                else:
                    await update.message.reply_text("⚠️ Orchestrator not available")
            else:
                await update.message.reply_text("⚠️ System not fully initialized")
        except Exception as e:
            logger.error("telegram_goal_failed", error=str(e))
            await update.message.reply_text(f"❌ Internal error: {str(e)[:200]}")


# Global singleton
telegram_bot = MustafaOSTelegramBot()
