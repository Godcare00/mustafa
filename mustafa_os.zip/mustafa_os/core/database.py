"""
MUSTAFA OS - Database Manager
Async SQLite with connection pooling for task/agent state persistence.
"""
from __future__ import annotations

import asyncio
import json
import time
import uuid
from contextlib import asynccontextmanager
from pathlib import Path
from typing import Any, AsyncGenerator, Dict, List, Optional

import aiosqlite

from core.logger import get_logger

logger = get_logger("database")


class Database:
    """
    Async SQLite database manager.
    Handles task tracking, agent state, tool registry, and experiment logs.
    """

    def __init__(self, db_path: str):
        self.db_path = db_path
        self._connection: Optional[aiosqlite.Connection] = None
        self._lock = asyncio.Lock()
        Path(db_path).parent.mkdir(parents=True, exist_ok=True)

    async def connect(self) -> None:
        """Initialize database connection and schema."""
        self._connection = await aiosqlite.connect(self.db_path)
        self._connection.row_factory = aiosqlite.Row
        await self._connection.execute("PRAGMA journal_mode=WAL")
        await self._connection.execute("PRAGMA synchronous=NORMAL")
        await self._connection.execute("PRAGMA cache_size=10000")
        await self._init_schema()
        logger.info("Database connected", db_path=self.db_path)

    async def disconnect(self) -> None:
        """Close database connection."""
        if self._connection:
            await self._connection.close()
            self._connection = None
            logger.info("Database disconnected")

    async def _init_schema(self) -> None:
        """Create all tables if they don't exist."""
        schema = """
        CREATE TABLE IF NOT EXISTS tasks (
            id TEXT PRIMARY KEY,
            goal TEXT NOT NULL,
            status TEXT NOT NULL DEFAULT 'pending',
            created_at REAL NOT NULL,
            updated_at REAL NOT NULL,
            completed_at REAL,
            result TEXT,
            error TEXT,
            metadata TEXT DEFAULT '{}'
        );

        CREATE TABLE IF NOT EXISTS agent_executions (
            id TEXT PRIMARY KEY,
            task_id TEXT,
            agent_name TEXT NOT NULL,
            input TEXT NOT NULL,
            output TEXT,
            status TEXT NOT NULL DEFAULT 'running',
            started_at REAL NOT NULL,
            completed_at REAL,
            duration_ms REAL,
            error TEXT,
            FOREIGN KEY (task_id) REFERENCES tasks(id)
        );

        CREATE TABLE IF NOT EXISTS tool_executions (
            id TEXT PRIMARY KEY,
            task_id TEXT,
            agent_execution_id TEXT,
            tool_name TEXT NOT NULL,
            input TEXT NOT NULL,
            output TEXT,
            status TEXT NOT NULL DEFAULT 'running',
            started_at REAL NOT NULL,
            completed_at REAL,
            duration_ms REAL,
            error TEXT
        );

        CREATE TABLE IF NOT EXISTS tool_registry (
            name TEXT PRIMARY KEY,
            description TEXT NOT NULL,
            code TEXT,
            json_schema TEXT NOT NULL,
            permissions TEXT DEFAULT '[]',
            category TEXT DEFAULT 'custom',
            version TEXT DEFAULT '1.0.0',
            is_builtin INTEGER DEFAULT 0,
            created_at REAL NOT NULL,
            updated_at REAL NOT NULL,
            enabled INTEGER DEFAULT 1
        );

        CREATE TABLE IF NOT EXISTS experiments (
            id TEXT PRIMARY KEY,
            name TEXT NOT NULL,
            hypothesis TEXT NOT NULL,
            status TEXT NOT NULL DEFAULT 'proposed',
            proposed_by TEXT,
            created_at REAL NOT NULL,
            started_at REAL,
            completed_at REAL,
            baseline_metrics TEXT,
            experiment_metrics TEXT,
            result TEXT,
            deployed INTEGER DEFAULT 0,
            notes TEXT
        );

        CREATE TABLE IF NOT EXISTS metrics (
            id TEXT PRIMARY KEY,
            metric_name TEXT NOT NULL,
            metric_value REAL NOT NULL,
            labels TEXT DEFAULT '{}',
            recorded_at REAL NOT NULL
        );

        CREATE TABLE IF NOT EXISTS system_events (
            id TEXT PRIMARY KEY,
            event_type TEXT NOT NULL,
            description TEXT NOT NULL,
            severity TEXT DEFAULT 'info',
            data TEXT DEFAULT '{}',
            occurred_at REAL NOT NULL
        );

        CREATE INDEX IF NOT EXISTS idx_tasks_status ON tasks(status);
        CREATE INDEX IF NOT EXISTS idx_tasks_created ON tasks(created_at);
        CREATE INDEX IF NOT EXISTS idx_agent_exec_task ON agent_executions(task_id);
        CREATE INDEX IF NOT EXISTS idx_tool_exec_task ON tool_executions(task_id);
        CREATE INDEX IF NOT EXISTS idx_metrics_name ON metrics(metric_name);
        CREATE INDEX IF NOT EXISTS idx_metrics_time ON metrics(recorded_at);
        CREATE INDEX IF NOT EXISTS idx_events_type ON system_events(event_type);
        """
        await self._connection.executescript(schema)
        await self._connection.commit()

    @asynccontextmanager
    async def _cursor(self) -> AsyncGenerator[aiosqlite.Cursor, None]:
        """Context manager for getting a cursor."""
        async with self._lock:
            cursor = await self._connection.cursor()
            try:
                yield cursor
                await self._connection.commit()
            except Exception:
                await self._connection.rollback()
                raise
            finally:
                await cursor.close()

    # ─── Tasks ────────────────────────────────────────────────────────────────

    async def create_task(self, goal: str, metadata: Optional[Dict] = None) -> str:
        """Create a new task record."""
        task_id = str(uuid.uuid4())
        now = time.time()
        async with self._cursor() as cur:
            await cur.execute(
                """INSERT INTO tasks (id, goal, status, created_at, updated_at, metadata)
                   VALUES (?, ?, 'pending', ?, ?, ?)""",
                (task_id, goal, now, now, json.dumps(metadata or {})),
            )
        return task_id

    async def update_task(
        self,
        task_id: str,
        status: str,
        result: Optional[Any] = None,
        error: Optional[str] = None,
    ) -> None:
        """Update a task's status and result."""
        now = time.time()
        completed_at = now if status in ("completed", "failed", "cancelled") else None
        async with self._cursor() as cur:
            await cur.execute(
                """UPDATE tasks SET status=?, result=?, error=?, updated_at=?, completed_at=?
                   WHERE id=?""",
                (
                    status,
                    json.dumps(result) if result is not None else None,
                    error,
                    now,
                    completed_at,
                    task_id,
                ),
            )

    async def get_task(self, task_id: str) -> Optional[Dict]:
        """Retrieve a task by ID."""
        async with self._cursor() as cur:
            await cur.execute("SELECT * FROM tasks WHERE id=?", (task_id,))
            row = await cur.fetchone()
            return dict(row) if row else None

    async def list_tasks(
        self,
        status: Optional[str] = None,
        limit: int = 50,
        offset: int = 0,
    ) -> List[Dict]:
        """List tasks with optional status filter."""
        async with self._cursor() as cur:
            if status:
                await cur.execute(
                    "SELECT * FROM tasks WHERE status=? ORDER BY created_at DESC LIMIT ? OFFSET ?",
                    (status, limit, offset),
                )
            else:
                await cur.execute(
                    "SELECT * FROM tasks ORDER BY created_at DESC LIMIT ? OFFSET ?",
                    (limit, offset),
                )
            rows = await cur.fetchall()
            return [dict(r) for r in rows]

    # ─── Agent Executions ─────────────────────────────────────────────────────

    async def record_agent_start(
        self, task_id: str, agent_name: str, input_data: Any
    ) -> str:
        """Record the start of an agent execution."""
        exec_id = str(uuid.uuid4())
        now = time.time()
        async with self._cursor() as cur:
            await cur.execute(
                """INSERT INTO agent_executions (id, task_id, agent_name, input, status, started_at)
                   VALUES (?, ?, ?, ?, 'running', ?)""",
                (exec_id, task_id, agent_name, json.dumps(input_data), now),
            )
        return exec_id

    async def record_agent_complete(
        self,
        exec_id: str,
        output: Any = None,
        error: Optional[str] = None,
    ) -> None:
        """Record agent execution completion."""
        now = time.time()
        async with self._cursor() as cur:
            await cur.execute("SELECT started_at FROM agent_executions WHERE id=?", (exec_id,))
            row = await cur.fetchone()
            duration_ms = (now - row["started_at"]) * 1000 if row else None
            status = "failed" if error else "completed"
            await cur.execute(
                """UPDATE agent_executions
                   SET output=?, error=?, status=?, completed_at=?, duration_ms=?
                   WHERE id=?""",
                (json.dumps(output) if output is not None else None, error, status, now, duration_ms, exec_id),
            )

    # ─── Tool Registry ────────────────────────────────────────────────────────

    async def register_tool(
        self,
        name: str,
        description: str,
        json_schema: Dict,
        code: Optional[str] = None,
        permissions: Optional[List[str]] = None,
        category: str = "custom",
        is_builtin: bool = False,
    ) -> None:
        """Register or update a tool in the registry."""
        now = time.time()
        async with self._cursor() as cur:
            await cur.execute(
                """INSERT OR REPLACE INTO tool_registry
                   (name, description, code, json_schema, permissions, category, is_builtin, created_at, updated_at)
                   VALUES (?, ?, ?, ?, ?, ?, ?, COALESCE((SELECT created_at FROM tool_registry WHERE name=?), ?), ?)""",
                (
                    name,
                    description,
                    code,
                    json.dumps(json_schema),
                    json.dumps(permissions or []),
                    category,
                    1 if is_builtin else 0,
                    name,
                    now,
                    now,
                ),
            )

    async def get_tool(self, name: str) -> Optional[Dict]:
        """Get a tool by name."""
        async with self._cursor() as cur:
            await cur.execute("SELECT * FROM tool_registry WHERE name=? AND enabled=1", (name,))
            row = await cur.fetchone()
            if row:
                d = dict(row)
                d["json_schema"] = json.loads(d["json_schema"])
                d["permissions"] = json.loads(d["permissions"])
                return d
            return None

    async def list_tools(self, category: Optional[str] = None) -> List[Dict]:
        """List all enabled tools."""
        async with self._cursor() as cur:
            if category:
                await cur.execute(
                    "SELECT * FROM tool_registry WHERE enabled=1 AND category=?", (category,)
                )
            else:
                await cur.execute("SELECT * FROM tool_registry WHERE enabled=1")
            rows = await cur.fetchall()
            result = []
            for r in rows:
                d = dict(r)
                d["json_schema"] = json.loads(d["json_schema"])
                d["permissions"] = json.loads(d["permissions"])
                result.append(d)
            return result

    # ─── Metrics ──────────────────────────────────────────────────────────────

    async def record_metric(
        self, name: str, value: float, labels: Optional[Dict] = None
    ) -> None:
        """Record a metric data point."""
        async with self._cursor() as cur:
            await cur.execute(
                "INSERT INTO metrics (id, metric_name, metric_value, labels, recorded_at) VALUES (?, ?, ?, ?, ?)",
                (str(uuid.uuid4()), name, value, json.dumps(labels or {}), time.time()),
            )

    async def get_metrics_summary(self, metric_name: str, window_seconds: int = 3600) -> Dict:
        """Get aggregate statistics for a metric."""
        since = time.time() - window_seconds
        async with self._cursor() as cur:
            await cur.execute(
                """SELECT COUNT(*) as count, AVG(metric_value) as avg,
                          MIN(metric_value) as min, MAX(metric_value) as max
                   FROM metrics WHERE metric_name=? AND recorded_at >= ?""",
                (metric_name, since),
            )
            row = await cur.fetchone()
            return dict(row) if row else {}

    # ─── System Events ────────────────────────────────────────────────────────

    async def log_event(
        self,
        event_type: str,
        description: str,
        severity: str = "info",
        data: Optional[Dict] = None,
    ) -> None:
        """Log a system event."""
        async with self._cursor() as cur:
            await cur.execute(
                """INSERT INTO system_events (id, event_type, description, severity, data, occurred_at)
                   VALUES (?, ?, ?, ?, ?, ?)""",
                (
                    str(uuid.uuid4()),
                    event_type,
                    description,
                    severity,
                    json.dumps(data or {}),
                    time.time(),
                ),
            )


# Singleton instance
_db_instance: Optional[Database] = None


async def get_db() -> Database:
    """Get the global database instance."""
    global _db_instance
    if _db_instance is None:
        from core.config import get_settings
        settings = get_settings()
        _db_instance = Database(settings.database.path)
        await _db_instance.connect()
    return _db_instance
