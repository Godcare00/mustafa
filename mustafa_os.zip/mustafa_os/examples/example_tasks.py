"""
MUSTAFA OS - Example Workflows
Demonstrates how to use MUSTAFA OS for common tasks.
These can be run directly or used as reference.

Run with: python examples/example_tasks.py
"""
from __future__ import annotations

import asyncio
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))


async def run_example(name: str, goal: str, context: dict = None) -> None:
    """Run a single example task through MUSTAFA OS."""
    from core.kernel import get_kernel

    print(f"\n{'='*60}")
    print(f"EXAMPLE: {name}")
    print(f"GOAL: {goal}")
    print('='*60)

    kernel = get_kernel()
    result = await kernel.process(
        goal=goal,
        context=context or {},
        session_id=f"example_{name.lower().replace(' ', '_')}",
    )
    print(json.dumps(result, indent=2, default=str))


EXAMPLES = [
    {
        "name": "Web Research",
        "goal": "Research the most popular Python web frameworks in 2025. Provide a structured comparison.",
        "context": {},
    },
    {
        "name": "Code Generation",
        "goal": "Write a Python function that reads a CSV file, calculates the average of a numeric column, and returns a summary dictionary. Include type hints and docstring.",
        "context": {},
    },
    {
        "name": "System Health Check",
        "goal": "Check the health of MUSTAFA OS and report on any issues.",
        "context": {},
    },
    {
        "name": "Data Analysis Plan",
        "goal": "Create a detailed step-by-step plan for analyzing sales data from a CSV file, including data cleaning, aggregation, and visualization.",
        "context": {"data_format": "CSV", "columns": ["date", "product", "quantity", "revenue"]},
    },
    {
        "name": "Tool Discovery",
        "goal": "List all available tools and categorize them by their capabilities. Which tools would be most useful for a data science workflow?",
        "context": {},
    },
    {
        "name": "Memory Test",
        "goal": "Remember this important fact: MUSTAFA OS was created for autonomous multi-agent task orchestration. Then verify you can recall it.",
        "context": {},
    },
    {
        "name": "Code Critique",
        "goal": "Review this Python code and identify issues: def divide(a,b): return a/b",
        "context": {"review_type": "code_quality"},
    },
    {
        "name": "Multi-Step Research",
        "goal": "Find the top 3 open-source LLM providers, compare their pricing models, and recommend the best one for a startup with limited budget.",
        "context": {},
    },
]


async def main() -> None:
    """Run all examples."""
    from core.kernel import get_kernel

    print("""
╔══════════════════════════════════════════╗
║    MUSTAFA OS - Example Workflows         ║
╚══════════════════════════════════════════╝
""")

    # Boot once
    kernel = get_kernel()
    print("Booting MUSTAFA OS...")
    await kernel.boot()
    print("✓ System online\n")

    try:
        # Run first 3 examples to demonstrate capabilities
        for example in EXAMPLES[:3]:
            await run_example(
                name=example["name"],
                goal=example["goal"],
                context=example.get("context", {}),
            )
            await asyncio.sleep(1)  # Small pause between examples

    finally:
        await kernel.shutdown()

    print("\n\nAll examples completed. See MUSTAFA OS docs for more.")


if __name__ == "__main__":
    asyncio.run(main())
