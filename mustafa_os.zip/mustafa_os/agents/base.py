"""
MUSTAFA OS - Base Agent
Abstract base class for all MUSTAFA OS agents.
Provides LLM access, memory, messaging, metrics, and lifecycle management.
"""
from __future__ import annotations

import time
from abc import ABC, abstractmethod
from typing import Any, Dict, List, Optional

from core.config import get_settings
from core.database import get_db
from core.llm_client import LLMClient, LLMMessage, get_llm_client
from core.logger import get_logger
from core.message_bus import AgentMessage, MessageBus
from core.reliability import CircuitBreaker, get_circuit_breaker
from memory.memory_system import MemorySystem

logger = get_logger("base_agent")


class AgentStatus:
    IDLE = "idle"
    RUNNING = "running"
    ERROR = "error"
    OFFLINE = "offline"


class BaseAgent(ABC):
    """
    Abstract base for all MUSTAFA OS agents.
    Each agent has its own LLM connection, memory access, messaging, and metrics.
    """

    agent_name: str = "base_agent"
    agent_description: str = "Base agent"

    def __init__(
        self,
        llm_client: Optional[LLMClient] = None,
        memory_system: Optional[MemorySystem] = None,
        message_bus: Optional[MessageBus] = None,
    ):
        self._llm = llm_client or get_llm_client()
        self._memory = memory_system
        self._bus = message_bus
        self._status = AgentStatus.IDLE
        self._circuit_breaker: CircuitBreaker = get_circuit_breaker(
            f"agent:{self.agent_name}",
            failure_threshold=5,
            recovery_timeout=60.0,
        )
        self._settings = get_settings()
        self._agent_config = self._settings.get_agent_config(self.agent_name)
        self._model = self._agent_config.get("model", self._settings.llm.default_model)
        self._max_tokens = self._agent_config.get("max_tokens", 4096)
        self._temperature = self._agent_config.get("temperature", 0.7)
        self._system_prompt = self._agent_config.get("system_prompt", "")
        self._log = logger.bind(agent=self.agent_name)
        self._tasks_completed = 0
        self._tasks_failed = 0
        self._total_latency_ms = 0.0
        self._last_active: Optional[float] = None

    async def on_startup(self) -> None:
        """Called when agent starts up. Override for initialization."""
        self._status = AgentStatus.IDLE
        self._log.info("Agent started")

    async def on_shutdown(self) -> None:
        """Called when agent shuts down. Override for cleanup."""
        self._status = AgentStatus.OFFLINE
        self._log.info("Agent stopped")

    @abstractmethod
    async def execute(self, task: str, context: Optional[Dict] = None, task_id: Optional[str] = None) -> Any:
        """Execute a task. Must be implemented by all agents."""
        ...

    async def run(
        self,
        task: str,
        context: Optional[Dict] = None,
        task_id: Optional[str] = None,
    ) -> Any:
        """
        Public entry point. Wraps execute() with lifecycle management.
        Records metrics, handles errors, updates status.
        """
        self._status = AgentStatus.RUNNING
        self._last_active = time.time()
        exec_id: Optional[str] = None
        db = None
        start = time.monotonic()

        try:
            db = await get_db()
            exec_id = await db.record_agent_start(
                task_id=task_id or "standalone",
                agent_name=self.agent_name,
                input_data={"task": task, "context": context},
            )

            self._log.info("Executing task", task=task[:100], task_id=task_id)
            result = await self.execute(task=task, context=context, task_id=task_id)

            duration_ms = (time.monotonic() - start) * 1000
            self._tasks_completed += 1
            self._total_latency_ms += duration_ms
            self._status = AgentStatus.IDLE

            if exec_id and db:
                await db.record_agent_complete(exec_id=exec_id, output=result)
            if db:
                await db.record_metric(
                    f"agent.{self.agent_name}.latency_ms", duration_ms
                )

            self._log.info(
                "Task completed",
                task=task[:100],
                duration_ms=round(duration_ms, 1),
            )
            return result

        except Exception as e:
            duration_ms = (time.monotonic() - start) * 1000
            self._tasks_failed += 1
            # Return to IDLE — the agent itself is still functional, just this task failed
            self._status = AgentStatus.IDLE

            if exec_id and db:
                try:
                    await db.record_agent_complete(exec_id=exec_id, error=str(e))
                except Exception:
                    pass  # Best-effort DB recording

            self._log.error(
                "Task failed",
                task=task[:100],
                error=str(e),
                duration_ms=round(duration_ms, 1),
            )
            raise

    async def llm_complete(
        self,
        messages: List[LLMMessage],
        system_prompt: Optional[str] = None,
        json_mode: bool = False,
        max_tokens: Optional[int] = None,
        temperature: Optional[float] = None,
    ) -> str:
        """Execute an LLM completion with this agent's configuration."""
        effective_system = system_prompt or self._system_prompt
        response = await self._llm.complete(
            messages=messages,
            model=self._model,
            max_tokens=max_tokens or self._max_tokens,
            temperature=temperature if temperature is not None else self._temperature,
            system_prompt=effective_system,
            json_mode=json_mode,
        )
        return response.content

    async def llm_complete_json(
        self,
        messages: List[LLMMessage],
        system_prompt: Optional[str] = None,
        max_tokens: Optional[int] = None,
    ) -> Any:
        """Execute an LLM completion and parse result as JSON."""
        effective_system = system_prompt or self._system_prompt
        return await self._llm.complete_json(
            messages=messages,
            model=self._model,
            max_tokens=max_tokens or self._max_tokens,
            temperature=self._temperature,
            system_prompt=effective_system,
        )

    async def store_memory(
        self,
        content: str,
        memory_type: str = "knowledge",
        metadata: Optional[Dict] = None,
    ) -> Optional[str]:
        """Store information in long-term memory."""
        if self._memory:
            return await self._memory.remember(
                content=content,
                memory_type=memory_type,
                metadata={"agent": self.agent_name, **(metadata or {})},
            )
        return None

    async def recall_memory(
        self,
        query: str,
        top_k: int = 5,
        memory_type: Optional[str] = None,
    ) -> List[Any]:
        """Recall relevant memories."""
        if self._memory:
            return await self._memory.recall(query=query, top_k=top_k, memory_type=memory_type)
        return []

    async def send_message(
        self,
        recipient: str,
        message_type: str,
        payload: Dict,
        task_id: Optional[str] = None,
    ) -> None:
        """Send a message to another agent."""
        if self._bus:
            msg = AgentMessage(
                sender=self.agent_name,
                recipient=recipient,
                message_type=message_type,
                payload=payload,
                task_id=task_id,
            )
            await self._bus.publish(msg)

    def get_stats(self) -> Dict:
        """Get agent performance statistics."""
        avg_latency = (
            self._total_latency_ms / max(self._tasks_completed, 1)
        )
        return {
            "agent_name": self.agent_name,
            "status": self._status,
            "tasks_completed": self._tasks_completed,
            "tasks_failed": self._tasks_failed,
            "avg_latency_ms": round(avg_latency, 1),
            "last_active": self._last_active,
            "circuit_breaker": self._circuit_breaker.get_status(),
        }
