"""
MUSTAFA OS - Tool Execution Engine
Plugin-based tool system with permission management and health monitoring.
"""

from __future__ import annotations

import asyncio
import time
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Set, Type

from core.logging_config import get_logger
from core.settings import get_tools_config

logger = get_logger("tools")


@dataclass
class ToolResult:
    """Standardized result from tool execution."""
    success: bool
    data: Optional[Dict[str, Any]] = None
    error: Optional[str] = None
    execution_time: float = 0.0
    tool_name: str = ""

    def to_dict(self) -> Dict[str, Any]:
        return {
            "success": self.success,
            "data": self.data,
            "error": self.error,
            "execution_time": self.execution_time,
            "tool_name": self.tool_name,
        }


@dataclass
class ToolInfo:
    """Metadata about a registered tool."""
    name: str
    description: str
    permissions: List[str] = field(default_factory=list)
    enabled: bool = True
    call_count: int = 0
    error_count: int = 0
    avg_execution_time: float = 0.0

    def to_dict(self) -> Dict[str, Any]:
        return {
            "name": self.name,
            "description": self.description,
            "permissions": self.permissions,
            "enabled": self.enabled,
            "call_count": self.call_count,
            "error_count": self.error_count,
            "avg_execution_time": round(self.avg_execution_time, 3),
            "success_rate": round(
                (self.call_count - self.error_count) / max(self.call_count, 1), 3
            ),
        }


class BaseTool(ABC):
    """
    Abstract base class for all MUSTAFA OS tool plugins.
    
    To create a new tool:
    1. Inherit from BaseTool
    2. Implement the execute() method
    3. Define name, description, and permissions
    4. Place in tools/ or plugins/ directory
    """

    name: str = ""
    description: str = ""
    permissions: List[str] = []
    timeout: int = 30

    @abstractmethod
    async def execute(self, params: Dict[str, Any]) -> ToolResult:
        """
        Execute the tool with the given parameters.
        Must be implemented by all concrete tools.
        """
        ...

    async def validate_params(self, params: Dict[str, Any]) -> Optional[str]:
        """
        Validate input parameters before execution.
        Return error message if invalid, None if valid.
        """
        return None

    def to_dict(self) -> Dict[str, Any]:
        return {
            "name": self.name,
            "description": self.description,
            "permissions": self.permissions,
            "timeout": self.timeout,
        }


class ToolExecutionEngine:
    """
    Central tool execution engine with:
    - Permission enforcement
    - Execution metrics
    - Error isolation
    - Dynamic tool registration
    """

    def __init__(self) -> None:
        self._tools: Dict[str, BaseTool] = {}
        self._agent_permissions: Dict[str, Set[str]] = {}
        self._tool_stats: Dict[str, ToolInfo] = {}

    def register(self, tool: BaseTool) -> None:
        """Register a tool plugin."""
        if not tool.name:
            raise ValueError(f"Tool {type(tool).__name__} has no name defined")

        self._tools[tool.name] = tool
        self._tool_stats[tool.name] = ToolInfo(
            name=tool.name,
            description=tool.description,
            permissions=tool.permissions,
        )
        logger.info("tool_registered", tool_name=tool.name, permissions=tool.permissions)

    def set_agent_permissions(
        self, agent_id: str, allowed_tools: List[str]
    ) -> None:
        """Set which tools an agent is allowed to use."""
        if "*" in allowed_tools:
            # Allow all tools
            self._agent_permissions[agent_id] = {"*"}
        else:
            self._agent_permissions[agent_id] = set(allowed_tools)

    def check_permission(self, agent_id: str, tool_name: str) -> bool:
        """Check if an agent has permission to use a tool."""
        permissions = self._agent_permissions.get(agent_id, set())
        return "*" in permissions or tool_name in permissions

    async def execute(
        self,
        tool_name: str,
        agent_id: str,
        params: Dict[str, Any],
    ) -> ToolResult:
        """
        Execute a tool on behalf of an agent.
        
        Handles:
        - Permission checking
        - Parameter validation
        - Timeout enforcement
        - Error isolation
        - Metrics collection
        """
        # Check tool exists
        tool = self._tools.get(tool_name)
        if not tool:
            logger.error("tool_not_found", tool_name=tool_name, agent_id=agent_id)
            return ToolResult(
                success=False,
                error=f"Tool '{tool_name}' not found",
                tool_name=tool_name,
            )

        # Check permissions
        if not self.check_permission(agent_id, tool_name):
            logger.warning(
                "tool_permission_denied", tool_name=tool_name, agent_id=agent_id
            )
            return ToolResult(
                success=False,
                error=f"Agent '{agent_id}' does not have permission to use '{tool_name}'",
                tool_name=tool_name,
            )

        # Validate params
        validation_error = await tool.validate_params(params)
        if validation_error:
            return ToolResult(
                success=False,
                error=f"Invalid parameters: {validation_error}",
                tool_name=tool_name,
            )

        # Execute with timeout
        start_time = time.monotonic()
        stats = self._tool_stats[tool_name]
        stats.call_count += 1

        try:
            result = await asyncio.wait_for(
                tool.execute(params),
                timeout=tool.timeout,
            )
            result.execution_time = time.monotonic() - start_time
            result.tool_name = tool_name

            # Update stats
            n = stats.call_count
            stats.avg_execution_time = (
                (stats.avg_execution_time * (n - 1) + result.execution_time) / n
            )

            logger.debug(
                "tool_executed",
                tool_name=tool_name,
                agent_id=agent_id,
                success=result.success,
                execution_time=round(result.execution_time, 3),
            )

            return result

        except asyncio.TimeoutError:
            stats.error_count += 1
            elapsed = time.monotonic() - start_time
            logger.error(
                "tool_timeout",
                tool_name=tool_name,
                timeout=tool.timeout,
                elapsed=elapsed,
            )
            return ToolResult(
                success=False,
                error=f"Tool '{tool_name}' timed out after {tool.timeout}s",
                execution_time=elapsed,
                tool_name=tool_name,
            )
        except Exception as e:
            stats.error_count += 1
            elapsed = time.monotonic() - start_time
            logger.error("tool_execution_failed", tool_name=tool_name, error=str(e))
            return ToolResult(
                success=False,
                error=str(e),
                execution_time=elapsed,
                tool_name=tool_name,
            )

    def get_all_tools(self) -> List[ToolInfo]:
        """Get info for all registered tools."""
        return list(self._tool_stats.values())

    def get_tool_info(self, tool_name: str) -> Optional[ToolInfo]:
        return self._tool_stats.get(tool_name)

    async def health_check_all(self) -> Dict[str, Any]:
        """Check health of all tools."""
        return {
            "total_tools": len(self._tools),
            "tools": [info.to_dict() for info in self._tool_stats.values()],
        }

    def initialize_from_config(self) -> None:
        """Initialize tool permissions from YAML config."""
        config = get_tools_config()
        # Default: all tools available to all agents
        # Individual agents set their own permissions in agents.yaml


# ─── Global Singleton ─────────────────────────────────────────────────────────

_tool_engine: Optional[ToolExecutionEngine] = None


def get_tool_engine() -> ToolExecutionEngine:
    """Get or create the global tool execution engine."""
    global _tool_engine
    if _tool_engine is None:
        _tool_engine = ToolExecutionEngine()
        _tool_engine.initialize_from_config()
        _register_builtin_tools(_tool_engine)
    return _tool_engine


def _register_builtin_tools(engine: ToolExecutionEngine) -> None:
    """Register all built-in tools."""
    builtin_registrations = [
        ("tools.web_search",      "WebSearchTool"),
        ("tools.file_manager",    "FileManagerTool"),
        ("tools.api_request",     "APIRequestTool"),
        ("tools.data_analysis",   "DataAnalysisTool"),
        ("tools.code_executor",   "CodeExecutorTool"),
        ("tools.memory_search",   "MemorySearchTool"),
        ("tools.system_metrics",  "SystemMetricsTool"),
        ("tools.database_query",  "DatabaseQueryTool"),
    ]
    for module_path, class_name in builtin_registrations:
        try:
            import importlib
            mod = importlib.import_module(module_path)
            cls = getattr(mod, class_name)
            engine.register(cls())
        except Exception as e:
            logger.warning("builtin_tool_registration_failed", tool=class_name, error=str(e))
