"""
MUSTAFA OS - Orchestrator Agent
The sole entry point. Fully autonomous — no hardcoded pipelines or workflows.
The LLM sees everything (agents, tools, memory, conversation) and decides
what to do, how to do it, and what to do when things fail.
"""

from __future__ import annotations

import asyncio
import json
import re
import uuid
from datetime import datetime
from typing import Any, Dict, List, Optional

from agents.base import AgentResult, BaseAgent, TaskContext, MUSTAFA_OS_IDENTITY
from core.database import TaskRecord, async_session_factory
from core.logging_config import get_logger
from core.registry import agent_registry
from sqlalchemy import select

logger = get_logger("orchestrator")

# ─── Orchestrator system prompt ───────────────────────────────────────────────

ORCHESTRATOR_SYSTEM_PROMPT = MUSTAFA_OS_IDENTITY + """
You are the MUSTAFA OS Orchestrator — the autonomous brain of a multi-agent AI operating system.

You receive every user request. For each one you get:
  - Full list of available agents and their capabilities
  - Full list of available tools and what they do
  - Conversation history with the user
  - Relevant memories from past tasks

YOUR JOB:
Think autonomously about what is needed to fulfil the request. Then act.

DECISION PROCESS (ask yourself each time):
1. Can I answer this directly from knowledge + conversation context? → answer directly.
2. Do I need live data, files, or computation? → call a tool myself.
3. Is this complex enough to need a specialist agent? → dispatch to the right agent.
4. Do I need multiple agents/tools in sequence or parallel? → build a plan and execute it.
5. Is a required capability missing? → request that the Developer agent create a new tool.
6. Did something fail? → try alternatives. If nothing works, tell the user honestly
   and present concrete alternative options. Never silently swallow failures.

TOOL-CALLING PROTOCOL (for steps 2–5):
Output ONLY valid JSON per turn:

Call a tool:
{"action": "tool_call", "tool": "<name>", "params": {...}, "thought": "why"}

Dispatch to an agent (you handle orchestration, agent handles execution):
{"action": "agent_call", "agent": "<agent_id>", "task_type": "<type>", "payload": {...}, "thought": "why"}

Give final answer to user:
{"action": "answer", "content": "<complete response>", "thought": "done"}

Ask user for clarification (when genuinely ambiguous):
{"action": "clarify", "question": "<specific question>", "alternatives": ["option A", "option B"]}

Report failure + alternatives:
{"action": "report_failure", "what_failed": "...", "tried": ["..."], "alternatives": ["...", "..."]}

RULES:
- NEVER fabricate data. If you need real information, call a tool.
- After a tool or agent call, analyse the actual result before continuing.
- Report what you DID, not instructions for the user to follow.
- If you successfully created/modified a file, say the exact path.
- If web search fails, try a different query or different tool.
- You decide parallelism — if two agent calls are independent, fire them simultaneously.
- You can create new tools on the fly by dispatching to the developer agent with task_type="create_tool".
"""


class OrchestratorAgent(BaseAgent):
    """
    Fully autonomous orchestrator. No hardcoded routing, no predefined workflows.
    Every decision — direct answer, tool call, agent dispatch, plan, retry, or
    escalation — is made by the LLM with full awareness of the system state.
    """

    def __init__(self) -> None:
        super().__init__(
            agent_id="orchestrator",
            name="Orchestrator Agent",
            capabilities=[
                "goal_parsing", "autonomous_reasoning", "tool_calling",
                "agent_dispatch", "parallel_execution", "self_healing",
                "conversation_memory", "dynamic_tool_creation",
            ],
            allowed_tools=["*"],
        )
        # Override system prompt with the orchestrator-specific one
        self._system_prompt = ORCHESTRATOR_SYSTEM_PROMPT

    # ─── Public entry point ───────────────────────────────────────────────────

    async def handle_task(self, task_type: str, context: TaskContext) -> AgentResult:
        handlers = {
            "execute_goal":  self._execute_goal,
            "task_status":   self._get_task_status,
            "system_status": self._get_system_status,
        }
        handler = handlers.get(task_type)
        if not handler:
            return AgentResult.fail(f"Unknown task type: {task_type}")
        return await handler(context)

    # ─── Core: fully autonomous execution loop ─────────────────────────────

    async def _execute_goal(self, context: TaskContext) -> AgentResult:
        goal       = context.goal
        task_id    = context.task_id
        session_id = context.payload.get("session_id", task_id)

        self.logger.info("executing_goal", goal=goal[:100], task_id=task_id)
        await self._persist_task(task_id, goal, "running")
        await self._append_conversation(session_id, "user", goal)

        try:
            # Build the full situational context the orchestrator needs
            system_context = await self._build_full_context(goal, session_id)

            # Single autonomous ReAct loop — the LLM controls everything
            final_answer, actions_taken = await self._autonomous_loop(
                goal=goal,
                system_context=system_context,
                task_id=task_id,
            )

            await self._append_conversation(session_id, "assistant", final_answer)
            await self._store_memory(goal, final_answer, task_id)
            await self._persist_task(task_id, goal, "completed", result={"answer": final_answer})

            self.logger.info("goal_completed", task_id=task_id, actions=len(actions_taken))
            return AgentResult.ok(data={"answer": final_answer}, task_id=task_id)

        except Exception as e:
            await self._persist_task(task_id, goal, "failed", error=str(e))
            self.logger.error("goal_failed", task_id=task_id, error=str(e))
            return AgentResult.fail(str(e), task_id=task_id)

    async def _autonomous_loop(
        self,
        goal: str,
        system_context: str,
        task_id: str,
        max_iterations: int = 12,
    ) -> tuple[str, List[Dict[str, Any]]]:
        """
        The single autonomous execution loop.

        The orchestrator LLM:
          - Sees the full system context (agents, tools, memory, history)
          - Decides each action: answer / tool_call / agent_call / clarify / report_failure
          - Receives real results from every action
          - Decides the next action based on accumulated evidence
          - Repeats until it outputs {"action": "answer"} or max iterations

        No hardcoded routing. No predefined workflow. Pure autonomous reasoning.
        """
        from core.llm_client import LLMMessage

        messages: List[LLMMessage] = [
            LLMMessage(role="user", content=f"{system_context}\n\nUSER REQUEST: {goal}")
        ]
        actions_taken: List[Dict[str, Any]] = []

        for iteration in range(max_iterations):
            # Ask the orchestrator LLM what to do next
            response = await self._llm_call(messages)
            decision = self._parse_json_response(response)

            if not decision:
                # LLM broke protocol — treat raw text as final answer
                self.logger.warning("protocol_broken", iteration=iteration, preview=response[:80])
                return response, actions_taken

            action = decision.get("action")
            self.logger.info("orchestrator_action", action=action, iteration=iteration,
                             thought=decision.get("thought", "")[:60])

            # ── Direct answer ──────────────────────────────────────────────
            if action == "answer":
                return decision.get("content", response), actions_taken

            # ── Clarification needed ───────────────────────────────────────
            if action == "clarify":
                question   = decision.get("question", "Could you clarify?")
                alternatives = decision.get("alternatives", [])
                alt_text = "\n".join(f"  • {a}" for a in alternatives) if alternatives else ""
                answer = f"{question}\n\n{alt_text}".strip()
                return answer, actions_taken

            # ── Report failure ─────────────────────────────────────────────
            if action == "report_failure":
                what_failed  = decision.get("what_failed", "An operation failed")
                tried        = decision.get("tried", [])
                alternatives = decision.get("alternatives", [])
                tried_text = "\n".join(f"  • {t}" for t in tried)
                alt_text   = "\n".join(f"  • {a}" for a in alternatives)
                answer = (
                    f"I ran into a problem: **{what_failed}**\n\n"
                    f"What I tried:\n{tried_text}\n\n"
                    f"Alternatives you can consider:\n{alt_text}"
                )
                return answer, actions_taken

            # ── Tool call ──────────────────────────────────────────────────
            if action == "tool_call":
                tool_name = decision.get("tool", "")
                params    = decision.get("params", {})
                thought   = decision.get("thought", "")

                self.logger.info("orchestrator_tool_call", tool=tool_name, iteration=iteration)
                tool_result = await self._call_tool(tool_name, params)
                actions_taken.append({"action": "tool_call", "tool": tool_name, "result": tool_result})

                messages.append(LLMMessage(role="assistant", content=response))
                result_text = json.dumps(tool_result, indent=2, default=str)[:4000]
                messages.append(LLMMessage(
                    role="user",
                    content=f"TOOL_RESULT ({tool_name}):\n{result_text}\n\nContinue."
                ))
                continue

            # ── Agent call (single) ────────────────────────────────────────
            if action == "agent_call":
                agent_id  = decision.get("agent", "")
                task_type = decision.get("task_type", "execute_step")
                payload   = decision.get("payload", {})
                thought   = decision.get("thought", "")

                self.logger.info("orchestrator_agent_call", agent=agent_id, task_type=task_type)
                agent_result = await self._call_agent(agent_id, task_type, payload, task_id)
                actions_taken.append({"action": "agent_call", "agent": agent_id, "result": agent_result})

                messages.append(LLMMessage(role="assistant", content=response))
                result_text = json.dumps(agent_result, indent=2, default=str)[:4000]
                messages.append(LLMMessage(
                    role="user",
                    content=f"AGENT_RESULT ({agent_id}/{task_type}):\n{result_text}\n\nContinue."
                ))
                continue

            # ── Parallel agent/tool calls ──────────────────────────────────
            if action == "parallel_calls":
                calls = decision.get("calls", [])
                if not calls:
                    messages.append(LLMMessage(role="assistant", content=response))
                    messages.append(LLMMessage(role="user", content="parallel_calls had no calls. Continue."))
                    continue

                self.logger.info("orchestrator_parallel_calls", count=len(calls))
                parallel_tasks = []
                for call in calls:
                    if call.get("action") == "tool_call":
                        parallel_tasks.append(self._call_tool(call["tool"], call.get("params", {})))
                    elif call.get("action") == "agent_call":
                        parallel_tasks.append(self._call_agent(
                            call["agent"], call.get("task_type", "execute_step"),
                            call.get("payload", {}), task_id
                        ))

                parallel_results = await asyncio.gather(*parallel_tasks, return_exceptions=True)
                results_summary = []
                for call, result in zip(calls, parallel_results):
                    if isinstance(result, Exception):
                        result = {"success": False, "error": str(result)}
                    label = call.get("tool") or call.get("agent", "unknown")
                    results_summary.append(f"{label}: {json.dumps(result, default=str)[:800]}")
                    actions_taken.append({"action": call.get("action"), "call": call, "result": result})

                messages.append(LLMMessage(role="assistant", content=response))
                messages.append(LLMMessage(
                    role="user",
                    content=f"PARALLEL_RESULTS:\n" + "\n---\n".join(results_summary) + "\n\nContinue."
                ))
                continue

            # Unknown action — treat as final answer
            self.logger.warning("unknown_action", action=action)
            return response, actions_taken

        # Max iterations — request best-effort summary
        messages.append(LLMMessage(role="user", content=(
            'You have reached the iteration limit. Provide your best answer now. '
            'Output: {"action": "answer", "content": "<summary of what was accomplished and any remaining gaps>", "thought": "max iterations"}'
        )))
        final_raw = await self._llm_call(messages)
        decision  = self._parse_json_response(final_raw)
        if decision and decision.get("action") == "answer":
            return decision.get("content", final_raw), actions_taken
        return final_raw, actions_taken

    # ─── Context builder ──────────────────────────────────────────────────────

    async def _build_full_context(self, goal: str, session_id: str) -> str:
        """
        Builds the full situational brief the orchestrator receives before acting.
        Includes: agents, tools, conversation history, relevant memories.
        """
        # Live agents
        agents_text = "\n".join([
            f"  • {a['id']} ({a['name']}) — status: {a['status']} — capabilities: {', '.join(a['capabilities'])}"
            for a in self._get_live_agents()
        ]) or "  (none registered)"

        # Live tools
        tools_text = "\n".join([
            f"  • {t['name']}: {t['description']}"
            for t in self._get_live_tools()
        ]) or "  (none registered)"

        # Conversation history (last 8 turns)
        history = await self._get_conversation(session_id)
        history_text = "\n".join([
            f"  {m['role'].upper()}: {m['content'][:300]}"
            for m in history[-8:]
        ]) if history else "  (no prior conversation)"

        # Relevant memory (top 3 matches)
        memories = await self._recall_memory(goal)
        memory_text = "\n".join([
            f"  [{i+1}] {m.get('content', '')[:200]}"
            for i, m in enumerate(memories)
        ]) if memories else "  (no relevant past experience)"

        self.logger.info(
            "system_context_built",
            agents=len(self._get_live_agents()),
            tools=len(self._get_live_tools()),
            memory_hits=len(memories),
            history_turns=len(history),
        )

        return f"""=== MUSTAFA OS SYSTEM STATE ===

AVAILABLE AGENTS:
{agents_text}

AVAILABLE TOOLS:
{tools_text}

CONVERSATION HISTORY:
{history_text}

RELEVANT PAST EXPERIENCE:
{memory_text}

=============================="""

    def _get_live_agents(self) -> List[Dict[str, Any]]:
        agents = []
        for info in agent_registry.get_all_agents():
            if info.agent_id == "orchestrator":
                continue
            agents.append({
                "id":           info.agent_id,
                "name":         info.name,
                "status":       info.status,
                "capabilities": info.capabilities,
            })
        return agents

    def _get_live_tools(self) -> List[Dict[str, Any]]:
        try:
            from tools import get_tool_engine
            return [
                {"name": t.name, "description": t.description}
                for t in get_tool_engine().get_all_tools()
            ]
        except Exception:
            return []

    # ─── Action executors ─────────────────────────────────────────────────────

    async def _call_tool(
        self, tool_name: str, params: Dict[str, Any]
    ) -> Dict[str, Any]:
        """Execute a tool and return structured result."""
        try:
            from tools import get_tool_engine
            result = await asyncio.wait_for(
                get_tool_engine().execute(tool_name, self.agent_id, params),
                timeout=60,
            )
            return result.to_dict()
        except asyncio.TimeoutError:
            return {"success": False, "error": f"Tool '{tool_name}' timed out after 60s"}
        except Exception as e:
            self.logger.warning("tool_call_failed", tool=tool_name, error=str(e))
            return {"success": False, "error": str(e)}

    async def _call_agent(
        self,
        agent_id: str,
        task_type: str,
        payload: Dict[str, Any],
        task_id: str,
    ) -> Dict[str, Any]:
        """Dispatch a task to a specialist agent and return its result."""
        from core.kernel import kernel
        agent = kernel.get_agent(agent_id)
        if not agent:
            return {"success": False, "error": f"Agent '{agent_id}' not found or not running"}

        try:
            ctx = TaskContext(
                task_id=task_id,
                goal=payload.get("goal", ""),
                payload={**payload, "task_id": task_id},
                sender=self.agent_id,
            )
            result = await asyncio.wait_for(
                agent.handle_task(task_type, ctx),
                timeout=max(payload.get("timeout", 120), 90),
            )
            return result.to_dict()
        except asyncio.TimeoutError:
            return {"success": False, "error": f"Agent '{agent_id}' timed out"}
        except Exception as e:
            self.logger.error("agent_call_failed", agent=agent_id, error=str(e))
            return {"success": False, "error": str(e)}

    # ─── LLM + JSON helpers ───────────────────────────────────────────────────

    async def _llm_call(self, messages) -> str:
        """Call the LLM with the orchestrator system prompt."""
        from core.llm_client import llm_client
        response = await llm_client.complete(
            messages=messages,
            model=self._model,
            max_tokens=self._max_tokens,
            temperature=self._temperature,
            system_prompt=self._system_prompt,
        )
        return response.content

    def _parse_json_response(self, text: str) -> Optional[Dict[str, Any]]:
        """Extract JSON from LLM response, handling markdown fences."""
        cleaned = re.sub(r"```(?:json)?\s*", "", text).strip()
        cleaned = re.sub(r"```\s*$", "", cleaned).strip()
        try:
            return json.loads(cleaned)
        except json.JSONDecodeError:
            match = re.search(r"\{.*\}", cleaned, re.DOTALL)
            if match:
                try:
                    return json.loads(match.group())
                except json.JSONDecodeError:
                    pass
        return None

    # ─── Memory ───────────────────────────────────────────────────────────────

    async def _recall_memory(self, goal: str) -> List[Dict[str, Any]]:
        try:
            from core.kernel import kernel
            mem = kernel.memory
            if not mem or not mem.is_available:
                return []
            return await mem.search(query=goal, collection="task_history", top_k=3)
        except Exception:
            return []

    async def _store_memory(self, goal: str, answer: str, task_id: str) -> None:
        try:
            from core.kernel import kernel
            mem = kernel.memory
            if mem and mem.is_available:
                asyncio.create_task(mem.store(
                    content=f"GOAL: {goal}\nANSWER: {answer[:500]}",
                    metadata={
                        "goal": goal[:200],
                        "task_id": task_id,
                        "agent": "orchestrator",
                        "timestamp": datetime.utcnow().isoformat(),
                    },
                    collection="task_history",
                ))
        except Exception:
            pass

    # ─── Conversation ─────────────────────────────────────────────────────────

    async def _append_conversation(self, session_id: str, role: str, content: str) -> None:
        try:
            from memory.short_term import short_term_memory
            await short_term_memory.append_history(session_id, role, content)
        except Exception:
            pass

    async def _get_conversation(self, session_id: str, limit: int = 10) -> List[Dict[str, Any]]:
        try:
            from memory.short_term import short_term_memory
            return await short_term_memory.get_history(session_id, limit=limit)
        except Exception:
            return []

    # ─── Dynamic tool creation ────────────────────────────────────────────────

    async def create_tool_dynamically(
        self, tool_name: str, description: str, capability_needed: str
    ) -> bool:
        """Request a new tool be created and hot-loaded. Called from the autonomous loop."""
        result = await self._call_agent(
            "developer", "create_tool",
            {
                "goal": f"Create a MUSTAFA OS tool named '{tool_name}': {description}",
                "tool_spec": {
                    "name": tool_name,
                    "description": description,
                    "capability": capability_needed,
                },
            },
            str(uuid.uuid4()),
        )
        return result.get("success", False)

    # ─── Status / DB ─────────────────────────────────────────────────────────

    async def _get_task_status(self, context: TaskContext) -> AgentResult:
        task_id = context.payload.get("task_id")
        if not task_id:
            return AgentResult.fail("task_id required")
        async with async_session_factory() as session:
            result = await session.execute(select(TaskRecord).where(TaskRecord.id == task_id))
            task = result.scalar_one_or_none()
        if not task:
            return AgentResult.fail(f"Task {task_id} not found")
        return AgentResult.ok({
            "task_id":    task.id,
            "status":     task.status,
            "goal":       task.goal,
            "result":     task.result,
            "created_at": task.created_at.isoformat(),
        })

    async def _get_system_status(self, context: TaskContext) -> AgentResult:
        return AgentResult.ok({
            "agents": self._get_live_agents(),
            "tools":  self._get_live_tools(),
            "registry": agent_registry.get_system_summary(),
        })

    async def _persist_task(
        self,
        task_id: str,
        goal: str,
        status: str,
        plan: Optional[Dict] = None,
        result: Optional[Dict] = None,
        error: Optional[str] = None,
    ) -> None:
        try:
            async with async_session_factory() as session:
                existing = await session.get(TaskRecord, task_id)
                if existing:
                    existing.status = status
                    if plan:   existing.plan   = plan
                    if result: existing.result = result
                    if error:  existing.error  = error
                    if status == "completed":
                        existing.completed_at = datetime.utcnow()
                else:
                    session.add(TaskRecord(
                        id=task_id, goal=goal, status=status,
                        assigned_agent=self.agent_id,
                        plan=plan, result=result, error=error,
                    ))
                await session.commit()
        except Exception as e:
            self.logger.error("task_persist_failed", error=str(e))
