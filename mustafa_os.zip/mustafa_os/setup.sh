#!/usr/bin/env bash
# ═══════════════════════════════════════════════════════════════════════════════
# MUSTAFA OS - Automated Setup Script
# Installs all dependencies, configures environment, initializes databases,
# and starts a full health check to confirm the system is ready.
#
# Usage:
#   chmod +x setup.sh
#   ./setup.sh
#
# The script will:
#   1. Check Python version (3.10+ required)
#   2. Install Redis
#   3. Create virtual environment
#   4. Install Python dependencies
#   5. Configure .env file (prompts for API key)
#   6. Create required directories
#   7. Initialize databases
#   8. Run system health check
#   9. Print quick-start instructions
# ═══════════════════════════════════════════════════════════════════════════════

set -euo pipefail

# ─── Colors ────────────────────────────────────────────────────────────────────
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
BOLD='\033[1m'
RESET='\033[0m'

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
VENV_DIR="$SCRIPT_DIR/.venv"
LOG_FILE="$SCRIPT_DIR/logs/setup.log"

mkdir -p "$SCRIPT_DIR/logs"
exec > >(tee -a "$LOG_FILE") 2>&1

# ─── Helpers ───────────────────────────────────────────────────────────────────
print_banner() {
    echo -e "${CYAN}${BOLD}"
    echo "╔══════════════════════════════════════════════════════════════╗"
    echo "║              MUSTAFA OS - Setup & Installation               ║"
    echo "║  Modular Unified System for Task Automation & Intelligence   ║"
    echo "╚══════════════════════════════════════════════════════════════╝"
    echo -e "${RESET}"
}

step() {
    echo -e "\n${CYAN}${BOLD}[STEP]${RESET} $1"
}

ok() {
    echo -e "${GREEN}  ✓ $1${RESET}"
}

warn() {
    echo -e "${YELLOW}  ⚠ $1${RESET}"
}

fail() {
    echo -e "${RED}  ✗ $1${RESET}"
    exit 1
}

info() {
    echo -e "  ${CYAN}→ $1${RESET}"
}

# ─── Step 1: Check OS and Python ──────────────────────────────────────────────
print_banner
step "Checking system requirements"

# Python version check
if command -v python3 &>/dev/null; then
    PYTHON_CMD="python3"
elif command -v python &>/dev/null; then
    PYTHON_CMD="python"
else
    fail "Python 3.10+ is required but not found. Install from https://python.org"
fi

PYTHON_VERSION=$($PYTHON_CMD --version 2>&1 | awk '{print $2}')
PYTHON_MAJOR=$(echo "$PYTHON_VERSION" | cut -d. -f1)
PYTHON_MINOR=$(echo "$PYTHON_VERSION" | cut -d. -f2)

if [[ "$PYTHON_MAJOR" -lt 3 ]] || { [[ "$PYTHON_MAJOR" -eq 3 ]] && [[ "$PYTHON_MINOR" -lt 10 ]]; }; then
    fail "Python 3.10+ required. Found: $PYTHON_VERSION"
fi
ok "Python $PYTHON_VERSION detected"

# Check pip
if ! $PYTHON_CMD -m pip --version &>/dev/null; then
    fail "pip not found. Install pip for Python $PYTHON_VERSION"
fi
ok "pip available"

# ─── Step 2: Install Redis ─────────────────────────────────────────────────────
step "Installing Redis"

if command -v redis-server &>/dev/null; then
    ok "Redis already installed: $(redis-server --version | head -1)"
else
    info "Installing Redis..."
    OS="$(uname -s)"
    case "$OS" in
        Linux*)
            if command -v apt-get &>/dev/null; then
                sudo apt-get update -qq && sudo apt-get install -y redis-server
            elif command -v yum &>/dev/null; then
                sudo yum install -y redis
            elif command -v pacman &>/dev/null; then
                sudo pacman -Sy --noconfirm redis
            else
                warn "Cannot auto-install Redis. Please install manually: https://redis.io/download"
            fi
            ;;
        Darwin*)
            if command -v brew &>/dev/null; then
                brew install redis
            else
                warn "Homebrew not found. Install Redis manually or via: brew install redis"
            fi
            ;;
        *)
            warn "Unknown OS. Please install Redis manually: https://redis.io/download"
            ;;
    esac

    if command -v redis-server &>/dev/null; then
        ok "Redis installed"
    else
        warn "Redis installation may have failed. MUSTAFA OS will run without Redis (limited functionality)"
    fi
fi

# Start Redis if not running
if command -v redis-cli &>/dev/null; then
    if redis-cli ping &>/dev/null 2>&1; then
        ok "Redis is running"
    else
        info "Starting Redis..."
        if command -v systemctl &>/dev/null && systemctl is-enabled redis &>/dev/null 2>&1; then
            sudo systemctl start redis || true
        elif command -v brew &>/dev/null && [[ "$(uname)" == "Darwin" ]]; then
            brew services start redis || redis-server --daemonize yes
        else
            redis-server --daemonize yes --loglevel warning || true
        fi
        sleep 1
        if redis-cli ping &>/dev/null 2>&1; then
            ok "Redis started"
        else
            warn "Could not start Redis automatically. Start manually: redis-server"
        fi
    fi
fi

# ─── Step 3: Create Virtual Environment ───────────────────────────────────────
step "Setting up Python virtual environment"

if [[ ! -d "$VENV_DIR" ]]; then
    info "Creating virtual environment at $VENV_DIR"
    $PYTHON_CMD -m venv "$VENV_DIR"
    ok "Virtual environment created"
else
    ok "Virtual environment already exists"
fi

# Activate
source "$VENV_DIR/bin/activate"
PYTHON="$VENV_DIR/bin/python"
PIP="$VENV_DIR/bin/pip"

ok "Virtual environment activated"

# ─── Step 4: Install Python Dependencies ──────────────────────────────────────
step "Installing Python dependencies"

info "Upgrading pip..."
"$PIP" install --upgrade pip -q

info "Installing requirements (this may take a few minutes)..."
"$PIP" install -r "$SCRIPT_DIR/requirements.txt" -q

ok "Core dependencies installed"

# Optional: try installing chromadb separately (large package)
info "Installing ChromaDB for vector memory..."
"$PIP" install chromadb -q && ok "ChromaDB installed" || warn "ChromaDB installation failed — long-term memory will be disabled"

# Optional: sentence-transformers
info "Installing sentence-transformers for embeddings..."
"$PIP" install sentence-transformers -q && ok "Sentence-transformers installed" || warn "Sentence-transformers failed — embeddings may use fallback"

# ─── Step 5: Configure Environment ────────────────────────────────────────────
step "Configuring environment"

ENV_FILE="$SCRIPT_DIR/.env"

if [[ -f "$ENV_FILE" ]]; then
    warn ".env file already exists. Skipping creation."
    info "To reconfigure, delete .env and run setup.sh again."
else
    cp "$SCRIPT_DIR/.env.template" "$ENV_FILE"
    info "Created .env from template"

    echo ""
    echo -e "${BOLD}${YELLOW}CONFIGURATION REQUIRED${RESET}"
    echo "────────────────────────────────────────────"
    echo ""

    # Prompt for OpenRouter API key
    read -p "  Enter your OpenRouter API key (get one at https://openrouter.ai): " OPENROUTER_KEY
    if [[ -n "$OPENROUTER_KEY" ]]; then
        sed -i "s|your_openrouter_api_key_here|$OPENROUTER_KEY|g" "$ENV_FILE"
        ok "OpenRouter API key configured"
    else
        warn "No API key provided. Edit .env manually before running MUSTAFA OS."
    fi

    # Generate secret key
    SECRET_KEY=$(openssl rand -hex 32 2>/dev/null || $PYTHON -c "import secrets; print(secrets.token_hex(32))")
    sed -i "s|change_this_to_a_random_secret_key_64_chars|$SECRET_KEY|g" "$ENV_FILE"
    ok "Secret key generated"

    # Prompt for Telegram bot token (optional)
    echo ""
    read -p "  Telegram Bot Token (optional, press Enter to skip): " TG_TOKEN
    if [[ -n "$TG_TOKEN" ]]; then
        sed -i "s|TELEGRAM_BOT_TOKEN=|TELEGRAM_BOT_TOKEN=$TG_TOKEN|g" "$ENV_FILE"
        read -p "  Authorized Telegram User IDs (comma-separated, e.g. 123456,789012): " TG_USERS
        if [[ -n "$TG_USERS" ]]; then
            sed -i "s|TELEGRAM_AUTHORIZED_USERS=123456789,987654321|TELEGRAM_AUTHORIZED_USERS=$TG_USERS|g" "$ENV_FILE"
        fi
        # Enable telegram in system.yaml
        sed -i "s|enabled: false|enabled: true|g" "$SCRIPT_DIR/config/system.yaml"
        ok "Telegram bot configured"
    else
        info "Telegram bot skipped (can be configured later in .env)"
    fi
fi

# ─── Step 6: Create Required Directories ──────────────────────────────────────
step "Creating directory structure"

mkdir -p "$SCRIPT_DIR/data"
mkdir -p "$SCRIPT_DIR/data/chroma_db"
mkdir -p "$SCRIPT_DIR/logs"
mkdir -p "$SCRIPT_DIR/tmp/mustafa_sandbox"

ok "Directories created"

# ─── Step 7: Initialize Database ──────────────────────────────────────────────
step "Initializing database"

DB_INIT_SCRIPT="
import sys, asyncio
sys.path.insert(0, '$SCRIPT_DIR')
from core.database import Database

async def init():
    db = Database('$SCRIPT_DIR/data/mustafa_os.db')
    await db.connect()
    print('  ✓ Database schema initialized')
    # Register built-in tools
    import yaml
    with open('$SCRIPT_DIR/config/tools.yaml') as f:
        tools_cfg = yaml.safe_load(f)
    for name, cfg in tools_cfg.items():
        await db.register_tool(
            name=name,
            description=cfg.get('description', ''),
            json_schema=cfg.get('schema', {}),
            permissions=cfg.get('permissions', []),
            category=cfg.get('category', 'builtin'),
            is_builtin=True,
        )
    print(f'  ✓ Registered {len(tools_cfg)} built-in tools')
    await db.log_event('system_setup', 'MUSTAFA OS initialized via setup.sh')
    await db.disconnect()

asyncio.run(init())
"

"$PYTHON" -c "$DB_INIT_SCRIPT" && ok "Database initialized" || warn "Database initialization had issues — will retry on first boot"

# ─── Step 8: Create Convenience Scripts ───────────────────────────────────────
step "Creating launch scripts"

# Server launcher
cat > "$SCRIPT_DIR/start_server.sh" << 'SERVERSCRIPT'
#!/usr/bin/env bash
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$SCRIPT_DIR/.venv/bin/activate"
echo "Starting MUSTAFA OS API Server..."
python "$SCRIPT_DIR/main.py" server
SERVERSCRIPT
chmod +x "$SCRIPT_DIR/start_server.sh"

# CLI launcher
cat > "$SCRIPT_DIR/start_cli.sh" << 'CLISCRIPT'
#!/usr/bin/env bash
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$SCRIPT_DIR/.venv/bin/activate"
python "$SCRIPT_DIR/main.py" cli
CLISCRIPT
chmod +x "$SCRIPT_DIR/start_cli.sh"

# Telegram launcher
cat > "$SCRIPT_DIR/start_telegram.sh" << 'TGSCRIPT'
#!/usr/bin/env bash
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$SCRIPT_DIR/.venv/bin/activate"
python "$SCRIPT_DIR/main.py" telegram
TGSCRIPT
chmod +x "$SCRIPT_DIR/start_telegram.sh"

# Test runner
cat > "$SCRIPT_DIR/run_tests.sh" << 'TESTSCRIPT'
#!/usr/bin/env bash
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$SCRIPT_DIR/.venv/bin/activate"
cd "$SCRIPT_DIR"
python -m pytest tests/ -v --tb=short
TESTSCRIPT
chmod +x "$SCRIPT_DIR/run_tests.sh"

ok "Launch scripts created"

# ─── Step 9: System Health Check ──────────────────────────────────────────────
step "Running system health check"

HEALTH_SCRIPT="
import sys, asyncio
sys.path.insert(0, '$SCRIPT_DIR')

async def check():
    checks = {}
    
    # Check .env
    from pathlib import Path
    env_ok = Path('$SCRIPT_DIR/.env').exists()
    checks['env_file'] = 'ok' if env_ok else 'missing'
    
    # Check API key
    from dotenv import load_dotenv
    import os
    load_dotenv('$SCRIPT_DIR/.env')
    api_key = os.getenv('OPENROUTER_API_KEY', '')
    checks['api_key'] = 'configured' if api_key and api_key != 'your_openrouter_api_key_here' else 'NOT SET'
    
    # Check database
    try:
        from core.database import Database
        db = Database('$SCRIPT_DIR/data/mustafa_os.db')
        await db.connect()
        tasks = await db.list_tasks(limit=1)
        await db.disconnect()
        checks['database'] = 'ok'
    except Exception as e:
        checks['database'] = f'error: {e}'
    
    # Check Redis
    try:
        import redis.asyncio as aioredis
        r = aioredis.Redis(host='localhost', port=6379)
        await r.ping()
        await r.close()
        checks['redis'] = 'ok'
    except Exception as e:
        checks['redis'] = f'unavailable (ok for initial boot)'
    
    # Check ChromaDB
    try:
        import chromadb
        checks['chromadb'] = 'ok'
    except ImportError:
        checks['chromadb'] = 'not installed (long-term memory disabled)'
    
    print()
    all_ok = True
    for check, result in checks.items():
        ok_icon = '✓' if result in ('ok', 'configured') or result.startswith('ok') else ('⚠' if 'unavailable' in result or 'not installed' in result else '✗')
        color = '\033[92m' if ok_icon == '✓' else ('\033[93m' if ok_icon == '⚠' else '\033[91m')
        print(f'  {color}{ok_icon}\033[0m {check}: {result}')
        if ok_icon == '✗':
            all_ok = False
    
    print()
    if all_ok:
        print('  \033[92m\033[1m✓ MUSTAFA OS is ready to run!\033[0m')
    else:
        print('  \033[93m⚠ Some checks need attention (see above)\033[0m')

asyncio.run(check())
"

"$PYTHON" -c "$HEALTH_SCRIPT"

# ─── Step 10: Final Instructions ──────────────────────────────────────────────
echo ""
echo -e "${CYAN}${BOLD}═══════════════════════════════════════════════════════════════${RESET}"
echo -e "${GREEN}${BOLD}  MUSTAFA OS Setup Complete!${RESET}"
echo -e "${CYAN}${BOLD}═══════════════════════════════════════════════════════════════${RESET}"
echo ""
echo -e "${BOLD}  Quick Start:${RESET}"
echo ""
echo -e "  ${CYAN}Start CLI (recommended for first run):${RESET}"
echo -e "    ./start_cli.sh"
echo ""
echo -e "  ${CYAN}Start API Server:${RESET}"
echo -e "    ./start_server.sh"
echo -e "    Then open: http://localhost:8000/docs"
echo ""
echo -e "  ${CYAN}Start Telegram Bot:${RESET}"
echo -e "    ./start_telegram.sh"
echo ""
echo -e "  ${CYAN}Run Tests:${RESET}"
echo -e "    ./run_tests.sh"
echo ""
echo -e "  ${YELLOW}Note: Ensure your OpenRouter API key is set in .env${RESET}"
echo -e "  ${YELLOW}      before sending tasks to MUSTAFA OS.${RESET}"
echo ""
echo -e "  Full docs: ${CYAN}./docs/README.md${RESET}"
echo ""
echo -e "${CYAN}${BOLD}═══════════════════════════════════════════════════════════════${RESET}"
echo ""
