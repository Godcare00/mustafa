"""
MUSTAFA OS - Tool Execution Engine
Dynamic plugin-based tool system with JSON schema validation,
sandboxing, permissions, and runtime tool creation.
"""
from __future__ import annotations

import asyncio
import json
import os
import sys
import tempfile
import time
from pathlib import Path
from typing import Any, Dict, List, Optional

import httpx
import jsonschema

from core.config import get_settings
from core.database import get_db
from core.logger import get_logger

logger = get_logger("tool_engine")

TOOLS_DIR = Path(__file__).parent.parent / "tools"


async def _safe_bg_tool(coro: Any) -> None:
    """Silent background executor for non-critical tool bookkeeping."""
    try:
        await coro
    except Exception:
        pass


class ToolResult:
    """Standardized tool execution result."""

    def __init__(
        self,
        tool_name: str,
        success: bool,
        output: Any = None,
        error: Optional[str] = None,
        duration_ms: float = 0.0,
    ):
        self.tool_name = tool_name
        self.success = success
        self.output = output
        self.error = error
        self.duration_ms = duration_ms

    def to_dict(self) -> Dict:
        return {
            "tool": self.tool_name,
            "success": self.success,
            "output": self.output,
            "error": self.error,
            "duration_ms": round(self.duration_ms, 1),
        }


class ToolPermissionError(Exception):
    """Raised when a tool execution is denied due to permissions."""
    pass


class ToolValidationError(Exception):
    """Raised when tool input fails JSON schema validation."""
    pass


class ToolNotFoundError(Exception):
    """Raised when a tool is not found in the registry."""
    pass


# ─── Built-in Tool Implementations ───────────────────────────────────────────

async def _search_via_serpapi(
    query: str, max_results: int, api_key: str
) -> Dict:
    """
    Search using SerpAPI (Google Search).
    Returns structured results with title, url, snippet.
    """
    async with httpx.AsyncClient(timeout=20.0) as client:
        response = await client.get(
            "https://serpapi.com/search",
            params={
                "q": query,
                "api_key": api_key,
                "num": max_results,
                "hl": "en",
                "gl": "us",
            },
        )
        if response.status_code != 200:
            raise RuntimeError(f"SerpAPI returned HTTP {response.status_code}: {response.text[:200]}")

        data = response.json()

        # Check for API-level errors
        if "error" in data:
            raise RuntimeError(f"SerpAPI error: {data['error']}")

        results = []

        # Answer box — fast factual answer
        if data.get("answer_box"):
            box = data["answer_box"]
            snippet = (
                box.get("answer")
                or box.get("snippet")
                or box.get("result")
                or ""
            )
            if snippet:
                results.append({
                    "title": box.get("title", "Direct Answer"),
                    "url": box.get("link", ""),
                    "snippet": str(snippet),
                    "source": "answer_box",
                })

        # Organic results
        for r in data.get("organic_results", [])[:max_results]:
            results.append({
                "title": r.get("title", ""),
                "url": r.get("link", ""),
                "snippet": r.get("snippet", ""),
                "source": "organic",
            })

        # Knowledge graph
        kg = data.get("knowledge_graph")
        if kg and not results:
            results.append({
                "title": kg.get("title", ""),
                "url": kg.get("website", ""),
                "snippet": kg.get("description", ""),
                "source": "knowledge_graph",
            })

        return {
            "results": results[:max_results],
            "query": query,
            "total_results": len(results),
            "provider": "serpapi",
        }


async def _search_via_ddgs(query: str, max_results: int) -> Dict:
    """
    Search using DuckDuckGo Search (duckduckgo-search library).
    Falls back to the instant answer API if the library is not installed.
    """
    # Try duckduckgo-search library first (proper web results)
    try:
        from duckduckgo_search import DDGS
        with DDGS() as ddgs:
            raw = list(ddgs.text(query, max_results=max_results))
        results = [
            {
                "title": r.get("title", ""),
                "url": r.get("href", ""),
                "snippet": r.get("body", ""),
                "source": "ddgs",
            }
            for r in raw
            if r.get("title") or r.get("body")
        ]
        if results:
            return {
                "results": results[:max_results],
                "query": query,
                "total_results": len(results),
                "provider": "ddgs",
            }
    except ImportError:
        pass  # Library not installed, fall through to instant answer API
    except Exception:
        pass  # DDGS failed, fall through

    # Fallback: DuckDuckGo Instant Answer API
    async with httpx.AsyncClient(timeout=20.0) as client:
        response = await client.get(
            "https://api.duckduckgo.com/",
            params={
                "q": query,
                "format": "json",
                "no_html": "1",
                "skip_disambig": "1",
            },
        )
        data = response.json()

        results = []
        if data.get("AbstractText"):
            results.append({
                "title": data.get("Heading", query),
                "url": data.get("AbstractURL", ""),
                "snippet": data["AbstractText"],
                "source": "ddg_instant",
            })
        for topic in data.get("RelatedTopics", [])[:max_results]:
            if isinstance(topic, dict) and topic.get("Text"):
                results.append({
                    "title": topic.get("Text", "")[:80],
                    "url": topic.get("FirstURL", ""),
                    "snippet": topic.get("Text", ""),
                    "source": "ddg_instant",
                })

        if not results:
            raise RuntimeError("DuckDuckGo returned no results")

        return {
            "results": results[:max_results],
            "query": query,
            "total_results": len(results),
            "provider": "ddg_instant",
        }


async def _tool_web_search(query: str, max_results: int = 5) -> Dict:
    """
    Web search with SerpAPI (primary) and DuckDuckGo (fallback).
    Tries each provider up to 2 attempts total. If both fail, returns a
    structured error the orchestrator can surface to the user.
    """
    serpapi_key = os.environ.get("SERPAPI_KEY", "").strip()
    max_attempts = 2
    attempts_made = []
    last_error = ""

    for attempt in range(1, max_attempts + 1):
        # Attempt 1: SerpAPI (if key is configured)
        if attempt == 1 and serpapi_key:
            try:
                logger.info("web_search: trying SerpAPI", query=query[:80])
                result = await _search_via_serpapi(query, max_results, serpapi_key)
                logger.info("web_search: SerpAPI succeeded", results=result["total_results"])
                return result
            except Exception as e:
                last_error = f"SerpAPI: {e}"
                attempts_made.append(f"SerpAPI failed: {e}")
                logger.warning("web_search: SerpAPI failed, trying DDGS", error=str(e))
                # Use attempt 2 for DDGS below
                try:
                    result = await _search_via_ddgs(query, max_results)
                    logger.info("web_search: DDGS fallback succeeded", provider=result["provider"])
                    result["fallback_used"] = True
                    result["fallback_reason"] = last_error
                    return result
                except Exception as e2:
                    last_error = f"DDGS: {e2}"
                    attempts_made.append(f"DDGS failed: {e2}")
                    break  # Both attempted, give up

        # Attempt 1: DDGS (no SerpAPI key configured)
        if attempt == 1 and not serpapi_key:
            try:
                logger.info("web_search: no SerpAPI key, using DDGS", query=query[:80])
                result = await _search_via_ddgs(query, max_results)
                logger.info("web_search: DDGS succeeded", provider=result["provider"])
                return result
            except Exception as e:
                last_error = f"DDGS attempt 1: {e}"
                attempts_made.append(f"DDGS attempt 1 failed: {e}")
                logger.warning("web_search: DDGS attempt 1 failed, retrying", error=str(e))
                continue

        # Attempt 2: DDGS retry (no SerpAPI key)
        if attempt == 2 and not serpapi_key:
            try:
                await asyncio.sleep(1.0)  # Brief pause before retry
                result = await _search_via_ddgs(query, max_results)
                logger.info("web_search: DDGS retry succeeded")
                return result
            except Exception as e:
                last_error = f"DDGS attempt 2: {e}"
                attempts_made.append(f"DDGS attempt 2 failed: {e}")
                break

    # All attempts exhausted — return structured failure the orchestrator can report
    logger.error("web_search: all attempts failed", query=query[:80], attempts=attempts_made)
    return {
        "results": [],
        "query": query,
        "total_results": 0,
        "error": (
            f"Web search failed after {len(attempts_made)} attempt(s). "
            f"Last error: {last_error}. "
            "Please inform the user that search is currently unavailable and suggest "
            "they try again or provide the information manually."
        ),
        "search_failed": True,
        "attempts": attempts_made,
    }


async def _tool_read_file(path: str, encoding: str = "utf-8", max_bytes: int = 1_048_576) -> Dict:
    """Read file contents."""
    try:
        p = Path(path).expanduser().resolve()
        if not p.exists():
            return {"error": f"File not found: {path}", "content": None}
        if not p.is_file():
            return {"error": f"Not a file: {path}", "content": None}
        size = p.stat().st_size
        content = p.read_text(encoding=encoding)[:max_bytes]
        return {
            "content": content,
            "path": str(p),
            "size_bytes": size,
            "encoding": encoding,
        }
    except Exception as e:
        return {"error": str(e), "content": None, "path": path}


async def _tool_write_file(path: str, content: str, mode: str = "write", encoding: str = "utf-8") -> Dict:
    """Write content to file."""
    try:
        p = Path(path).expanduser().resolve()
        p.parent.mkdir(parents=True, exist_ok=True)
        file_mode = "a" if mode == "append" else "w"
        with open(p, file_mode, encoding=encoding) as fh:
            fh.write(content)
        return {"success": True, "path": str(p), "bytes_written": len(content.encode(encoding))}
    except Exception as e:
        return {"success": False, "error": str(e), "path": path}


async def _tool_execute_shell(
    command: str,
    working_directory: str = "/tmp/mustafa_sandbox",
    timeout: int = 30,
    env_vars: Optional[Dict] = None,
) -> Dict:
    """Execute a shell command in sandbox."""
    settings = get_settings()
    if not settings.security.sandbox_enabled:
        return {"error": "Shell execution is disabled", "return_code": -1}

    # Basic command allowlist check
    BLOCKED_PATTERNS = ["rm -rf /", "mkfs", "dd if=/dev/zero", "> /dev/sd", "chmod 777 /"]
    for pattern in BLOCKED_PATTERNS:
        if pattern in command:
            return {"error": f"Blocked command pattern: {pattern}", "return_code": -1, "stdout": "", "stderr": ""}

    try:
        work_dir = Path(working_directory)
        work_dir.mkdir(parents=True, exist_ok=True)
        env = {**os.environ, **(env_vars or {})}
        start = time.monotonic()
        proc = await asyncio.create_subprocess_shell(
            command,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
            cwd=str(work_dir),
            env=env,
        )
        try:
            stdout, stderr = await asyncio.wait_for(proc.communicate(), timeout=timeout)
            elapsed = (time.monotonic() - start) * 1000
            return {
                "stdout": stdout.decode("utf-8", errors="replace"),
                "stderr": stderr.decode("utf-8", errors="replace"),
                "return_code": proc.returncode,
                "execution_time": round(elapsed / 1000, 3),
                "timed_out": False,
            }
        except asyncio.TimeoutError:
            proc.kill()
            return {"stdout": "", "stderr": "", "return_code": -1, "execution_time": timeout, "timed_out": True}
    except Exception as e:
        return {"stdout": "", "stderr": str(e), "return_code": -1, "execution_time": 0, "timed_out": False}


async def _tool_python_eval(code: str, timeout: int = 15, capture_output: bool = True) -> Dict:
    """Execute Python code in a subprocess (isolated from the main process)."""
    start = time.monotonic()
    tmp_path: Optional[str] = None
    try:
        with tempfile.NamedTemporaryFile(mode="w", suffix=".py", delete=False, dir="/tmp") as f:
            f.write(code)
            tmp_path = f.name

        proc = await asyncio.create_subprocess_exec(
            sys.executable, tmp_path,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
        try:
            stdout, stderr = await asyncio.wait_for(proc.communicate(), timeout=timeout)
        except asyncio.TimeoutError:
            try:
                proc.kill()
                await proc.communicate()
            except Exception:
                pass
            return {
                "stdout": "", "stderr": "Execution timed out",
                "result": None,
                "execution_time": timeout,
                "success": False,
                "error": "Timeout",
            }

        elapsed = (time.monotonic() - start) * 1000
        stderr_text = stderr.decode("utf-8", errors="replace")
        return {
            "stdout": stdout.decode("utf-8", errors="replace"),
            "stderr": stderr_text,
            "result": None,
            "execution_time": round(elapsed / 1000, 3),
            "success": proc.returncode == 0,
            "error": stderr_text if proc.returncode != 0 else None,
        }
    except Exception as e:
        return {"stdout": "", "stderr": str(e), "result": None,
                "execution_time": 0, "success": False, "error": str(e)}
    finally:
        if tmp_path and os.path.exists(tmp_path):
            try:
                os.unlink(tmp_path)
            except OSError:
                pass


async def _tool_http_request(
    url: str,
    method: str = "GET",
    headers: Optional[Dict] = None,
    body: Optional[Dict] = None,
    params: Optional[Dict] = None,
    timeout: int = 30,
) -> Dict:
    """Make HTTP requests."""
    try:
        start = time.monotonic()
        async with httpx.AsyncClient(timeout=timeout, follow_redirects=True) as client:
            response = await client.request(
                method=method,
                url=url,
                headers=headers,
                json=body,
                params=params,
            )
            elapsed_ms = (time.monotonic() - start) * 1000
            return {
                "status_code": response.status_code,
                "headers": dict(response.headers),
                "body": response.text[:50000],  # Cap at 50KB
                "elapsed_ms": round(elapsed_ms, 1),
                "success": 200 <= response.status_code < 300,
            }
    except Exception as e:
        return {"status_code": 0, "headers": {}, "body": "", "elapsed_ms": 0, "success": False, "error": str(e)}


async def _tool_list_directory(path: str, recursive: bool = False, show_hidden: bool = False) -> Dict:
    """List directory contents."""
    try:
        p = Path(path).expanduser().resolve()
        if not p.exists():
            return {"error": f"Path not found: {path}", "entries": []}
        if not p.is_dir():
            return {"error": f"Not a directory: {path}", "entries": []}

        entries = []
        iterator = p.rglob("*") if recursive else p.iterdir()
        for entry in iterator:
            if not show_hidden and entry.name.startswith("."):
                continue
            stat = entry.stat()
            entries.append({
                "name": entry.name,
                "path": str(entry),
                "type": "directory" if entry.is_dir() else "file",
                "size_bytes": stat.st_size if entry.is_file() else 0,
                "modified": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime(stat.st_mtime)),
            })
        return {"path": str(p), "entries": entries, "total_entries": len(entries)}
    except Exception as e:
        return {"error": str(e), "entries": [], "path": path}


async def _tool_system_status(
    include_agents: bool = True,
    include_metrics: bool = True,
    include_tasks: bool = True,
) -> Dict:
    """Get current MUSTAFA OS system health and status metrics."""
    try:
        from core.reliability import get_all_circuit_breakers
        db = await get_db()
        result: Dict[str, Any] = {
            "status": "healthy",
            "timestamp": time.time(),
        }
        if include_tasks:
            tasks = await db.list_tasks(limit=50)
            completed = sum(1 for t in tasks if t["status"] == "completed")
            failed = sum(1 for t in tasks if t["status"] == "failed")
            pending = sum(1 for t in tasks if t["status"] in ("pending", "running"))
            result["tasks"] = {
                "total": len(tasks),
                "completed": completed,
                "failed": failed,
                "pending": pending,
                "success_rate": round(completed / max(len(tasks), 1) * 100, 1),
            }
            if failed > 0 and len(tasks) > 0 and (failed / len(tasks)) > 0.3:
                result["status"] = "degraded"

        if include_metrics:
            cbs = get_all_circuit_breakers()
            open_cbs = [n for n, cb in cbs.items() if cb["state"] == "open"]
            result["circuit_breakers"] = cbs
            if open_cbs:
                result["status"] = "degraded"
                result["alerts"] = [f"Circuit breakers open: {', '.join(open_cbs)}"]

        return result
    except Exception as e:
        return {"status": "error", "error": str(e)}


async def _tool_memory_store(
    content: str,
    metadata: Optional[Dict] = None,
    memory_type: str = "knowledge",
) -> Dict:
    """Store information in long-term vector memory."""
    try:
        from memory.memory_system import get_memory_system
        memory = get_memory_system()
        memory_id = await memory.remember(
            content=content,
            memory_type=memory_type,
            metadata=metadata or {},
        )
        return {"memory_id": memory_id, "success": True}
    except Exception as e:
        return {"success": False, "error": str(e)}


async def _tool_memory_retrieve(
    query: str,
    top_k: int = 5,
    memory_type: str = "all",
) -> Dict:
    """Retrieve relevant memories using semantic search."""
    try:
        from memory.memory_system import get_memory_system
        memory = get_memory_system()
        effective_type = None if memory_type == "all" else memory_type
        memories = await memory.recall(query=query, top_k=top_k, memory_type=effective_type)
        return {
            "query": query,
            "memories": [
                {
                    "id": m.id,
                    "content": m.content,
                    "type": m.memory_type,
                    "relevance_score": round(m.relevance_score, 3),
                }
                for m in memories
            ],
            "total_found": len(memories),
        }
    except Exception as e:
        return {"query": query, "memories": [], "total_found": 0, "error": str(e)}


async def _tool_create_tool(
    tool_name: str,
    description: str,
    code: str,
    json_schema: Dict,
    permissions: Optional[List[str]] = None,
    dependencies: Optional[List[str]] = None,
) -> Dict:
    """Dynamically create and register a new tool."""
    engine = get_tool_engine()
    success = await engine.register_dynamic_tool(
        tool_name=tool_name,
        description=description,
        code=code,
        json_schema=json_schema,
        permissions=permissions or [],
        dependencies=dependencies or [],
    )
    return {
        "success": success,
        "tool_id": tool_name,
        "message": f"Tool '{tool_name}' registered." if success else "Registration failed.",
    }


async def _tool_upgrade_tool(
    tool_name: str,
    new_code: str,
    new_schema: Optional[Dict] = None,
    changelog: str = "",
) -> Dict:
    """Upgrade an existing tool's implementation."""
    try:
        db = await get_db()
        existing = await db.get_tool(tool_name)
        if not existing:
            return {"success": False, "error": f"Tool '{tool_name}' not found"}

        compile(new_code, f"<tool:{tool_name}>", "exec")  # validate syntax

        await db.register_tool(
            name=tool_name,
            description=existing["description"],
            json_schema=new_schema or existing["json_schema"],
            code=new_code,
            permissions=existing.get("permissions", []),
            category=existing.get("category", "custom"),
            is_builtin=False,
        )
        return {"success": True, "tool_name": tool_name, "message": f"Upgraded. {changelog}"}
    except SyntaxError as e:
        return {"success": False, "error": f"Syntax error in new code: {e}"}
    except Exception as e:
        return {"success": False, "error": str(e)}


# Map of builtin tool names to their implementations
BUILTIN_TOOLS: Dict[str, Any] = {
    "web_search": _tool_web_search,
    "read_file": _tool_read_file,
    "write_file": _tool_write_file,
    "execute_shell": _tool_execute_shell,
    "python_eval": _tool_python_eval,
    "http_request": _tool_http_request,
    "list_directory": _tool_list_directory,
    "system_status": _tool_system_status,
    "memory_store": _tool_memory_store,
    "memory_retrieve": _tool_memory_retrieve,
    "create_tool": _tool_create_tool,
    "upgrade_tool": _tool_upgrade_tool,
}



class ToolEngine:
    """
    Plugin-based tool execution engine.
    Loads tools from config, supports dynamic registration, validates inputs,
    enforces permissions, and records execution metrics.
    """

    def __init__(self):
        self._dynamic_tools: Dict[str, Any] = {}
        self._settings = get_settings()
        self._initialized = False
        self._tool_list_cache: Optional[List[Dict]] = None  # Invalidated on registration

    def _invalidate_tool_cache(self) -> None:
        self._tool_list_cache = None

    async def initialize(self) -> None:
        """Initialize tool engine: register builtins from config."""
        db = await get_db()
        tools_cfg = self._settings.tools_config

        for tool_name, tool_cfg in tools_cfg.items():
            schema = tool_cfg.get("schema", {})
            await db.register_tool(
                name=tool_name,
                description=tool_cfg.get("description", ""),
                json_schema=schema,
                permissions=tool_cfg.get("permissions", []),
                category=tool_cfg.get("category", "builtin"),
                is_builtin=True,
            )

        self._initialized = True
        self._invalidate_tool_cache()
        logger.info("Tool engine initialized", tool_count=len(tools_cfg))

    async def execute(
        self,
        tool_name: str,
        params: Dict[str, Any],
        task_id: Optional[str] = None,
        agent_name: str = "system",
    ) -> ToolResult:
        """
        Execute a tool by name with given parameters.
        Validates input for custom/dynamic tools only; builtins skip validation.
        Metric writes are fire-and-forget to avoid blocking the caller.
        """
        start = time.monotonic()

        try:
            # Get tool definition
            tool_def = await self._get_tool_def(tool_name)
            if not tool_def:
                raise ToolNotFoundError(f"Tool '{tool_name}' not found")

            # Only validate input for custom/dynamic tools.
            # Builtins are always called with correct params by the orchestrator.
            if not tool_def.get("is_builtin", False):
                schema = tool_def.get("json_schema", {})
                input_schema = schema.get("input", schema)
                if input_schema:
                    try:
                        jsonschema.validate(instance=params, schema=input_schema)
                    except jsonschema.ValidationError as e:
                        raise ToolValidationError(f"Input validation failed: {e.message}")

            # Execute tool
            output = await self._dispatch(tool_name, params, tool_def)
            duration_ms = (time.monotonic() - start) * 1000

            # Metric writes — fire and forget
            db = await get_db()
            asyncio.create_task(_safe_bg_tool(db.record_metric(f"tool.{tool_name}.latency_ms", duration_ms)))

            logger.info(
                "Tool executed",
                tool=tool_name,
                duration_ms=round(duration_ms, 1),
                agent=agent_name,
            )

            return ToolResult(
                tool_name=tool_name,
                success=True,
                output=output,
                duration_ms=duration_ms,
            )

        except (ToolNotFoundError, ToolValidationError, ToolPermissionError) as e:
            duration_ms = (time.monotonic() - start) * 1000
            logger.warning("Tool execution blocked", tool=tool_name, error=str(e))
            return ToolResult(tool_name=tool_name, success=False, error=str(e), duration_ms=duration_ms)
        except Exception as e:
            duration_ms = (time.monotonic() - start) * 1000
            logger.error("Tool execution failed", tool=tool_name, error=str(e))
            db = await get_db()
            await db.record_metric(f"tool.{tool_name}.error", 1.0)
            return ToolResult(
                tool_name=tool_name,
                success=False,
                error=str(e),
                duration_ms=duration_ms,
            )

    async def _get_tool_def(self, tool_name: str) -> Optional[Dict]:
        """Get tool definition from DB or dynamic registry."""
        db = await get_db()
        return await db.get_tool(tool_name)

    async def _dispatch(self, tool_name: str, params: Dict, tool_def: Dict) -> Any:
        """Dispatch tool execution to builtin or dynamic implementation."""
        # Check built-in tools
        if tool_name in BUILTIN_TOOLS:
            fn = BUILTIN_TOOLS[tool_name]
            return await fn(**params)

        # Check dynamic tools (created at runtime)
        if tool_name in self._dynamic_tools:
            fn = self._dynamic_tools[tool_name]
            return await fn(**params)

        # Try to execute code stored in DB
        tool_def_from_db = await (await get_db()).get_tool(tool_name)
        if tool_def_from_db and tool_def_from_db.get("code"):
            return await self._execute_dynamic_code(
                tool_name, tool_def_from_db["code"], params
            )

        raise ToolNotFoundError(f"No implementation found for tool: {tool_name}")

    async def _execute_dynamic_code(self, tool_name: str, code: str, params: Dict) -> Any:
        """Execute dynamically created tool code."""
        namespace: Dict = {}
        exec(compile(code, f"<tool:{tool_name}>", "exec"), namespace)

        # Find the main function
        fn = namespace.get("execute") or namespace.get(tool_name) or namespace.get("run")
        if not fn:
            raise ToolNotFoundError(f"Dynamic tool '{tool_name}' has no execute/run function")

        if asyncio.iscoroutinefunction(fn):
            return await fn(**params)
        else:
            return fn(**params)

    async def register_dynamic_tool(
        self,
        tool_name: str,
        description: str,
        code: str,
        json_schema: Dict,
        permissions: Optional[List[str]] = None,
        dependencies: Optional[List[str]] = None,
    ) -> bool:
        """Register a new tool created at runtime."""
        try:
            # Install dependencies if needed
            if dependencies:
                for dep in dependencies:
                    logger.info(f"Installing dependency: {dep}")
                    proc = await asyncio.create_subprocess_exec(
                        sys.executable, "-m", "pip", "install", dep, "-q",
                        stdout=asyncio.subprocess.PIPE,
                        stderr=asyncio.subprocess.PIPE,
                    )
                    await proc.communicate()

            # Validate code compiles
            compile(code, f"<tool:{tool_name}>", "exec")

            # Register in database
            db = await get_db()
            await db.register_tool(
                name=tool_name,
                description=description,
                json_schema=json_schema,
                code=code,
                permissions=permissions or [],
                category="custom",
                is_builtin=False,
            )

            logger.info("Dynamic tool registered", tool=tool_name)
            self._invalidate_tool_cache()  # Force fresh list on next request
            return True
        except SyntaxError as e:
            logger.error("Tool code has syntax error", tool=tool_name, error=str(e))
            return False
        except Exception as e:
            logger.error("Tool registration failed", tool=tool_name, error=str(e))
            return False

    async def list_all_tools(self) -> List[Dict]:
        """Get all registered tools. Cached to avoid repeated DB reads."""
        if self._tool_list_cache is not None:
            return self._tool_list_cache
        db = await get_db()
        self._tool_list_cache = await db.list_tools()
        return self._tool_list_cache

    async def get_tools_manifest(self) -> str:
        """
        Compact tool manifest for the orchestrator.
        Only name, description and category — no full JSON schemas.
        The orchestrator decides WHICH tool to use; the engine handles validation.
        """
        tools = await self.list_all_tools()
        manifest = [
            {
                "name": t["name"],
                "description": t["description"],
                "category": t.get("category", "unknown"),
            }
            for t in tools
        ]
        return json.dumps(manifest, indent=2)


# Singleton
_tool_engine: Optional[ToolEngine] = None


def get_tool_engine() -> ToolEngine:
    """Get the global tool engine instance."""
    global _tool_engine
    if _tool_engine is None:
        _tool_engine = ToolEngine()
    return _tool_engine
