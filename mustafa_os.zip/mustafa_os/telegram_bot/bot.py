"""
MUSTAFA OS - Telegram Bot Interface
Secure Telegram bot with authorized-user-only access to MUSTAFA OS.
"""

from __future__ import annotations

import asyncio
import uuid
from datetime import datetime
from functools import wraps
from typing import Callable, Optional

from core.logging_config import get_logger
from core.settings import settings

logger = get_logger("telegram_bot")


def authorized_only(func: Callable) -> Callable:
    """
    Decorator to restrict bot commands to authorized Telegram users.
    Must handle `self` as first argument because it wraps instance methods —
    PTB calls bound methods as func(self, update, context).
    """
    @wraps(func)
    async def wrapper(self, update, context, *args, **kwargs):
        if update is None or update.effective_user is None:
            return
        user_id = update.effective_user.id
        if user_id not in settings.telegram_user_ids:
            await update.message.reply_text(
                "⛔ Access denied. You are not authorized to use MUSTAFA OS."
            )
            logger.warning(
                "unauthorized_telegram_access",
                user_id=user_id,
                username=update.effective_user.username,
            )
            return
        return await func(self, update, context, *args, **kwargs)
    return wrapper


class MustafaOSTelegramBot:
    """
    Telegram bot interface for MUSTAFA OS.
    Only allows access from pre-authorized Telegram user IDs.
    """

    def __init__(self) -> None:
        self._app = None
        self._kernel = None

    def _check_configured(self) -> bool:
        return bool(settings.telegram_bot_token and
                    settings.telegram_bot_token != "your_telegram_bot_token_here")

    async def start(self, kernel) -> None:
        """Start the Telegram bot."""
        if not self._check_configured():
            logger.warning("telegram_bot_not_configured", message="Set TELEGRAM_BOT_TOKEN in .env")
            return

        if not settings.telegram_user_ids:
            logger.warning("no_authorized_telegram_users", message="Set TELEGRAM_AUTHORIZED_USERS in .env")
            return

        try:
            from telegram import Update
            from telegram.ext import (
                Application,
                CommandHandler,
                MessageHandler,
                filters,
            )

            self._kernel = kernel

            self._app = Application.builder().token(settings.telegram_bot_token).build()

            # Register handlers
            self._app.add_handler(CommandHandler("start",  self._cmd_start))
            self._app.add_handler(CommandHandler("help",   self._cmd_help))
            self._app.add_handler(CommandHandler("status", self._cmd_status))
            self._app.add_handler(CommandHandler("agents", self._cmd_agents))
            self._app.add_handler(CommandHandler("tasks",  self._cmd_tasks))
            self._app.add_handler(CommandHandler("evolve", self._cmd_evolve))
            # Incoming file/image handlers
            self._app.add_handler(MessageHandler(filters.Document.ALL, self._handle_document))
            self._app.add_handler(MessageHandler(filters.PHOTO,        self._handle_photo))
            # Text messages (after file handlers so documents with captions don't double-fire)
            self._app.add_handler(
                MessageHandler(filters.TEXT & ~filters.COMMAND, self._handle_goal)
            )

            # Start polling in background
            await self._app.initialize()
            await self._app.start()
            await self._app.updater.start_polling(drop_pending_updates=True)

            logger.info(
                "telegram_bot_started",
                authorized_users=settings.telegram_user_ids,
            )

        except ImportError:
            logger.warning("python_telegram_bot_not_installed",
                          message="Run: pip install python-telegram-bot")
        except Exception as e:
            logger.error("telegram_bot_start_failed", error=str(e))

    async def stop(self) -> None:
        if self._app:
            try:
                await self._app.updater.stop()
                await self._app.stop()
                await self._app.shutdown()
            except Exception as e:
                logger.error("telegram_bot_stop_failed", error=str(e))

    async def _send_attachments(self, update, data: dict) -> bool:
        """
        Send any files created during task execution as Telegram attachments.
        Checks both 'files_created' (from developer agent) and scans the answer
        for file paths. Returns True if at least one file was sent.
        """
        import os

        sent = False
        # Collect candidate file paths from result data
        candidates: list[str] = []

        # Developer agent reports files_created explicitly
        for path in data.get("files_created", []):
            candidates.append(path)

        # Also scan the answer text for file paths like ./data/something.ext
        answer = data.get("answer", "")
        import re
        found = re.findall(r'(?:\./)?(data|plugins|logs|experiments)/[\w./\-]+\.\w+', answer)
        for match in found:
            full = f"./{match}" if not match.startswith("./") else match
            candidates.append(full)

        # Deduplicate while preserving order
        seen = set()
        unique = []
        for p in candidates:
            norm = os.path.normpath(p)
            if norm not in seen:
                seen.add(norm)
                unique.append(norm)

        for path in unique:
            if not os.path.isfile(path):
                continue
            size = os.path.getsize(path)
            if size == 0 or size > 50 * 1024 * 1024:  # skip empty or > 50MB
                continue
            try:
                filename = os.path.basename(path)
                ext = os.path.splitext(filename)[1].lower()

                with open(path, "rb") as f:
                    content = f.read()

                # Choose send method based on file type
                if ext in (".png", ".jpg", ".jpeg", ".gif", ".webp"):
                    await update.message.reply_photo(
                        photo=content,
                        caption=f"📎 {filename}",
                    )
                elif ext in (".mp4", ".mov", ".avi"):
                    await update.message.reply_video(
                        video=content,
                        caption=f"🎬 {filename}",
                    )
                elif ext in (".mp3", ".wav", ".ogg", ".m4a"):
                    await update.message.reply_audio(
                        audio=content,
                        caption=f"🎵 {filename}",
                    )
                else:
                    # Send as document (covers .txt, .py, .json, .csv, .pdf, .zip, etc.)
                    from telegram import InputFile
                    import io
                    await update.message.reply_document(
                        document=InputFile(io.BytesIO(content), filename=filename),
                        caption=f"📄 {filename}",
                    )
                logger.info("telegram_attachment_sent", path=path, size=size)
                sent = True
            except Exception as e:
                logger.warning("telegram_attachment_failed", path=path, error=str(e))

        return sent

    @authorized_only
    async def _handle_document(self, update, context) -> None:
        """
        Handle a file sent by the user. Downloads it to ./data/uploads/,
        then passes the path to the orchestrator so agents can work with it.
        """
        import os
        doc      = update.message.document
        caption  = update.message.caption or f"Process this file: {doc.file_name}"
        task_id  = str(uuid.uuid4())
        session_id = self._get_session_id(update.effective_user.id)

        await update.message.reply_text(f"📥 Receiving {doc.file_name}...")

        try:
            # Download the file
            upload_dir = "./data/uploads"
            os.makedirs(upload_dir, exist_ok=True)
            file_path  = os.path.join(upload_dir, doc.file_name)

            tg_file = await context.bot.get_file(doc.file_id)
            await tg_file.download_to_drive(file_path)

            logger.info("telegram_file_received", filename=doc.file_name, path=file_path)

            if self._kernel and self._kernel.is_running:
                from agents.base import TaskContext
                orchestrator = self._kernel.get_orchestrator()
                if orchestrator:
                    goal = f"{caption}\n\n[Attached file saved at: {file_path}]"
                    ctx  = TaskContext(
                        task_id=task_id,
                        goal=goal,
                        payload={
                            "goal":        goal,
                            "task_id":     task_id,
                            "session_id":  session_id,
                            "file_path":   file_path,
                            "file_name":   doc.file_name,
                        },
                    )
                    result = await orchestrator.handle_task("execute_goal", ctx)

                    if result.success:
                        data   = result.data if isinstance(result.data, dict) else {}
                        answer = data.get("answer", str(result.data))
                        await self._send_attachments(update, data)
                        if len(answer) > 3800:
                            answer = answer[:3800] + "\n\n[...truncated]"
                        await self._safe_reply(update, f"✅ {answer}")
                    else:
                        await self._safe_reply(update, f"❌ {result.error}")
            else:
                await update.message.reply_text("⚠️ System not ready")
        except Exception as e:
            logger.error("telegram_document_failed", error=str(e))
            await update.message.reply_text(f"❌ Failed to process file: {str(e)[:200]}")

    @authorized_only
    async def _handle_photo(self, update, context) -> None:
        """Handle a photo sent by the user — download and pass to orchestrator."""
        import os
        caption    = update.message.caption or "Analyze this image"
        task_id    = str(uuid.uuid4())
        session_id = self._get_session_id(update.effective_user.id)

        photo    = update.message.photo[-1]  # largest resolution
        tg_file  = await context.bot.get_file(photo.file_id)
        filename = f"photo_{photo.file_id[-8:]}.jpg"

        upload_dir = "./data/uploads"
        os.makedirs(upload_dir, exist_ok=True)
        file_path  = os.path.join(upload_dir, filename)

        await update.message.reply_text("📷 Processing image...")

        try:
            await tg_file.download_to_drive(file_path)

            if self._kernel and self._kernel.is_running:
                from agents.base import TaskContext
                orchestrator = self._kernel.get_orchestrator()
                if orchestrator:
                    goal = f"{caption}\n\n[Image saved at: {file_path}]"
                    ctx  = TaskContext(
                        task_id=task_id, goal=goal,
                        payload={
                            "goal": goal, "task_id": task_id,
                            "session_id": session_id, "file_path": file_path,
                        },
                    )
                    result = await orchestrator.handle_task("execute_goal", ctx)
                    if result.success:
                        data   = result.data if isinstance(result.data, dict) else {}
                        answer = data.get("answer", str(result.data))
                        await self._safe_reply(update, f"✅ {answer}")
                    else:
                        await self._safe_reply(update, f"❌ {result.error}")
        except Exception as e:
            logger.error("telegram_photo_failed", error=str(e))
            await update.message.reply_text(f"❌ Error: {str(e)[:200]}")


        """
        Send a reply, trying Markdown first.
        Falls back to plain text if Telegram rejects the Markdown (400).
        This handles LLM responses that contain unmatched backticks,
        asterisks, or other characters that break Telegram's Markdown parser.
        """
        try:
            await update.message.reply_text(text, parse_mode="Markdown")
        except Exception:
            # Strip common Markdown characters and resend as plain text
            plain = (text
                     .replace("*", "")
                     .replace("`", "'")
                     .replace("_", "")
                     .replace("[", "")
                     .replace("]", ""))
            try:
                await update.message.reply_text(plain)
            except Exception as e:
                logger.error("telegram_reply_failed", error=str(e))

    @authorized_only
    async def _cmd_start(self, update, context) -> None:
        user = update.effective_user.first_name
        await update.message.reply_text(
            f"👋 Welcome, {user}!\n\n"
            f"*MUSTAFA OS* is ready.\n\n"
            f"Just send me any goal and I'll execute it autonomously.\n\n"
            f"Commands:\n"
            f"/help - Show help\n"
            f"/status - System status\n"
            f"/agents - List agents\n"
            f"/tasks - Recent tasks\n"
            f"/evolve - Trigger self-improvement",
            parse_mode="Markdown",
        )

    @authorized_only
    async def _cmd_help(self, update, context) -> None:
        await update.message.reply_text(
            "*MUSTAFA OS Commands*\n\n"
            "/start - Welcome message\n"
            "/status - System health\n"
            "/agents - All agent statuses\n"
            "/tasks - Recent task history\n"
            "/evolve - Run evolution cycle\n\n"
            "Or just send any text as a goal!",
            parse_mode="Markdown",
        )

    @authorized_only
    async def _cmd_status(self, update, context) -> None:
        if not self._kernel:
            await update.message.reply_text("⚠️ Kernel not available")
            return

        status = self._kernel.get_status()
        summary = status.get("registry_summary", {})

        text = (
            f"*MUSTAFA OS Status*\n\n"
            f"🟢 Running: {'Yes' if status['running'] else 'No'}\n"
            f"⏱ Uptime: {int(status['uptime_seconds'])}s\n"
            f"🤖 Agents: {status['agent_count']}\n"
            f"✅ Idle: {summary.get('idle', 0)}\n"
            f"⚡ Busy: {summary.get('busy', 0)}\n"
            f"❌ Error: {summary.get('error', 0)}\n"
            f"📊 Success Rate: {summary.get('overall_success_rate', 0):.0%}"
        )
        await update.message.reply_text(text, parse_mode="Markdown")

    @authorized_only
    async def _cmd_agents(self, update, context) -> None:
        from core.registry import agent_registry
        agents = agent_registry.get_all_agents()

        if not agents:
            await update.message.reply_text("No agents registered")
            return

        status_emoji = {"idle": "🟢", "busy": "🟡", "error": "🔴", "stopped": "⚫"}
        lines = ["*Registered Agents*\n"]
        for a in agents:
            emoji = status_emoji.get(a.status, "⚪")
            lines.append(f"{emoji} *{a.name}* — {a.status} | {a.task_count} tasks")

        await update.message.reply_text("\n".join(lines), parse_mode="Markdown")

    @authorized_only
    async def _cmd_tasks(self, update, context) -> None:
        try:
            from api.app import _active_tasks
            if not _active_tasks:
                await update.message.reply_text("No tasks this session")
                return

            lines = ["*Recent Tasks*\n"]
            for task in list(_active_tasks.values())[-5:]:
                status_emoji = {"completed": "✅", "failed": "❌", "running": "⏳"}.get(task["status"], "⚪")
                lines.append(
                    f"{status_emoji} `{task['task_id'][:8]}...`\n"
                    f"   {task['goal'][:60]}"
                )
            await self._safe_reply(update, "\n".join(lines))
        except Exception as e:
            await update.message.reply_text(f"Error: {e}")

    @authorized_only
    async def _cmd_evolve(self, update, context) -> None:
        await update.message.reply_text("🧬 Triggering evolution cycle via Orchestrator...")
        try:
            if self._kernel and self._kernel.is_running:
                orchestrator = self._kernel.get_orchestrator()
                if orchestrator:
                    from agents.base import TaskContext
                    ctx = TaskContext(
                        task_id=str(uuid.uuid4()),
                        goal="Run a self-improvement evolution cycle: analyse system performance, identify weaknesses, and propose improvements.",
                        payload={"triggered_by": "telegram"},
                    )
                    asyncio.create_task(orchestrator.handle_task("execute_goal", ctx))
                    await update.message.reply_text("✅ Evolution cycle triggered.")
                else:
                    await update.message.reply_text("⚠️ Orchestrator not available")
            else:
                await update.message.reply_text("⚠️ System not running")
        except Exception as e:
            await update.message.reply_text(f"❌ Failed: {e}")

    def _get_session_id(self, user_id: int) -> str:
        """Return a stable session ID per Telegram user (persists for the bot's lifetime)."""
        if not hasattr(self, "_sessions"):
            self._sessions: dict = {}
        if user_id not in self._sessions:
            self._sessions[user_id] = str(uuid.uuid4())
        return self._sessions[user_id]

    @authorized_only
    async def _handle_goal(self, update, context) -> None:
        """Handle a text message as a goal."""
        goal       = update.message.text
        task_id    = str(uuid.uuid4())
        session_id = self._get_session_id(update.effective_user.id)

        await update.message.reply_text(
            f"🤔 Processing goal...\n`{goal[:100]}`",
            parse_mode="Markdown",
        )

        try:
            if self._kernel and self._kernel.is_running:
                from agents.base import TaskContext
                orchestrator = self._kernel.get_orchestrator()
                if orchestrator:
                    ctx = TaskContext(
                        task_id=task_id,
                        goal=goal,
                        payload={"goal": goal, "task_id": task_id, "session_id": session_id},
                    )
                    result = await orchestrator.handle_task("execute_goal", ctx)

                    if result.success:
                        data   = result.data if isinstance(result.data, dict) else {}
                        answer = data.get("answer", str(result.data))

                        # Send any files that were created as attachments
                        files_sent = await self._send_attachments(update, data)

                        # Send text response
                        if len(answer) > 3800:
                            answer = answer[:3800] + "\n\n[...truncated]"
                        prefix = "✅ Result:\n\n" if not files_sent else "✅ Done:\n\n"
                        await self._safe_reply(update, f"{prefix}{answer}")
                    else:
                        await self._safe_reply(update, f"❌ Error: {result.error}")
                else:
                    await update.message.reply_text("⚠️ Orchestrator not available")
            else:
                await update.message.reply_text("⚠️ System not fully initialized")
        except Exception as e:
            logger.error("telegram_goal_failed", error=str(e))
            await update.message.reply_text(f"❌ Internal error: {str(e)[:200]}")


# Global singleton
telegram_bot = MustafaOSTelegramBot()
