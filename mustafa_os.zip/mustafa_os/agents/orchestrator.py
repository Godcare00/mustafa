"""
MUSTAFA OS - Orchestrator Agent
The central intelligence that receives goals, reasons about available resources,
and dynamically coordinates agents and tools to accomplish any task.
NO pre-defined workflows — pure dynamic reasoning at every step.
"""
from __future__ import annotations

import asyncio
import json
import time
import uuid
from typing import Any, Dict, List, Optional, Tuple

from agents.base import BaseAgent
from core.llm_client import LLMMessage
from core.logger import get_logger
from core.tool_engine import ToolEngine, get_tool_engine

logger = get_logger("orchestrator")


class OrchestratorAgent(BaseAgent):
    """
    The central brain of MUSTAFA OS.
    Receives every user goal and dynamically decides:
    - Which agents to invoke
    - Which tools to call
    - When to create new capabilities
    - When to escalate to user
    
    Has NO hard-coded procedures. Every decision is made fresh via LLM reasoning.
    """

    agent_name = "orchestrator"
    agent_description = (
        "Central intelligence that dynamically coordinates all agents and tools "
        "to accomplish any goal. No pre-defined workflows."
    )

    def __init__(self, agent_registry: "AgentRegistry", **kwargs):
        super().__init__(**kwargs)
        self._registry = agent_registry
        self._tool_engine: ToolEngine = get_tool_engine()
        self._max_iterations = 15  # Max reasoning/action cycles per task

    async def execute(
        self,
        task: str,
        context: Optional[Dict] = None,
        task_id: Optional[str] = None,
    ) -> Any:
        """
        Execute a task through dynamic multi-step reasoning.
        The orchestrator sees all available agents and tools and decides what to do.
        """
        tid = task_id or str(uuid.uuid4())
        ctx = context or {}
        iteration = 0
        history: List[Dict] = []
        accumulated_results: List[Dict] = []

        self._log.info("Orchestrator starting task", task_id=tid, task=task[:150])

        # Build initial context
        agents_manifest = await self._registry.get_agents_manifest()
        tools_manifest = await self._tool_engine.get_tools_manifest()

        # Retrieve relevant memories
        memories = await self.recall_memory(task, top_k=5)
        memory_context = ""
        if memories:
            memory_context = "\n\nRELEVANT MEMORIES:\n" + "\n".join(
                f"- [{m.memory_type}] {m.content[:200]}" for m in memories
            )

        system_context = f"""
AVAILABLE AGENTS:
{agents_manifest}

AVAILABLE TOOLS:
{tools_manifest}

TASK ID: {tid}
{memory_context}
"""

        while iteration < self._max_iterations:
            iteration += 1
            self._log.info(f"Orchestrator iteration {iteration}", task_id=tid)

            # Build messages for LLM
            messages = self._build_messages(task, ctx, history, accumulated_results, iteration)

            # Get orchestrator decision
            try:
                decision = await self.llm_complete_json(
                    messages=messages,
                    system_prompt=self._system_prompt + "\n" + system_context,
                )
            except Exception as e:
                self._log.error("Orchestrator LLM failed", error=str(e), task_id=tid)
                return {
                    "status": "error",
                    "error": f"Orchestrator reasoning failed: {e}",
                    "task_id": tid,
                    "partial_results": accumulated_results,
                }

            self._log.info(
                "Orchestrator decision made",
                iteration=iteration,
                task_id=tid,
                data={"reasoning": str(decision.get("reasoning", ""))[:200]},
            )

            history.append({"iteration": iteration, "decision": decision})

            # Check if task is complete
            if decision.get("task_complete"):
                final_answer = decision.get("final_answer") or decision.get("user_message", "Task completed.")
                self._log.info("Task completed by orchestrator", task_id=tid, iterations=iteration)

                # Store successful task in memory
                await self.store_memory(
                    content=f"Task: {task}\nResult: {str(final_answer)[:500]}",
                    memory_type="task_result",
                    metadata={"task_id": tid, "iterations": iteration},
                )

                return {
                    "status": "completed",
                    "result": final_answer,
                    "task_id": tid,
                    "iterations": iteration,
                    "steps_taken": accumulated_results,
                }

            # Check if user input needed
            if decision.get("needs_user_input"):
                return {
                    "status": "needs_input",
                    "message": decision.get("user_message", "I need more information."),
                    "alternatives": decision.get("alternatives", []),
                    "task_id": tid,
                    "partial_results": accumulated_results,
                }

            # Execute delegations (agent calls)
            delegations = decision.get("delegations", [])
            if delegations:
                results = await self._execute_delegations(delegations, tid)
                accumulated_results.extend(results)
                for r in results:
                    history.append({"delegation_result": r})

            # Execute tool calls
            tool_calls = decision.get("tool_calls", [])
            if tool_calls:
                results = await self._execute_tool_calls(tool_calls, tid)
                accumulated_results.extend(results)
                for r in results:
                    history.append({"tool_result": r})

            # Handle new capability creation
            if decision.get("needs_new_capability"):
                spec = decision.get("new_capability_spec", {})
                creation_result = await self._create_capability(spec, tid)
                accumulated_results.append(creation_result)
                history.append({"capability_created": creation_result})
                # Update tools manifest after creation
                tools_manifest = await self._tool_engine.get_tools_manifest()
                system_context = f"""
AVAILABLE AGENTS:
{agents_manifest}

AVAILABLE TOOLS (UPDATED):
{tools_manifest}

TASK ID: {tid}
{memory_context}
"""

            # If no actions were taken, something is wrong
            if not delegations and not tool_calls and not decision.get("needs_new_capability"):
                if not decision.get("task_complete") and not decision.get("needs_user_input"):
                    self._log.warning(
                        "No actions taken in iteration",
                        iteration=iteration,
                        task_id=tid,
                    )
                    # Force a conclusion
                    return {
                        "status": "completed",
                        "result": decision.get("user_message", "Task processed."),
                        "task_id": tid,
                        "iterations": iteration,
                        "steps_taken": accumulated_results,
                    }

        # Max iterations reached
        self._log.warning("Max iterations reached", task_id=tid, max=self._max_iterations)
        return {
            "status": "max_iterations_reached",
            "message": f"Task processing reached the maximum iteration limit ({self._max_iterations}). Partial results available.",
            "task_id": tid,
            "partial_results": accumulated_results,
            "alternatives": [
                "Break the task into smaller sub-tasks",
                "Provide more specific instructions",
                "Increase iteration limit in configuration",
            ],
        }

    def _build_messages(
        self,
        task: str,
        context: Dict,
        history: List[Dict],
        accumulated_results: List[Dict],
        iteration: int,
    ) -> List[LLMMessage]:
        """Build the message list for the orchestrator LLM call."""
        user_content = f"""
TASK: {task}

CONTEXT: {json.dumps(context, default=str, indent=2) if context else 'None'}

ITERATION: {iteration}

ACCUMULATED RESULTS SO FAR:
{json.dumps(accumulated_results[-10:], default=str, indent=2) if accumulated_results else 'None yet'}

RECENT HISTORY:
{json.dumps(history[-5:], default=str, indent=2) if history else 'None yet'}

---
Based on the task, available agents/tools (in system context), and results so far:
1. Reason about what still needs to be done
2. Decide whether to delegate to agents, call tools, create new capabilities, or finalize

Respond with a JSON object:
{{
  "reasoning": "step-by-step thinking about current state and what to do",
  "task_complete": false,
  "final_answer": null,
  "delegations": [
    {{"agent": "agent_name", "task": "specific task description", "priority": 1, "context": {{}}}}
  ],
  "tool_calls": [
    {{"tool": "tool_name", "params": {{}}, "reason": "why calling this"}}
  ],
  "needs_new_capability": false,
  "new_capability_spec": {{
    "type": "tool",
    "name": "tool_name",
    "description": "what it should do",
    "required_behavior": "detailed spec"
  }},
  "needs_user_input": false,
  "alternatives": [],
  "user_message": "human-friendly status update"
}}
"""
        return [LLMMessage.user(user_content)]

    async def _execute_delegations(
        self, delegations: List[Dict], task_id: str
    ) -> List[Dict]:
        """Execute agent delegations, in parallel where possible."""
        results = []

        # Group by priority - higher priority first
        sorted_delegations = sorted(delegations, key=lambda d: d.get("priority", 5))

        # Execute in parallel where same priority
        groups: Dict[int, List[Dict]] = {}
        for d in sorted_delegations:
            p = d.get("priority", 5)
            groups.setdefault(p, []).append(d)

        for priority, group in sorted(groups.items()):
            # Run same-priority delegations in parallel
            tasks = []
            for delegation in group:
                agent_name = delegation.get("agent", "")
                agent_task = delegation.get("task", "")
                agent_ctx = delegation.get("context", {})

                agent = self._registry.get_agent(agent_name)
                if agent:
                    tasks.append(
                        self._safe_agent_run(agent, agent_task, agent_ctx, task_id, agent_name)
                    )
                else:
                    results.append({
                        "agent": agent_name,
                        "status": "error",
                        "error": f"Agent '{agent_name}' not found in registry",
                    })

            if tasks:
                parallel_results = await asyncio.gather(*tasks, return_exceptions=True)
                for r in parallel_results:
                    if isinstance(r, Exception):
                        results.append({"status": "error", "error": str(r)})
                    else:
                        results.append(r)

        return results

    async def _safe_agent_run(
        self, agent: Any, task: str, context: Dict, task_id: str, agent_name: str
    ) -> Dict:
        """Run an agent safely, catching all exceptions."""
        try:
            result = await asyncio.wait_for(
                agent.run(task=task, context=context, task_id=task_id),
                timeout=120.0,
            )
            return {"agent": agent_name, "status": "success", "result": result}
        except asyncio.TimeoutError:
            return {"agent": agent_name, "status": "timeout", "error": "Agent timed out"}
        except Exception as e:
            self._log.error("Agent delegation failed", agent=agent_name, error=str(e))
            return {"agent": agent_name, "status": "error", "error": str(e)}

    async def _execute_tool_calls(
        self, tool_calls: List[Dict], task_id: str
    ) -> List[Dict]:
        """Execute tool calls, in parallel where possible."""
        tasks = []
        for tc in tool_calls:
            tool_name = tc.get("tool", "")
            params = tc.get("params", {})
            tasks.append(self._safe_tool_call(tool_name, params, task_id))

        results = await asyncio.gather(*tasks, return_exceptions=True)
        output = []
        for i, r in enumerate(results):
            if isinstance(r, Exception):
                output.append({"tool": tool_calls[i].get("tool"), "status": "error", "error": str(r)})
            else:
                output.append(r)
        return output

    async def _safe_tool_call(self, tool_name: str, params: Dict, task_id: str) -> Dict:
        """Execute a single tool call safely."""
        try:
            result = await self._tool_engine.execute(
                tool_name=tool_name,
                params=params,
                task_id=task_id,
                agent_name=self.agent_name,
            )
            return {
                "tool": tool_name,
                "status": "success" if result.success else "failed",
                "result": result.output,
                "error": result.error,
                "duration_ms": result.duration_ms,
            }
        except Exception as e:
            return {"tool": tool_name, "status": "error", "error": str(e)}

    async def _create_capability(self, spec: Dict, task_id: str) -> Dict:
        """Create a new tool capability when one doesn't exist."""
        self._log.info("Creating new capability", spec=spec, task_id=task_id)

        try:
            # Get developer agent to write the code
            developer = self._registry.get_agent("developer")
            if not developer:
                return {"status": "error", "error": "Developer agent not available to create capability"}

            creation_task = f"""
Create a new MUSTAFA OS tool with these specifications:
Type: {spec.get('type', 'tool')}
Name: {spec.get('name', 'custom_tool')}
Description: {spec.get('description', '')}
Required behavior: {spec.get('required_behavior', '')}

Output a JSON object with:
{{
  "tool_name": "snake_case_name",
  "description": "clear description",
  "code": "complete Python async function code",
  "json_schema": {{"input": {{}}, "output": {{}}}},
  "permissions": [],
  "dependencies": []
}}
"""
            dev_result = await developer.run(task=creation_task, task_id=task_id)

            # Parse the tool spec from developer output
            if isinstance(dev_result, dict) and dev_result.get("tool_name"):
                tool_spec = dev_result
            elif isinstance(dev_result, str):
                import re
                json_match = re.search(r'\{.*\}', dev_result, re.DOTALL)
                if json_match:
                    tool_spec = json.loads(json_match.group())
                else:
                    return {"status": "error", "error": "Could not parse tool spec from developer"}
            else:
                return {"status": "error", "error": "Developer returned unexpected format"}

            success = await self._tool_engine.register_dynamic_tool(
                tool_name=tool_spec["tool_name"],
                description=tool_spec["description"],
                code=tool_spec["code"],
                json_schema=tool_spec["json_schema"],
                permissions=tool_spec.get("permissions", []),
                dependencies=tool_spec.get("dependencies", []),
            )

            return {
                "status": "created" if success else "failed",
                "tool_name": tool_spec.get("tool_name"),
                "message": f"Tool '{tool_spec.get('tool_name')}' created successfully" if success else "Tool creation failed",
            }

        except Exception as e:
            self._log.error("Capability creation failed", error=str(e), task_id=task_id)
            return {"status": "error", "error": str(e)}


# ─── Agent Registry ───────────────────────────────────────────────────────────

class AgentRegistry:
    """
    Registry of all agents in MUSTAFA OS.
    Provides discovery, manifest generation, and lifecycle management.
    """

    def __init__(self):
        self._agents: Dict[str, BaseAgent] = {}
        self._log = logger.bind(component="agent_registry")

    def register(self, agent: BaseAgent) -> None:
        """Register an agent."""
        self._agents[agent.agent_name] = agent
        self._log.info("Agent registered", agent=agent.agent_name)

    def get_agent(self, name: str) -> Optional[BaseAgent]:
        """Get an agent by name."""
        return self._agents.get(name)

    def list_agents(self) -> List[Dict]:
        """List all registered agents with their status."""
        return [
            {
                "name": a.agent_name,
                "description": a.agent_description,
                "status": a._status,
                "stats": a.get_stats(),
            }
            for a in self._agents.values()
        ]

    async def get_agents_manifest(self) -> str:
        """Get a compact manifest for orchestrator context."""
        agents = self.list_agents()
        manifest = [
            {
                "name": a["name"],
                "description": a["description"],
                "status": a["status"],
            }
            for a in agents
            if a["name"] != "orchestrator"  # Don't list self
        ]
        return json.dumps(manifest, indent=2)

    async def startup_all(self) -> None:
        """Start all registered agents."""
        for agent in self._agents.values():
            try:
                await agent.on_startup()
            except Exception as e:
                self._log.error("Agent startup failed", agent=agent.agent_name, error=str(e))

    async def shutdown_all(self) -> None:
        """Shutdown all registered agents."""
        for agent in self._agents.values():
            try:
                await agent.on_shutdown()
            except Exception as e:
                self._log.error("Agent shutdown failed", agent=agent.agent_name, error=str(e))
