"""
MUSTAFA OS - Experiment Engine
Manages the self-improvement loop: propose → design → run → evaluate → deploy.
All experiments are logged, isolated, and reversible.
"""
from __future__ import annotations

import asyncio
import json
import time
import uuid
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, List, Optional

from core.database import get_db
from core.logger import get_logger

logger = get_logger("experiments")


class ExperimentStatus(str, Enum):
    PROPOSED  = "proposed"
    APPROVED  = "approved"
    RUNNING   = "running"
    COMPLETED = "completed"
    FAILED    = "failed"
    REJECTED  = "rejected"
    DEPLOYED  = "deployed"


@dataclass
class Experiment:
    """A single self-improvement experiment."""
    id: str = field(default_factory=lambda: str(uuid.uuid4()))
    name: str = ""
    hypothesis: str = ""
    status: ExperimentStatus = ExperimentStatus.PROPOSED
    proposed_by: str = "evolution_agent"
    created_at: float = field(default_factory=time.time)
    started_at: Optional[float] = None
    completed_at: Optional[float] = None
    baseline_metrics: Dict = field(default_factory=dict)
    experiment_metrics: Dict = field(default_factory=dict)
    result: Optional[str] = None
    deployed: bool = False
    notes: str = ""

    def to_dict(self) -> Dict:
        return {
            "id": self.id,
            "name": self.name,
            "hypothesis": self.hypothesis,
            "status": self.status.value,
            "proposed_by": self.proposed_by,
            "created_at": self.created_at,
            "started_at": self.started_at,
            "completed_at": self.completed_at,
            "baseline_metrics": self.baseline_metrics,
            "experiment_metrics": self.experiment_metrics,
            "result": self.result,
            "deployed": self.deployed,
            "notes": self.notes,
        }


class ExperimentEngine:
    """
    Manages the experiment lifecycle for system self-improvement.
    Provides a safe, auditable loop for proposing, testing, and deploying improvements.
    """

    def __init__(self):
        self._active_experiments: Dict[str, Experiment] = {}
        self._log = logger

    async def propose(
        self,
        name: str,
        hypothesis: str,
        proposed_by: str = "evolution_agent",
        notes: str = "",
    ) -> Experiment:
        """Register a new improvement experiment."""
        exp = Experiment(
            name=name,
            hypothesis=hypothesis,
            proposed_by=proposed_by,
            notes=notes,
        )
        db = await get_db()
        async with db._cursor() as cur:
            await cur.execute(
                """INSERT INTO experiments
                   (id, name, hypothesis, status, proposed_by, created_at, notes)
                   VALUES (?, ?, ?, ?, ?, ?, ?)""",
                (
                    exp.id, exp.name, exp.hypothesis,
                    exp.status.value, exp.proposed_by,
                    exp.created_at, exp.notes,
                ),
            )
        self._active_experiments[exp.id] = exp
        self._log.info("Experiment proposed", experiment_id=exp.id, name=name)
        return exp

    async def capture_baseline(self, experiment_id: str, metrics: Dict) -> None:
        """Capture baseline metrics before running the experiment."""
        exp = await self._get_experiment(experiment_id)
        if exp:
            exp.baseline_metrics = metrics
            await self._update_db(exp)
            self._log.info("Baseline captured", experiment_id=experiment_id)

    async def start(self, experiment_id: str) -> bool:
        """Mark experiment as running."""
        exp = await self._get_experiment(experiment_id)
        if not exp:
            return False
        exp.status = ExperimentStatus.RUNNING
        exp.started_at = time.time()
        await self._update_db(exp)
        self._log.info("Experiment started", experiment_id=experiment_id)
        return True

    async def record_result(
        self,
        experiment_id: str,
        metrics: Dict,
        result_summary: str,
    ) -> None:
        """Record the outcome metrics and result of an experiment."""
        exp = await self._get_experiment(experiment_id)
        if not exp:
            return
        exp.experiment_metrics = metrics
        exp.result = result_summary
        exp.completed_at = time.time()
        exp.status = ExperimentStatus.COMPLETED
        await self._update_db(exp)
        self._log.info("Experiment result recorded", experiment_id=experiment_id, result=result_summary[:100])

    async def evaluate(self, experiment_id: str) -> Dict:
        """
        Compare baseline vs experiment metrics.
        Returns evaluation with recommendation.
        """
        exp = await self._get_experiment(experiment_id)
        if not exp:
            return {"error": "Experiment not found"}

        baseline = exp.baseline_metrics
        experiment = exp.experiment_metrics

        improvements = {}
        regressions = {}
        unchanged = {}

        for metric in set(list(baseline.keys()) + list(experiment.keys())):
            b_val = baseline.get(metric)
            e_val = experiment.get(metric)

            if b_val is None or e_val is None:
                continue

            try:
                b_float = float(b_val)
                e_float = float(e_val)
                if b_float == 0:
                    change_pct = 0.0
                else:
                    change_pct = ((e_float - b_float) / abs(b_float)) * 100

                # Higher is better for success_rate, lower is better for latency/errors
                higher_is_better = "rate" in metric or "success" in metric or "score" in metric
                lower_is_better = "latency" in metric or "error" in metric or "failure" in metric

                if higher_is_better:
                    if change_pct > 5:
                        improvements[metric] = {"baseline": b_val, "experiment": e_val, "change_pct": round(change_pct, 1)}
                    elif change_pct < -5:
                        regressions[metric] = {"baseline": b_val, "experiment": e_val, "change_pct": round(change_pct, 1)}
                    else:
                        unchanged[metric] = {"baseline": b_val, "experiment": e_val}
                elif lower_is_better:
                    if change_pct < -5:
                        improvements[metric] = {"baseline": b_val, "experiment": e_val, "change_pct": round(change_pct, 1)}
                    elif change_pct > 5:
                        regressions[metric] = {"baseline": b_val, "experiment": e_val, "change_pct": round(change_pct, 1)}
                    else:
                        unchanged[metric] = {"baseline": b_val, "experiment": e_val}
            except (TypeError, ValueError):
                continue

        recommend_deploy = len(improvements) > len(regressions)

        return {
            "experiment_id": experiment_id,
            "name": exp.name,
            "improvements": improvements,
            "regressions": regressions,
            "unchanged": unchanged,
            "recommend_deploy": recommend_deploy,
            "summary": (
                f"{len(improvements)} improvements, "
                f"{len(regressions)} regressions, "
                f"{len(unchanged)} unchanged metrics"
            ),
        }

    async def deploy(self, experiment_id: str) -> bool:
        """Mark an experiment as deployed (accepted improvement)."""
        exp = await self._get_experiment(experiment_id)
        if not exp:
            return False
        exp.status = ExperimentStatus.DEPLOYED
        exp.deployed = True
        await self._update_db(exp)
        self._log.info("Experiment deployed", experiment_id=experiment_id, name=exp.name)
        return True

    async def reject(self, experiment_id: str, reason: str = "") -> None:
        """Reject an experiment (do not deploy)."""
        exp = await self._get_experiment(experiment_id)
        if exp:
            exp.status = ExperimentStatus.REJECTED
            exp.notes = (exp.notes + f"\nRejected: {reason}").strip()
            await self._update_db(exp)
            self._log.info("Experiment rejected", experiment_id=experiment_id, reason=reason)

    async def list_experiments(self, status: Optional[str] = None) -> List[Dict]:
        """List all experiments."""
        db = await get_db()
        async with db._cursor() as cur:
            if status:
                await cur.execute(
                    "SELECT * FROM experiments WHERE status=? ORDER BY created_at DESC",
                    (status,),
                )
            else:
                await cur.execute("SELECT * FROM experiments ORDER BY created_at DESC")
            rows = await cur.fetchall()
            return [dict(r) for r in rows]

    async def _get_experiment(self, experiment_id: str) -> Optional[Experiment]:
        """Get experiment from cache or DB."""
        if experiment_id in self._active_experiments:
            return self._active_experiments[experiment_id]

        db = await get_db()
        async with db._cursor() as cur:
            await cur.execute("SELECT * FROM experiments WHERE id=?", (experiment_id,))
            row = await cur.fetchone()
            if row:
                d = dict(row)
                exp = Experiment(
                    id=d["id"],
                    name=d["name"],
                    hypothesis=d["hypothesis"],
                    status=ExperimentStatus(d["status"]),
                    proposed_by=d["proposed_by"],
                    created_at=d["created_at"],
                    started_at=d.get("started_at"),
                    completed_at=d.get("completed_at"),
                    baseline_metrics=json.loads(d["baseline_metrics"] or "{}"),
                    experiment_metrics=json.loads(d["experiment_metrics"] or "{}"),
                    result=d.get("result"),
                    deployed=bool(d.get("deployed", 0)),
                    notes=d.get("notes", ""),
                )
                self._active_experiments[experiment_id] = exp
                return exp
        return None

    async def _update_db(self, exp: Experiment) -> None:
        """Persist experiment state to DB."""
        db = await get_db()
        async with db._cursor() as cur:
            await cur.execute(
                """UPDATE experiments SET
                   status=?, started_at=?, completed_at=?,
                   baseline_metrics=?, experiment_metrics=?,
                   result=?, deployed=?, notes=?
                   WHERE id=?""",
                (
                    exp.status.value,
                    exp.started_at,
                    exp.completed_at,
                    json.dumps(exp.baseline_metrics),
                    json.dumps(exp.experiment_metrics),
                    exp.result,
                    1 if exp.deployed else 0,
                    exp.notes,
                    exp.id,
                ),
            )


# Singleton
_experiment_engine: Optional[ExperimentEngine] = None


def get_experiment_engine() -> ExperimentEngine:
    """Get or create the global experiment engine."""
    global _experiment_engine
    if _experiment_engine is None:
        _experiment_engine = ExperimentEngine()
    return _experiment_engine
