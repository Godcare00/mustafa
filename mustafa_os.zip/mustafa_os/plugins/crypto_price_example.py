"""
MUSTAFA OS - Example Plugin: Crypto Price Tool
Drop files like this in ./plugins/ and MUSTAFA OS auto-loads them.

This tool fetches real-time cryptocurrency prices from the CoinGecko public API.
"""
from __future__ import annotations

import aiohttp
from typing import Any, Dict, Optional

# BaseTool is importable once the system is running
try:
    from tools.base import BaseTool, ToolResult
except ImportError:
    from tools.base import BaseTool, ToolResult


class CryptoPriceTool(BaseTool):
    """
    Fetch real-time cryptocurrency prices from CoinGecko.
    
    Example usage:
        params = {"coin": "bitcoin", "currency": "usd"}
    """

    name = "crypto_price"
    description = "Fetch real-time cryptocurrency prices from CoinGecko"
    permissions = ["network.read"]
    timeout = 15

    BASE_URL = "https://api.coingecko.com/api/v3"

    async def execute(self, params: Dict[str, Any]) -> ToolResult:
        coin = params.get("coin", "bitcoin").lower()
        currency = params.get("currency", "usd").lower()

        try:
            url = f"{self.BASE_URL}/simple/price"
            query = {"ids": coin, "vs_currencies": currency, "include_24hr_change": "true"}

            async with aiohttp.ClientSession() as session:
                async with session.get(url, params=query, timeout=aiohttp.ClientTimeout(total=10)) as resp:
                    if resp.status != 200:
                        return ToolResult(success=False, error=f"CoinGecko API error: {resp.status}")

                    data = await resp.json()

                    if coin not in data:
                        return ToolResult(success=False, error=f"Coin '{coin}' not found")

                    coin_data = data[coin]
                    return ToolResult(
                        success=True,
                        data={
                            "coin": coin,
                            "currency": currency,
                            "price": coin_data.get(currency),
                            "change_24h": coin_data.get(f"{currency}_24h_change"),
                        },
                    )
        except Exception as e:
            return ToolResult(success=False, error=str(e))

    async def validate_params(self, params: Dict[str, Any]) -> Optional[str]:
        if not params.get("coin"):
            return "coin parameter required (e.g., 'bitcoin', 'ethereum')"
        return None
