# MUSTAFA OS
### Modular Unified System for Task Automation and Autonomous Intelligence

**Version:** 1.0.0  
**Architecture:** Autonomous Multi-Agent Operating System  
**LLM Provider:** OpenRouter (`arcee-ai/trinity-large-preview:free`)

---

## Overview

MUSTAFA OS is a production-grade autonomous multi-agent operating system. It receives user goals through a CLI, REST API, or Telegram bot, and dynamically coordinates a network of specialized AI agents and tools to accomplish any task — without pre-defined workflows.

Every request goes to the **Orchestrator Agent**, which:
1. Reads all available agents and tools at runtime
2. Reasons about what is needed
3. Delegates to specialist agents and tools
4. Creates new capabilities if needed
5. Synthesizes results and responds

---

## Architecture

```
MUSTAFA OS
│
├── Orchestrator Agent       ← Central intelligence, dynamic reasoning
│   └── Agent Registry       ← Discovers and manages all agents
│
├── Specialist Agents
│   ├── Planner              ← Task decomposition
│   ├── Research             ← Web research & synthesis
│   ├── Developer            ← Code writing & tool creation
│   ├── Testing              ← QA & test execution
│   ├── Critic               ← Output review & quality scoring
│   ├── Memory Agent         ← Knowledge management
│   ├── Tool Manager         ← Plugin ecosystem management
│   ├── Monitoring           ← System health & metrics
│   └── Evolution            ← Self-improvement experiments
│
├── Core Infrastructure
│   ├── LLM Client           ← OpenRouter with circuit breaker + retry
│   ├── Tool Engine          ← Plugin system with JSON schema validation
│   ├── Message Bus          ← Redis pub/sub for agent communication
│   ├── Database             ← Async SQLite for state persistence
│   └── Memory System        ← Redis (short-term) + ChromaDB (long-term)
│
├── Interfaces
│   ├── FastAPI REST API      ← Full REST interface + Swagger docs
│   ├── CLI Chat              ← Rich terminal interface
│   └── Telegram Bot          ← Authorized-users-only bot
│
└── Observability
    ├── JSON Structured Logs  ← Machine-readable logs
    ├── Metrics Collector     ← Background metrics aggregation
    └── Experiment Engine     ← Self-improvement tracking
```

---

## Quick Start

### 1. Install

```bash
cd mustafa_os
chmod +x setup.sh
./setup.sh
```

The setup script will:
- Check Python 3.10+ is installed
- Install and start Redis
- Create a Python virtual environment
- Install all dependencies
- Prompt for your OpenRouter API key
- Initialize the SQLite database
- Run a health check

### 2. Configure

Edit `.env` with your settings:

```env
OPENROUTER_API_KEY=your_key_here
TELEGRAM_BOT_TOKEN=optional
TELEGRAM_AUTHORIZED_USERS=123456789
```

### 3. Run

**CLI (recommended for first time):**
```bash
./start_cli.sh
```

**API Server:**
```bash
./start_server.sh
# Then visit: http://localhost:8000/docs
```

**Telegram Bot:**
```bash
./start_telegram.sh
```

---

## How It Works

### The Orchestrator — No Pre-defined Workflows

The Orchestrator Agent is the heart of MUSTAFA OS. It has no hard-coded procedures. Every time it receives a goal, it:

1. **Receives the full agents manifest** — names, descriptions, current status
2. **Receives the full tools manifest** — names, descriptions, JSON schemas
3. **Reasons dynamically** via LLM about what the task requires
4. **Decides** whether to call tools, delegate to agents, or create new capabilities
5. **Executes** delegations in parallel where possible
6. **Escalates** to the user if blocked, with alternatives

This means you can give MUSTAFA OS any task — research, coding, data analysis, file management — and it will figure out the path.

### Example Interactions

```
You ▶ Research the latest developments in quantum computing and write a summary

→ Orchestrator reasons: needs Research agent + web_search tool
→ Research agent runs 3 targeted web searches
→ Research agent synthesizes findings
→ Orchestrator returns structured summary
```

```
You ▶ Write a Python script to parse CSV files and store results in SQLite

→ Orchestrator reasons: needs Developer agent + python_eval tool
→ Developer agent writes the code
→ Testing agent validates the code
→ Critic agent reviews quality
→ Orchestrator returns final code
```

```
You ▶ Monitor system health and alert me if something is wrong

→ Orchestrator reasons: needs Monitoring agent + system_status tool
→ Monitoring agent collects all metrics
→ Returns health report with any alerts
```

---

## REST API Reference

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/` | System info |
| GET | `/health` | Health check |
| GET | `/status` | Full system status |
| POST | `/process` | **Main endpoint** — process any goal |
| GET | `/tasks` | List all tasks |
| GET | `/tasks/{id}` | Get task by ID |
| GET | `/agents` | List all agents |
| GET | `/tools` | List all tools |
| POST | `/tools/execute` | Execute a specific tool |
| POST | `/memory/search` | Semantic memory search |
| POST | `/memory/store` | Store in long-term memory |
| GET | `/metrics` | System metrics |
| GET | `/events` | System events log |

**Process a goal:**
```bash
curl -X POST http://localhost:8000/process \
  -H "Content-Type: application/json" \
  -d '{"goal": "Search the web for the top 5 Python web frameworks in 2025"}'
```

---

## Tool System

Tools are plugins with JSON schemas. All tools are validated before execution.

### Built-in Tools

| Tool | Description | Permissions |
|------|-------------|-------------|
| `web_search` | Search the web via DuckDuckGo | network |
| `read_file` | Read file contents | filesystem_read |
| `write_file` | Write to a file | filesystem_write |
| `execute_shell` | Run shell commands (sandboxed) | shell_execution |
| `python_eval` | Execute Python code | code_execution |
| `http_request` | Make HTTP requests | network |
| `list_directory` | List directory contents | filesystem_read |
| `memory_store` | Store in long-term memory | memory_write |
| `memory_retrieve` | Semantic memory search | memory_read |
| `system_status` | Get system health metrics | monitoring |
| `create_tool` | Create a new tool at runtime | tool_management |
| `upgrade_tool` | Upgrade existing tool | tool_management |

### Creating Custom Tools

The Orchestrator will automatically instruct the Developer agent to create new tools when a capability is missing. You can also create tools via the API:

```bash
curl -X POST http://localhost:8000/tools/execute \
  -H "Content-Type: application/json" \
  -d '{
    "tool_name": "create_tool",
    "params": {
      "tool_name": "weather_lookup",
      "description": "Get current weather for a city",
      "code": "async def execute(city: str):\n    import httpx\n    async with httpx.AsyncClient() as c:\n        r = await c.get(f\"https://wttr.in/{city}?format=j1\")\n        return r.json()",
      "json_schema": {"input": {"type": "object", "properties": {"city": {"type": "string"}}, "required": ["city"]}, "output": {"type": "object"}}
    }
  }'
```

---

## Memory System

MUSTAFA OS uses two memory tiers:

**Short-term (Redis):**
- Active task context
- Conversation history per session
- TTL-based expiration (default: 1 hour)

**Long-term (ChromaDB):**
- Semantic vector store for knowledge
- Task results and learnings
- Experiment logs
- Survives restarts

Agents automatically store important findings in long-term memory and retrieve relevant context before executing tasks.

---

## Configuration

### `config/system.yaml`
Core system settings: server port, LLM model, Redis, SQLite, memory TTL, circuit breaker thresholds.

### `config/agents.yaml`
Agent system prompts, models, temperatures. Customize agent behavior here.

### `config/tools.yaml`
Tool definitions with JSON schemas, permissions, and timeouts.

### `config/models.yaml`
LLM model assignments per agent.

---

## Reliability Features

| Feature | Implementation |
|---------|----------------|
| Circuit Breakers | Per-agent and LLM client breakers |
| Retry Logic | Exponential backoff, 3 attempts |
| Timeout Management | Per-operation timeouts |
| Graceful Error Handling | Failures report to user, never crash system |
| Health Checks | `/health` endpoint, background monitoring |
| Structured Logging | JSON logs to `logs/mustafa_os.jsonl` |
| Parallel Execution | Same-priority delegations run concurrently |

---

## Observability

All logs are written as JSON to `logs/mustafa_os.jsonl`:

```json
{"timestamp": "2025-01-01T12:00:00Z", "level": "INFO", "logger": "orchestrator", "message": "Task completed", "agent": "orchestrator", "task_id": "abc123", "duration_ms": 1234}
```

---

## Project Structure

```
mustafa_os/
├── main.py                  # Entry point (server/cli/telegram/health/test)
├── setup.sh                 # Automated setup script
├── requirements.txt         # Python dependencies
├── .env.template            # Environment variable template
├── config/
│   ├── system.yaml          # System configuration
│   ├── agents.yaml          # Agent system prompts and settings
│   ├── tools.yaml           # Tool definitions with JSON schemas
│   └── models.yaml          # LLM model assignments
├── core/
│   ├── config.py            # Configuration loader (pydantic)
│   ├── logger.py            # JSON structured logger
│   ├── reliability.py       # Circuit breaker, retry, timeout
│   ├── database.py          # Async SQLite database
│   ├── llm_client.py        # OpenRouter LLM client
│   ├── message_bus.py       # Redis pub/sub message bus
│   ├── tool_engine.py       # Plugin tool execution engine
│   └── kernel.py            # System kernel (boot/shutdown/dispatch)
├── agents/
│   ├── base.py              # Abstract base agent
│   ├── orchestrator.py      # Orchestrator + AgentRegistry
│   └── specialists.py       # All 9 specialist agents
├── memory/
│   └── memory_system.py     # Short-term (Redis) + long-term (ChromaDB)
├── api/
│   └── app.py               # FastAPI application
├── cli/
│   └── chat.py              # Terminal chat interface
├── telegram_bot/
│   └── bot.py               # Telegram bot
├── monitoring/
│   └── collector.py         # Metrics collection
├── experiments/
│   └── engine.py            # Self-improvement experiment engine
├── tests/
│   └── test_core.py         # Unit + integration tests
├── data/                    # SQLite + ChromaDB storage
└── logs/                    # JSON log files
```

---

## Running Tests

```bash
./run_tests.sh
# or
source .venv/bin/activate
python -m pytest tests/ -v
```

---

## Telegram Bot Setup

1. Create a bot via [@BotFather](https://t.me/botfather) and get the token
2. Get your Telegram user ID from [@userinfobot](https://t.me/userinfobot)
3. Set in `.env`:
   ```
   TELEGRAM_BOT_TOKEN=your_token
   TELEGRAM_AUTHORIZED_USERS=your_user_id
   ```
4. Enable in `config/system.yaml`: `telegram.enabled: true`
5. Run: `./start_telegram.sh`

Only users in `TELEGRAM_AUTHORIZED_USERS` can interact with the bot.

---

## License

MUSTAFA OS is provided as-is for autonomous AI research and production use.
