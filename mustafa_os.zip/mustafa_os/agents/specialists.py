"""
MUSTAFA OS - Specialist Agents
All 9 specialist agents with their specific capabilities.
Each agent uses LLM + tools to accomplish its domain tasks.
"""
from __future__ import annotations

import json
import time
from typing import Any, Dict, List, Optional

from agents.base import BaseAgent
from core.llm_client import LLMMessage
from core.logger import get_logger
from core.tool_engine import get_tool_engine

logger = get_logger("agents")


class PlannerAgent(BaseAgent):
    """Decomposes complex goals into structured, executable plans."""

    agent_name = "planner"
    agent_description = (
        "Breaks complex tasks into structured, ordered execution plans "
        "with dependency tracking and risk assessment."
    )

    async def execute(self, task: str, context: Optional[Dict] = None, task_id: Optional[str] = None) -> Any:
        messages = [
            LLMMessage.user(
                f"Create a detailed execution plan for this task:\n\n{task}\n\n"
                f"Context: {json.dumps(context or {}, default=str)}\n\n"
                "Respond with a structured JSON plan."
            )
        ]
        return await self.llm_complete_json(messages=messages)


class ResearchAgent(BaseAgent):
    """Conducts web research, document analysis, and knowledge extraction."""

    agent_name = "research"
    agent_description = (
        "Web researcher and knowledge analyst. "
        "Searches, synthesizes, and extracts structured insights."
    )

    async def execute(self, task: str, context: Optional[Dict] = None, task_id: Optional[str] = None) -> Any:
        engine = get_tool_engine()

        # Perform web searches to gather data
        search_results = []
        search_queries = [task]

        # Generate multiple targeted queries
        queries_resp = await self.llm_complete_json(
            messages=[LLMMessage.user(
                f"Generate 2-3 specific web search queries to research this topic:\n{task}\n\n"
                "Respond with JSON: {{\"queries\": [\"query1\", \"query2\"]}}"
            )]
        )
        if isinstance(queries_resp, dict) and queries_resp.get("queries"):
            search_queries = queries_resp["queries"][:3]

        for query in search_queries:
            result = await engine.execute("web_search", {"query": query, "max_results": 5}, task_id=task_id)
            if result.success and result.output:
                search_results.extend(result.output.get("results", []))

        # Also check memory for relevant past knowledge
        memories = await self.recall_memory(task, top_k=3, memory_type="knowledge")

        # Synthesize findings
        synthesis_prompt = f"""
Analyze and synthesize the following research for this task: {task}

SEARCH RESULTS:
{json.dumps(search_results[:15], default=str, indent=2)}

RELEVANT PAST KNOWLEDGE:
{json.dumps([{"content": m.content, "type": m.memory_type} for m in memories], indent=2)}

Provide a comprehensive, structured research report in JSON format.
"""
        result = await self.llm_complete_json(
            messages=[LLMMessage.user(synthesis_prompt)]
        )

        # Store findings in memory
        if isinstance(result, dict):
            summary = result.get("summary", str(result)[:500])
            await self.store_memory(
                content=f"Research: {task}\nFindings: {summary}",
                memory_type="knowledge",
                metadata={"task": task[:100], "task_id": task_id},
            )

        return result


class DeveloperAgent(BaseAgent):
    """Writes production-quality code, debugs, and creates tools."""

    agent_name = "developer"
    agent_description = (
        "Senior software engineer. Writes, debugs, and improves code. "
        "Creates new tools and modules for MUSTAFA OS."
    )

    async def execute(self, task: str, context: Optional[Dict] = None, task_id: Optional[str] = None) -> Any:
        ctx = context or {}

        # Check if this is a tool creation request
        is_tool_creation = any(
            kw in task.lower()
            for kw in ["create tool", "new tool", "build tool", "write tool", "implement tool"]
        )

        if is_tool_creation:
            messages = [
                LLMMessage.user(
                    f"Create a MUSTAFA OS tool for: {task}\n\n"
                    f"Context: {json.dumps(ctx, default=str)}\n\n"
                    "Output a complete JSON with:\n"
                    "- tool_name (snake_case)\n"
                    "- description\n"
                    "- code (complete async Python function, must have 'async def execute(**params)' or 'async def tool_name(**params)')\n"
                    "- json_schema (with 'input' and 'output' sub-objects)\n"
                    "- permissions (list)\n"
                    "- dependencies (list of pip packages)\n"
                    "Respond ONLY with valid JSON."
                )
            ]
        else:
            messages = [
                LLMMessage.user(
                    f"Software engineering task: {task}\n\n"
                    f"Context: {json.dumps(ctx, default=str)}\n\n"
                    "Provide complete, production-quality code with:\n"
                    "- Type hints\n"
                    "- Docstrings\n"
                    "- Error handling\n"
                    "- Tests\n\n"
                    "Respond in JSON format."
                )
            ]

        return await self.llm_complete_json(messages=messages)


class TestingAgent(BaseAgent):
    """Runs tests, validates code quality, and generates test reports."""

    agent_name = "testing"
    agent_description = (
        "QA engineer that writes and executes tests, "
        "validates code reliability, and generates coverage reports."
    )

    async def execute(self, task: str, context: Optional[Dict] = None, task_id: Optional[str] = None) -> Any:
        ctx = context or {}
        engine = get_tool_engine()

        messages = [
            LLMMessage.user(
                f"Testing task: {task}\n\n"
                f"Context: {json.dumps(ctx, default=str)}\n\n"
                "Write comprehensive tests and provide a test execution plan. "
                "Include: unit tests, edge cases, error scenarios. "
                "Output JSON with test_code, test_cases, and execution_steps."
            )
        ]

        test_plan = await self.llm_complete_json(messages=messages)

        # Execute test code if present
        if isinstance(test_plan, dict) and test_plan.get("test_code"):
            exec_result = await engine.execute(
                "python_eval",
                {"code": test_plan["test_code"], "timeout": 30},
                task_id=task_id,
            )
            test_plan["execution_output"] = exec_result.output
            test_plan["execution_success"] = exec_result.success

        return test_plan


class CriticAgent(BaseAgent):
    """Evaluates agent outputs for quality, logic, and completeness."""

    agent_name = "critic"
    agent_description = (
        "Quality assurance reviewer that analyzes outputs for logical errors, "
        "missing elements, and improvement opportunities."
    )

    async def execute(self, task: str, context: Optional[Dict] = None, task_id: Optional[str] = None) -> Any:
        ctx = context or {}
        review_target = ctx.get("review_target", task)
        review_type = ctx.get("review_type", "general")

        messages = [
            LLMMessage.user(
                f"Critically review this {review_type} output:\n\n{review_target}\n\n"
                f"Original task/goal: {task}\n\n"
                "Provide a rigorous critique in JSON format with:\n"
                "- quality_score (0-100)\n"
                "- issues_found\n"
                "- logical_errors\n"
                "- missing_elements\n"
                "- suggestions\n"
                "- approve (boolean)\n"
                "- revised_output (if minor fixes needed)"
            )
        ]
        return await self.llm_complete_json(messages=messages)


class MemoryAgentImpl(BaseAgent):
    """Manages system memory, retrieval, and knowledge organization."""

    agent_name = "memory_agent"
    agent_description = (
        "Memory specialist managing short-term context, long-term knowledge, "
        "and experiment history. Surfaces relevant past experiences."
    )

    async def execute(self, task: str, context: Optional[Dict] = None, task_id: Optional[str] = None) -> Any:
        ctx = context or {}
        operation = ctx.get("operation", "search")

        if operation == "store":
            content = ctx.get("content", task)
            memory_type = ctx.get("memory_type", "knowledge")
            memory_id = await self.store_memory(
                content=content,
                memory_type=memory_type,
                metadata=ctx.get("metadata", {}),
            )
            return {"success": True, "memory_id": memory_id, "operation": "store"}

        elif operation == "search" or operation == "retrieve":
            memories = await self.recall_memory(task, top_k=ctx.get("top_k", 10))
            return {
                "query": task,
                "memories": [
                    {
                        "id": m.id,
                        "content": m.content,
                        "type": m.memory_type,
                        "relevance": m.relevance_score,
                        "metadata": m.metadata,
                    }
                    for m in memories
                ],
                "count": len(memories),
            }

        else:
            # Let LLM decide what to do with the memory system
            memories = await self.recall_memory(task, top_k=5)
            messages = [
                LLMMessage.user(
                    f"Memory management task: {task}\n\n"
                    f"Relevant memories found: {json.dumps([{'content': m.content, 'type': m.memory_type} for m in memories], indent=2)}\n\n"
                    f"Context: {json.dumps(ctx, default=str)}\n\n"
                    "Analyze and provide recommendations. Output JSON."
                )
            ]
            return await self.llm_complete_json(messages=messages)


class ToolManagerAgent(BaseAgent):
    """Manages the tool ecosystem, creates new tools, and enforces permissions."""

    agent_name = "tool_manager"
    agent_description = (
        "Tool ecosystem manager that registers, validates, creates, "
        "and maintains the plugin tool library."
    )

    async def execute(self, task: str, context: Optional[Dict] = None, task_id: Optional[str] = None) -> Any:
        ctx = context or {}
        engine = get_tool_engine()

        # If creating a new tool
        if ctx.get("action") == "create_tool" or "create" in task.lower():
            tool_spec = ctx.get("tool_spec", {})
            if tool_spec:
                success = await engine.register_dynamic_tool(
                    tool_name=tool_spec.get("tool_name", "custom_tool"),
                    description=tool_spec.get("description", ""),
                    code=tool_spec.get("code", ""),
                    json_schema=tool_spec.get("json_schema", {}),
                    permissions=tool_spec.get("permissions", []),
                    dependencies=tool_spec.get("dependencies", []),
                )
                return {"success": success, "tool_name": tool_spec.get("tool_name"), "action": "create"}

        # List tools
        if "list" in task.lower() or ctx.get("action") == "list":
            tools = await engine.list_all_tools()
            return {
                "tools": [{"name": t["name"], "description": t["description"], "category": t["category"]} for t in tools],
                "count": len(tools),
            }

        # General tool management task
        messages = [
            LLMMessage.user(
                f"Tool management task: {task}\n\n"
                f"Context: {json.dumps(ctx, default=str)}\n\n"
                "Respond with tool management recommendations in JSON format."
            )
        ]
        return await self.llm_complete_json(messages=messages)


class MonitoringAgent(BaseAgent):
    """Observes system health, performance, and generates diagnostics."""

    agent_name = "monitoring"
    agent_description = (
        "System health observer tracking agent performance, error rates, "
        "latency, and resource utilization. Generates diagnostics and alerts."
    )

    async def execute(self, task: str, context: Optional[Dict] = None, task_id: Optional[str] = None) -> Any:
        from core.database import get_db
        from core.reliability import get_all_circuit_breakers

        ctx = context or {}
        db = await get_db()

        # Gather real metrics
        recent_tasks = await db.list_tasks(limit=20)
        completed = sum(1 for t in recent_tasks if t["status"] == "completed")
        failed = sum(1 for t in recent_tasks if t["status"] == "failed")
        pending = sum(1 for t in recent_tasks if t["status"] == "pending")

        circuit_breakers = get_all_circuit_breakers()

        metrics = {
            "tasks": {
                "recent_total": len(recent_tasks),
                "completed": completed,
                "failed": failed,
                "pending": pending,
                "success_rate": round(completed / max(len(recent_tasks), 1) * 100, 1),
            },
            "circuit_breakers": circuit_breakers,
            "timestamp": time.time(),
        }

        # LLM analysis of metrics
        messages = [
            LLMMessage.user(
                f"Monitoring task: {task}\n\n"
                f"Current system metrics:\n{json.dumps(metrics, default=str, indent=2)}\n\n"
                f"Context: {json.dumps(ctx, default=str)}\n\n"
                "Analyze system health and provide structured diagnostics in JSON format with:\n"
                "- overall_status (healthy/degraded/critical)\n"
                "- issues\n"
                "- alerts\n"
                "- recommendations\n"
                "- metrics_summary"
            )
        ]
        analysis = await self.llm_complete_json(messages=messages)

        if isinstance(analysis, dict):
            analysis["raw_metrics"] = metrics
        return analysis


class EvolutionAgent(BaseAgent):
    """Manages system self-improvement through controlled experiments."""

    agent_name = "evolution"
    agent_description = (
        "Self-improvement engine that analyzes weaknesses, proposes experiments, "
        "evaluates results, and deploys successful upgrades."
    )

    async def execute(self, task: str, context: Optional[Dict] = None, task_id: Optional[str] = None) -> Any:
        ctx = context or {}
        db = await get_db()

        # Get current system performance for context
        recent_tasks = await db.list_tasks(limit=50)
        failed_tasks = [t for t in recent_tasks if t["status"] == "failed"]

        # Get past experiments from memory
        past_experiments = await self.recall_memory("experiment results", top_k=5, memory_type="experiment")

        messages = [
            LLMMessage.user(
                f"Evolution/improvement task: {task}\n\n"
                f"System performance context:\n"
                f"- Recent tasks: {len(recent_tasks)}, Failed: {len(failed_tasks)}\n"
                f"- Failure rate: {round(len(failed_tasks)/max(len(recent_tasks),1)*100, 1)}%\n\n"
                f"Past experiments:\n{json.dumps([{'content': m.content} for m in past_experiments], indent=2)}\n\n"
                f"Context: {json.dumps(ctx, default=str)}\n\n"
                "Propose or evaluate system improvements. Output structured JSON with:\n"
                "- analysis: current weakness identification\n"
                "- hypothesis: what improvement would help\n"
                "- experiment_design: how to test safely\n"
                "- expected_impact: what metrics would improve\n"
                "- risk_assessment: what could go wrong\n"
                "- recommendation: proceed/hold/abort"
            )
        ]
        result = await self.llm_complete_json(messages=messages)

        # Store experiment in memory
        if isinstance(result, dict):
            await self.store_memory(
                content=f"Evolution experiment: {task}\nResult: {json.dumps(result, default=str)[:500]}",
                memory_type="experiment",
                metadata={"task_id": task_id},
            )

        return result


def create_all_agents(**kwargs) -> Dict[str, BaseAgent]:
    """Factory function to create all specialist agents."""
    return {
        "planner": PlannerAgent(**kwargs),
        "research": ResearchAgent(**kwargs),
        "developer": DeveloperAgent(**kwargs),
        "testing": TestingAgent(**kwargs),
        "critic": CriticAgent(**kwargs),
        "memory_agent": MemoryAgentImpl(**kwargs),
        "tool_manager": ToolManagerAgent(**kwargs),
        "monitoring": MonitoringAgent(**kwargs),
        "evolution": EvolutionAgent(**kwargs),
    }
