"""
MUSTAFA OS - System Kernel
The boot sequence: initializes all components, wires dependencies,
and provides the unified runtime interface.
"""
from __future__ import annotations

import asyncio
import signal
import time
from typing import Any, Dict, Optional

from agents.orchestrator import AgentRegistry, OrchestratorAgent
from agents.specialists import create_all_agents
from core.config import get_settings
from core.database import get_db
from core.llm_client import get_llm_client
from core.logger import get_logger
from core.message_bus import MessageBus, get_message_bus
from core.tool_engine import get_tool_engine
from memory.memory_system import get_memory_system

logger = get_logger("kernel")


class MustafaKernel:
    """
    MUSTAFA OS Kernel — the system runtime.
    Handles initialization, lifecycle management, and request dispatch.
    """

    def __init__(self):
        self._settings = get_settings()
        self._registry: Optional[AgentRegistry] = None
        self._orchestrator: Optional[OrchestratorAgent] = None
        self._message_bus: Optional[MessageBus] = None
        self._started = False
        self._start_time: float = 0.0
        self._request_count = 0
        self._log = logger

    async def boot(self) -> None:
        """
        Full system boot sequence.
        Initializes all subsystems in the correct order.
        """
        self._start_time = time.time()
        self._log.info("MUSTAFA OS booting...")

        try:
            # 1. Database
            self._log.info("Initializing database...")
            db = await get_db()

            # 2. Redis message bus
            self._log.info("Connecting to Redis message bus...")
            self._message_bus = await get_message_bus()
            try:
                await self._message_bus.connect()
                self._log.info("Redis connected")
            except Exception as e:
                self._log.warning(f"Redis unavailable: {e}. Continuing without pub/sub.")

            # 3. Memory system
            self._log.info("Initializing memory system...")
            memory = get_memory_system()
            if self._message_bus and self._message_bus.is_connected:
                await memory.initialize(redis_client=self._message_bus._redis)
            else:
                self._log.warning("Memory system starting without Redis (short-term memory disabled)")

            # 4. Tool engine
            self._log.info("Initializing tool engine...")
            tool_engine = get_tool_engine()
            await tool_engine.initialize()

            # 5. Create agent registry
            self._log.info("Initializing agent registry...")
            self._registry = AgentRegistry()

            # 6. Create all specialist agents
            llm_client = get_llm_client()
            agent_deps = {
                "llm_client": llm_client,
                "memory_system": memory,
                "message_bus": self._message_bus if self._message_bus and self._message_bus.is_connected else None,
            }

            specialists = create_all_agents(**agent_deps)
            for name, agent in specialists.items():
                self._registry.register(agent)

            # 7. Create orchestrator (needs registry)
            self._orchestrator = OrchestratorAgent(
                agent_registry=self._registry,
                **agent_deps,
            )
            self._registry.register(self._orchestrator)

            # 8. Start all agents
            await self._registry.startup_all()

            # 9. Log boot event
            await db.log_event(
                "system_boot",
                "MUSTAFA OS booted successfully",
                severity="info",
                data={"version": "1.0.0", "agents": len(self._registry.list_agents())},
            )

            self._started = True
            boot_time = time.time() - self._start_time
            self._log.info(
                "MUSTAFA OS is ONLINE",
                boot_time_ms=round(boot_time * 1000, 1),
                agents=len(self._registry.list_agents()),
                tools=len(await tool_engine.list_all_tools()),
            )

        except Exception as e:
            self._log.critical("MUSTAFA OS boot FAILED", error=str(e))
            raise

    async def shutdown(self) -> None:
        """Graceful system shutdown."""
        self._log.info("MUSTAFA OS shutting down...")
        try:
            if self._registry:
                await self._registry.shutdown_all()
            if self._message_bus:
                await self._message_bus.disconnect()
            db = await get_db()
            await db.log_event("system_shutdown", "MUSTAFA OS shutdown gracefully")
            await db.disconnect()
            llm = get_llm_client()
            await llm.close()
        except Exception as e:
            self._log.error("Error during shutdown", error=str(e))
        self._started = False
        self._log.info("MUSTAFA OS offline")

    async def process(
        self,
        goal: str,
        session_id: Optional[str] = None,
        context: Optional[Dict] = None,
        task_id: Optional[str] = None,
    ) -> Dict[str, Any]:
        """
        Process a user goal through the orchestrator.
        This is the main entry point for all requests.
        """
        if not self._started or not self._orchestrator:
            return {
                "status": "error",
                "error": "MUSTAFA OS is not running. Please boot the system first.",
            }

        self._request_count += 1
        db = await get_db()

        # Create task record
        effective_task_id = task_id or await db.create_task(
            goal=goal,
            metadata={"session_id": session_id, "request_number": self._request_count},
        )

        # Store conversation in short-term memory if session exists
        if session_id and self._message_bus and self._message_bus.is_connected:
            memory = get_memory_system()
            await memory.short_term.append_conversation(session_id, "user", goal)

        try:
            # Update task status
            await db.update_task(effective_task_id, "running")

            # Run through orchestrator
            result = await self._orchestrator.run(
                task=goal,
                context=context,
                task_id=effective_task_id,
            )

            # Store response in conversation
            if session_id and self._message_bus and self._message_bus.is_connected:
                memory = get_memory_system()
                response_summary = str(result.get("result", result))[:500] if isinstance(result, dict) else str(result)[:500]
                await memory.short_term.append_conversation(session_id, "assistant", response_summary)

            # Update task in DB
            await db.update_task(
                effective_task_id,
                result.get("status", "completed") if isinstance(result, dict) else "completed",
                result=result,
            )

            return result

        except Exception as e:
            self._log.error("Request processing failed", error=str(e), task_id=effective_task_id)
            await db.update_task(effective_task_id, "failed", error=str(e))
            return {
                "status": "error",
                "error": str(e),
                "task_id": effective_task_id,
                "message": "An unexpected error occurred. The system remains operational.",
            }

    async def get_status(self) -> Dict[str, Any]:
        """Get current system status."""
        from core.reliability import get_all_circuit_breakers

        tool_engine = get_tool_engine()
        tools = await tool_engine.list_all_tools()
        db = await get_db()
        recent_tasks = await db.list_tasks(limit=10)

        return {
            "status": "online" if self._started else "offline",
            "uptime_seconds": round(time.time() - self._start_time, 1) if self._started else 0,
            "requests_processed": self._request_count,
            "agents": self._registry.list_agents() if self._registry else [],
            "tools_count": len(tools),
            "recent_tasks": len(recent_tasks),
            "circuit_breakers": get_all_circuit_breakers(),
            "redis_connected": self._message_bus.is_connected if self._message_bus else False,
            "memory_stats": get_memory_system().get_stats(),
        }

    async def health_check(self) -> Dict[str, Any]:
        """Quick health check for monitoring."""
        checks = {}

        # Database
        try:
            db = await get_db()
            await db.list_tasks(limit=1)
            checks["database"] = "ok"
        except Exception as e:
            checks["database"] = f"error: {e}"

        # Redis
        checks["redis"] = "ok" if (
            self._message_bus and await self._message_bus.ping()
        ) else "unavailable"

        # LLM API key
        llm = get_llm_client()
        checks["llm"] = llm.health()

        # Orchestrator
        checks["orchestrator"] = "ok" if self._orchestrator else "not_initialized"

        overall = "healthy" if all(v == "ok" or isinstance(v, dict) for v in checks.values()) else "degraded"

        return {
            "overall": overall,
            "checks": checks,
            "uptime_seconds": round(time.time() - self._start_time, 1),
        }


# Singleton kernel instance
_kernel: Optional[MustafaKernel] = None


def get_kernel() -> MustafaKernel:
    """Get or create the global kernel instance."""
    global _kernel
    if _kernel is None:
        _kernel = MustafaKernel()
    return _kernel
