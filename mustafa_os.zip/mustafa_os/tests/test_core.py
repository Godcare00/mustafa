"""
MUSTAFA OS - Test Suite
Unit tests for core system components.
"""

from __future__ import annotations

import asyncio
import json
import pytest
from unittest.mock import AsyncMock, MagicMock, patch
from typing import Any, Dict


# ─── Fixtures ──────────────────────────────────────────────────────────────────

@pytest.fixture
def sample_message():
    from core.messaging import AgentMessage, MessagePriority
    return AgentMessage(
        sender="test_sender",
        recipient="test_recipient",
        message_type="test_task",
        payload={"goal": "test goal", "task_id": "test-123"},
        priority=MessagePriority.NORMAL,
    )


@pytest.fixture
def mock_llm_client():
    mock = AsyncMock()
    mock.complete_simple.return_value = '{"result": "test result"}'
    mock.health_check.return_value = True
    return mock


# ─── Core Settings Tests ───────────────────────────────────────────────────────

class TestSettings:
    def test_settings_load(self):
        from core.settings import get_settings
        s = get_settings()
        assert s.system_name == "MUSTAFA_OS"
        assert s.system_version == "1.0.0"

    def test_telegram_user_ids_empty(self):
        from core.settings import get_settings
        s = get_settings()
        # When empty string, should return empty list
        if not s.telegram_authorized_users:
            assert s.telegram_user_ids == []

    def test_production_flag(self):
        from core.settings import get_settings
        s = get_settings()
        assert isinstance(s.is_production, bool)


# ─── Message Bus Tests ─────────────────────────────────────────────────────────

class TestAgentMessage:
    def test_message_serialization(self, sample_message):
        json_str = sample_message.to_json()
        data = json.loads(json_str)
        assert data["sender"] == "test_sender"
        assert data["recipient"] == "test_recipient"
        assert data["message_type"] == "test_task"

    def test_message_deserialization(self, sample_message):
        from core.messaging import AgentMessage
        json_str = sample_message.to_json()
        restored = AgentMessage.from_json(json_str)
        assert restored.sender == sample_message.sender
        assert restored.message_id == sample_message.message_id

    def test_message_has_uuid(self, sample_message):
        import uuid
        assert uuid.UUID(sample_message.message_id)

    def test_message_priority(self):
        from core.messaging import AgentMessage, MessagePriority
        msg = AgentMessage(
            sender="a", recipient="b",
            message_type="test",
            priority=MessagePriority.CRITICAL,
        )
        assert msg.priority == MessagePriority.CRITICAL


# ─── Registry Tests ────────────────────────────────────────────────────────────

class TestAgentRegistry:
    @pytest.mark.asyncio
    async def test_register_agent(self):
        from core.registry import AgentRegistry, AgentStatus
        registry = AgentRegistry()
        info = await registry.register("test_agent", "Test Agent", ["capability_a"])
        assert info.agent_id == "test_agent"
        assert info.status == AgentStatus.INITIALIZING

    @pytest.mark.asyncio
    async def test_unregister_agent(self):
        from core.registry import AgentRegistry
        registry = AgentRegistry()
        await registry.register("to_remove", "Remove Me", [])
        await registry.unregister("to_remove")
        assert registry.get_agent("to_remove") is None

    @pytest.mark.asyncio
    async def test_update_status(self):
        from core.registry import AgentRegistry, AgentStatus
        registry = AgentRegistry()
        await registry.register("status_test", "Status Test", [])
        await registry.update_status("status_test", AgentStatus.IDLE)
        agent = registry.get_agent("status_test")
        assert agent.status == AgentStatus.IDLE

    @pytest.mark.asyncio
    async def test_record_task_result(self):
        from core.registry import AgentRegistry, AgentStatus
        registry = AgentRegistry()
        await registry.register("task_test", "Task Test", [])
        await registry.update_status("task_test", AgentStatus.IDLE)
        await registry.record_task_result("task_test", success=True)
        agent = registry.get_agent("task_test")
        assert agent.task_count == 1
        assert agent.success_count == 1

    @pytest.mark.asyncio
    async def test_get_agents_by_capability(self):
        from core.registry import AgentRegistry
        registry = AgentRegistry()
        await registry.register("cap_agent", "Cap Agent", ["research", "web_search"])
        agents = registry.get_agents_by_capability("research")
        assert any(a.agent_id == "cap_agent" for a in agents)

    def test_system_summary_empty(self):
        from core.registry import AgentRegistry
        registry = AgentRegistry()
        summary = registry.get_system_summary()
        assert "total_agents" in summary
        assert "idle" in summary


# ─── Reliability Tests ─────────────────────────────────────────────────────────

class TestRetryAsync:
    @pytest.mark.asyncio
    async def test_retry_on_failure(self):
        from core.reliability import retry_async
        call_count = 0

        @retry_async(max_attempts=3, base_delay=0.01)
        async def flaky():
            nonlocal call_count
            call_count += 1
            if call_count < 3:
                raise ValueError("Not yet")
            return "success"

        result = await flaky()
        assert result == "success"
        assert call_count == 3

    @pytest.mark.asyncio
    async def test_retry_exhausted(self):
        from core.reliability import retry_async

        @retry_async(max_attempts=2, base_delay=0.01)
        async def always_fails():
            raise RuntimeError("always")

        with pytest.raises(RuntimeError):
            await always_fails()

    @pytest.mark.asyncio
    async def test_no_retry_on_success(self):
        from core.reliability import retry_async
        call_count = 0

        @retry_async(max_attempts=3, base_delay=0.01)
        async def succeeds():
            nonlocal call_count
            call_count += 1
            return "ok"

        result = await succeeds()
        assert result == "ok"
        assert call_count == 1


class TestCircuitBreaker:
    @pytest.mark.asyncio
    async def test_opens_after_threshold(self):
        from core.reliability import CircuitBreaker, CircuitBreakerOpenError, CircuitState

        cb = CircuitBreaker("test_cb", failure_threshold=3, recovery_timeout=60)

        async def failing():
            raise ValueError("fail")

        for _ in range(3):
            try:
                await cb.call(failing)
            except ValueError:
                pass

        assert cb.state == CircuitState.OPEN

    @pytest.mark.asyncio
    async def test_passes_when_closed(self):
        from core.reliability import CircuitBreaker

        cb = CircuitBreaker("test_pass")

        async def succeeds():
            return 42

        result = await cb.call(succeeds)
        assert result == 42

    @pytest.mark.asyncio
    async def test_reset(self):
        from core.reliability import CircuitBreaker, CircuitState

        cb = CircuitBreaker("test_reset", failure_threshold=1)

        async def failing():
            raise ValueError("fail")

        try:
            await cb.call(failing)
        except ValueError:
            pass

        cb.reset()
        assert cb.state == CircuitState.CLOSED


# ─── Tool Tests ────────────────────────────────────────────────────────────────

class TestToolExecutionEngine:
    def test_register_tool(self):
        from tools.base import ToolExecutionEngine, BaseTool, ToolResult

        class DummyTool(BaseTool):
            name = "dummy"
            description = "A dummy tool"
            permissions = ["test"]

            async def execute(self, params):
                return ToolResult(success=True, data={"value": params.get("x", 0)})

        engine = ToolExecutionEngine()
        engine.register(DummyTool())
        tools = engine.get_all_tools()
        assert any(t.name == "dummy" for t in tools)

    @pytest.mark.asyncio
    async def test_execute_tool_success(self):
        from tools.base import ToolExecutionEngine, BaseTool, ToolResult

        class EchoTool(BaseTool):
            name = "echo"
            description = "Echoes input"
            permissions = ["compute"]

            async def execute(self, params):
                return ToolResult(success=True, data={"echo": params.get("message")})

        engine = ToolExecutionEngine()
        engine.register(EchoTool())
        engine.set_agent_permissions("test_agent", ["echo"])

        result = await engine.execute("echo", "test_agent", {"message": "hello"})
        assert result.success
        assert result.data["echo"] == "hello"

    @pytest.mark.asyncio
    async def test_permission_denied(self):
        from tools.base import ToolExecutionEngine, BaseTool, ToolResult

        class SecretTool(BaseTool):
            name = "secret"
            description = "Secret tool"
            permissions = ["admin"]

            async def execute(self, params):
                return ToolResult(success=True, data={})

        engine = ToolExecutionEngine()
        engine.register(SecretTool())
        engine.set_agent_permissions("limited_agent", ["echo"])  # No "secret" permission

        result = await engine.execute("secret", "limited_agent", {})
        assert not result.success
        assert "permission" in result.error.lower()

    @pytest.mark.asyncio
    async def test_tool_not_found(self):
        from tools.base import ToolExecutionEngine
        engine = ToolExecutionEngine()
        engine.set_agent_permissions("agent", ["*"])
        result = await engine.execute("nonexistent", "agent", {})
        assert not result.success


# ─── Data Analysis Tool Tests ──────────────────────────────────────────────────

class TestDataAnalysisTool:
    @pytest.mark.asyncio
    async def test_stats(self):
        from tools.analysis_executor import DataAnalysisTool
        tool = DataAnalysisTool()
        result = await tool.execute({"operation": "stats", "data": [1, 2, 3, 4, 5]})
        assert result.success
        assert result.data["stats"]["mean"] == 3.0
        assert result.data["stats"]["count"] == 5

    @pytest.mark.asyncio
    async def test_filter(self):
        from tools.analysis_executor import DataAnalysisTool
        tool = DataAnalysisTool()
        data = [{"name": "Alice", "age": 30}, {"name": "Bob", "age": 25}]
        result = await tool.execute({
            "operation": "filter",
            "data": data,
            "params": {"field": "age", "operator": "gt", "value": 26},
        })
        assert result.success
        assert result.data["count"] == 1
        assert result.data["filtered"][0]["name"] == "Alice"


# ─── Agent Result Tests ────────────────────────────────────────────────────────

class TestAgentResult:
    def test_ok_result(self):
        from agents.base import AgentResult
        r = AgentResult.ok({"answer": "42"})
        assert r.success
        assert r.data["answer"] == "42"
        assert r.error is None

    def test_fail_result(self):
        from agents.base import AgentResult
        r = AgentResult.fail("Something went wrong")
        assert not r.success
        assert r.error == "Something went wrong"

    def test_to_dict(self):
        from agents.base import AgentResult
        r = AgentResult.ok("test data")
        d = r.to_dict()
        assert "success" in d
        assert "data" in d
        assert "timestamp" in d


# ─── File Manager Tool Tests ───────────────────────────────────────────────────

class TestFileManagerTool:
    @pytest.mark.asyncio
    async def test_write_and_read(self, tmp_path, monkeypatch):
        from tools.file_manager import FileManagerTool, ALLOWED_BASE_DIRS

        # Temporarily allow tmp_path
        test_path = str(tmp_path / "test.txt")
        monkeypatch.setattr(
            "tools.file_manager.ALLOWED_BASE_DIRS",
            ALLOWED_BASE_DIRS + [str(tmp_path)],
        )

        tool = FileManagerTool()
        write_result = await tool.execute({
            "operation": "write",
            "path": test_path,
            "content": "Hello MUSTAFA OS",
        })
        assert write_result.success

        read_result = await tool.execute({"operation": "read", "path": test_path})
        assert read_result.success
        assert read_result.data["content"] == "Hello MUSTAFA OS"

    @pytest.mark.asyncio
    async def test_path_traversal_blocked(self):
        from tools.file_manager import FileManagerTool
        tool = FileManagerTool()
        result = await tool.execute({"operation": "read", "path": "/etc/passwd"})
        assert not result.success
        assert "Access denied" in result.error


if __name__ == "__main__":
    pytest.main([__file__, "-v", "--tb=short"])
