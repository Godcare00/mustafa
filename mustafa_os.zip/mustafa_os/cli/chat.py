"""
MUSTAFA OS - CLI Chat Interface
Full-featured terminal chat for interacting with MUSTAFA OS.
Supports session continuity, command shortcuts, and rich output formatting.
"""
from __future__ import annotations

import asyncio
import json
import os
import sys
import textwrap
import time
import uuid
from pathlib import Path
from typing import Any, Dict, Optional

# Add project root to path
sys.path.insert(0, str(Path(__file__).parent.parent))


BANNER = """
╔══════════════════════════════════════════════════════════════════╗
║                                                                  ║
║    ███╗   ███╗██╗   ██╗███████╗████████╗ █████╗ ███████╗ █████╗ ║
║    ████╗ ████║██║   ██║██╔════╝╚══██╔══╝██╔══██╗██╔════╝██╔══██╗║
║    ██╔████╔██║██║   ██║███████╗   ██║   ███████║█████╗  ███████║║
║    ██║╚██╔╝██║██║   ██║╚════██║   ██║   ██╔══██║██╔══╝  ██╔══██║║
║    ██║ ╚═╝ ██║╚██████╔╝███████║   ██║   ██║  ██║██║     ██║  ██║║
║    ╚═╝     ╚═╝ ╚═════╝ ╚══════╝   ╚═╝   ╚═╝  ╚═╝╚═╝     ╚═╝  ╚═╝║
║                                                                  ║
║          Modular Unified System for Task Automation              ║
║               and Autonomous Intelligence  v1.0.0                ║
╚══════════════════════════════════════════════════════════════════╝
"""

HELP_TEXT = """
MUSTAFA OS CLI Commands:
  /help          Show this help message
  /status        Show system status
  /agents        List all agents and their status
  /tools         List all available tools
  /tasks         Show recent tasks
  /memory <q>    Search memory for a query
  /health        Run system health check
  /clear         Clear the screen
  /session       Show current session ID
  /new           Start a new session
  /exit          Shut down and exit

Just type anything else to send it to the Orchestrator.
"""

# ANSI color codes
class Color:
    RESET   = "\033[0m"
    BOLD    = "\033[1m"
    DIM     = "\033[2m"
    RED     = "\033[91m"
    GREEN   = "\033[92m"
    YELLOW  = "\033[93m"
    BLUE    = "\033[94m"
    MAGENTA = "\033[95m"
    CYAN    = "\033[96m"
    WHITE   = "\033[97m"
    GRAY    = "\033[90m"


def cprint(text: str, color: str = "", bold: bool = False) -> None:
    """Print colored text to terminal."""
    prefix = ""
    if bold:
        prefix += Color.BOLD
    prefix += color
    print(f"{prefix}{text}{Color.RESET}")


def print_separator(char: str = "─", width: int = 68, color: str = Color.GRAY) -> None:
    print(f"{color}{char * width}{Color.RESET}")


def format_result(result: Any, indent: int = 0) -> str:
    """Format a result dict for display."""
    if isinstance(result, dict):
        lines = []
        status = result.get("status", "")
        if status == "completed":
            final = result.get("result") or result.get("message", "")
            if isinstance(final, dict):
                lines.append(json.dumps(final, indent=2, default=str))
            elif isinstance(final, str):
                lines.append(final)
            else:
                lines.append(str(final))
        elif status in ("error", "max_iterations_reached", "needs_input"):
            msg = result.get("message") or result.get("error", str(result))
            lines.append(msg)
            if result.get("alternatives"):
                lines.append("\nAlternatives:")
                for alt in result["alternatives"]:
                    lines.append(f"  • {alt}")
        else:
            lines.append(json.dumps(result, indent=2, default=str))
        return "\n".join(lines)
    elif isinstance(result, str):
        return result
    else:
        return json.dumps(result, indent=2, default=str)


def print_result(result: Any) -> None:
    """Pretty-print a result."""
    if isinstance(result, dict):
        status = result.get("status", "unknown")
        task_id = result.get("task_id", "")
        iterations = result.get("iterations")
        processing_ms = result.get("processing_time_ms")

        # Status line
        if status == "completed":
            status_color = Color.GREEN
            status_icon = "✓"
        elif status == "error":
            status_color = Color.RED
            status_icon = "✗"
        elif status == "needs_input":
            status_color = Color.YELLOW
            status_icon = "?"
        else:
            status_color = Color.YELLOW
            status_icon = "~"

        meta_parts = []
        if task_id:
            meta_parts.append(f"task:{task_id[:8]}")
        if iterations:
            meta_parts.append(f"{iterations} iterations")
        if processing_ms:
            meta_parts.append(f"{processing_ms:.0f}ms")
        meta = "  " + Color.GRAY + " | ".join(meta_parts) + Color.RESET if meta_parts else ""

        cprint(f"\n{status_icon} [{status.upper()}]{meta}", color=status_color, bold=True)
        print_separator()

        formatted = format_result(result)
        # Wrap long lines
        for line in formatted.split("\n"):
            if len(line) > 100:
                wrapped = textwrap.fill(line, width=100, subsequent_indent="  ")
                print(wrapped)
            else:
                print(line)
    else:
        print(str(result))


async def run_cli() -> None:
    """Main CLI entry point."""
    # Suppress JSON logs from appearing in the terminal — they go to the log file.
    # Users can re-enable with: MUSTAFA_LOG_CONSOLE=1 ./start_cli.sh
    import os as _os
    if _os.environ.get("MUSTAFA_LOG_CONSOLE") is None:
        _os.environ["MUSTAFA_LOG_CONSOLE"] = "0"
    # Suppress onnxruntime GPU discovery noise from sentence-transformers
    _os.environ.setdefault("ORT_LOGGING_LEVEL", "3")  # 3 = ERROR only
    _os.environ.setdefault("TOKENIZERS_PARALLELISM", "false")

    from core.kernel import get_kernel
    from core.database import get_db
    from core.tool_engine import get_tool_engine

    # Print banner
    cprint(BANNER, color=Color.CYAN)

    cprint("Booting MUSTAFA OS...", color=Color.YELLOW)
    kernel = get_kernel()

    try:
        await kernel.boot()
        cprint("✓ System online", color=Color.GREEN, bold=True)
    except Exception as e:
        cprint(f"✗ Boot failed: {e}", color=Color.RED, bold=True)
        cprint("Check your .env file and ensure Redis is running.", color=Color.YELLOW)
        return

    print_separator()
    cprint("Type /help for commands, or just start talking to MUSTAFA OS.", color=Color.GRAY)
    print_separator()

    session_id = str(uuid.uuid4())
    cprint(f"Session: {session_id[:8]}", color=Color.GRAY)
    print()

    try:
        loop = asyncio.get_event_loop()
        while True:
            try:
                # Use executor so input() doesn't block the event loop
                user_input = await loop.run_in_executor(
                    None,
                    lambda: input(f"{Color.CYAN}{Color.BOLD}You ▶ {Color.RESET}"),
                )
                user_input = user_input.strip()
            except (EOFError, KeyboardInterrupt):
                print()
                cprint("\nShutting down...", color=Color.YELLOW)
                break

            if not user_input:
                continue

            # ─── CLI Commands ───────────────────────────────────────────────

            if user_input.lower() in ("/exit", "/quit", "exit", "quit"):
                cprint("Shutting down MUSTAFA OS...", color=Color.YELLOW)
                break

            elif user_input.lower() == "/help":
                cprint(HELP_TEXT, color=Color.CYAN)
                continue

            elif user_input.lower() == "/clear":
                os.system("clear" if os.name != "nt" else "cls")
                cprint(BANNER, color=Color.CYAN)
                continue

            elif user_input.lower() == "/session":
                cprint(f"Current session: {session_id}", color=Color.GRAY)
                continue

            elif user_input.lower() == "/new":
                session_id = str(uuid.uuid4())
                cprint(f"New session started: {session_id[:8]}", color=Color.GREEN)
                continue

            elif user_input.lower() == "/status":
                cprint("\nFetching system status...", color=Color.GRAY)
                status = await kernel.get_status()
                cprint("\nSYSTEM STATUS", color=Color.CYAN, bold=True)
                print_separator()
                cprint(f"  State:    {status['status'].upper()}", color=Color.GREEN if status['status'] == 'online' else Color.RED)
                cprint(f"  Uptime:   {status['uptime_seconds']:.1f}s", color=Color.WHITE)
                cprint(f"  Requests: {status['requests_processed']}", color=Color.WHITE)
                cprint(f"  Agents:   {len(status['agents'])}", color=Color.WHITE)
                cprint(f"  Tools:    {status['tools_count']}", color=Color.WHITE)
                cprint(f"  Redis:    {'connected' if status['redis_connected'] else 'unavailable'}", 
                       color=Color.GREEN if status['redis_connected'] else Color.YELLOW)
                print()
                continue

            elif user_input.lower() == "/health":
                cprint("\nRunning health check...", color=Color.GRAY)
                health = await kernel.health_check()
                overall_color = Color.GREEN if health['overall'] == 'healthy' else Color.YELLOW
                cprint(f"\nHEALTH: {health['overall'].upper()}", color=overall_color, bold=True)
                print_separator()
                for check, result in health['checks'].items():
                    ok = result == "ok" or isinstance(result, dict)
                    icon = "✓" if ok else "✗"
                    color = Color.GREEN if ok else Color.RED
                    val = json.dumps(result) if isinstance(result, dict) else str(result)
                    cprint(f"  {icon} {check}: {val}", color=color)
                print()
                continue

            elif user_input.lower() == "/agents":
                cprint("\nREGISTERED AGENTS", color=Color.CYAN, bold=True)
                print_separator()
                if kernel._registry:
                    for a in kernel._registry.list_agents():
                        status_color = Color.GREEN if a['status'] == 'idle' else Color.YELLOW
                        cprint(f"  • {a['name']:<20} [{a['status']}]", color=status_color)
                        cprint(f"    {a['description']}", color=Color.GRAY)
                print()
                continue

            elif user_input.lower() == "/tools":
                cprint("\nAVAILABLE TOOLS", color=Color.CYAN, bold=True)
                print_separator()
                engine = get_tool_engine()
                tools = await engine.list_all_tools()
                categories: Dict[str, list] = {}
                for t in tools:
                    cat = t.get("category", "other")
                    categories.setdefault(cat, []).append(t)
                for cat, cat_tools in sorted(categories.items()):
                    cprint(f"\n  [{cat.upper()}]", color=Color.YELLOW)
                    for t in cat_tools:
                        cprint(f"    • {t['name']:<25} {t['description'][:55]}", color=Color.WHITE)
                print()
                continue

            elif user_input.lower() == "/tasks":
                cprint("\nRECENT TASKS", color=Color.CYAN, bold=True)
                print_separator()
                db = await get_db()
                tasks = await db.list_tasks(limit=10)
                if not tasks:
                    cprint("  No tasks yet.", color=Color.GRAY)
                else:
                    for t in tasks:
                        status = t['status']
                        color = Color.GREEN if status == 'completed' else (Color.RED if status == 'failed' else Color.YELLOW)
                        goal_preview = t['goal'][:55] + "..." if len(t['goal']) > 55 else t['goal']
                        cprint(f"  [{status:<10}] {t['id'][:8]}  {goal_preview}", color=color)
                print()
                continue

            elif user_input.lower().startswith("/memory "):
                query = user_input[8:].strip()
                if not query:
                    cprint("Usage: /memory <search query>", color=Color.YELLOW)
                    continue
                cprint(f"\nSearching memory for: '{query}'...", color=Color.GRAY)
                from memory.memory_system import get_memory_system
                memory = get_memory_system()
                memories = await memory.recall(query, top_k=5)
                cprint(f"\nMEMORY RESULTS ({len(memories)} found)", color=Color.CYAN, bold=True)
                print_separator()
                if memories:
                    for m in memories:
                        cprint(f"  [{m.memory_type}] score:{m.relevance_score:.2f}", color=Color.YELLOW)
                        cprint(f"  {m.content[:120]}", color=Color.WHITE)
                        print()
                else:
                    cprint("  No relevant memories found.", color=Color.GRAY)
                continue

            # ─── Send to Orchestrator ────────────────────────────────────────

            cprint(f"\n{Color.GRAY}MUSTAFA OS ▶ Processing...{Color.RESET}", color="")

            start_time = time.monotonic()
            result = await kernel.process(
                goal=user_input,
                session_id=session_id,
            )
            elapsed_ms = (time.monotonic() - start_time) * 1000

            # Inject elapsed time so print_result can display it
            if isinstance(result, dict) and "processing_time_ms" not in result:
                result["processing_time_ms"] = round(elapsed_ms, 1)

            print_result(result)
            print()

    finally:
        await kernel.shutdown()
        cprint("\nGoodbye. MUSTAFA OS offline.", color=Color.CYAN)


def main() -> None:
    """Entry point for CLI."""
    asyncio.run(run_cli())


if __name__ == "__main__":
    main()
