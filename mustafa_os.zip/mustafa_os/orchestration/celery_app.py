"""
MUSTAFA OS - Celery Task Queue
Distributed task execution with Redis broker for background jobs.
"""

from __future__ import annotations

from celery import Celery
from core.settings import settings

celery_app = Celery(
    "mustafa_os",
    broker=settings.celery_broker_url,
    backend=settings.celery_result_backend,
    include=["orchestration.tasks"],
)

celery_app.conf.update(
    task_serializer="json",
    accept_content=["json"],
    result_serializer="json",
    timezone="UTC",
    enable_utc=True,
    task_track_started=True,
    task_acks_late=True,
    worker_prefetch_multiplier=1,
    task_soft_time_limit=270,
    task_time_limit=300,
    result_expires=3600,
)
