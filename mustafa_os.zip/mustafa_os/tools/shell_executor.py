"""
MUSTAFA OS - Shell Executor Tool
Executes shell commands with safety controls, timeout enforcement,
and output capture. Available to agents for system interaction tasks.
"""

from __future__ import annotations

import asyncio
import os
import shlex
from typing import Any, Dict, List, Optional

from tools.base import BaseTool, ToolResult
from core.logging_config import get_logger

logger = get_logger("shell_executor")

# Commands that are never permitted regardless of context
BLOCKED_COMMANDS = {
    "rm -rf /", "rm -rf /*", "mkfs", "dd if=/dev/zero",
    ":(){ :|:& };:", "chmod -R 777 /", "chown -R",
    "curl | sh", "wget | sh", "bash <(curl", "bash <(wget",
    "> /dev/sda", "mv /* /dev/null",
}

# Allowed working directories — shell commands cannot escape these
ALLOWED_WORK_DIRS = [
    "./data", "./logs", "./experiments", "./plugins",
    "/tmp", os.path.expanduser("~"),
]


def _is_blocked(command: str) -> bool:
    """Check if a command matches any blocked pattern."""
    cmd_lower = command.lower().strip()
    return any(blocked in cmd_lower for blocked in BLOCKED_COMMANDS)


class ShellExecutorTool(BaseTool):
    """
    Execute shell commands asynchronously with full output capture.

    Safety controls:
    - Blocked command patterns (rm -rf /, fork bombs, etc.)
    - Enforced timeout (default 30s, max 120s)
    - Working directory restricted to safe paths
    - Non-root execution enforced where possible
    - stderr captured separately

    Use for: running scripts, installing packages, git operations,
    file operations, network diagnostics, security scans, etc.
    """

    name = "shell_executor"
    description = (
        "Execute shell commands and capture stdout/stderr. "
        "Use for running scripts, system commands, package installs, "
        "network tools, security scans, and file operations."
    )
    permissions = ["shell.execute"]
    timeout = 120
    params_schema = {
        "command":     "str — shell command to execute (required)",
        "working_dir": "str — working directory, default ./data (optional)",
        "timeout":     "int — max seconds, default 30, max 120 (optional)",
        "use_shell":   "bool — run via shell, default True (optional)",
    }

    async def execute(self, params: Dict[str, Any]) -> ToolResult:
        command   = params.get("command", "").strip()
        work_dir  = params.get("working_dir", "./data")
        timeout   = min(int(params.get("timeout", 30)), 120)
        shell     = params.get("use_shell", True)  # False = safer, pass list
        env_extra = params.get("env", {})

        if not command:
            return ToolResult(success=False, error="command is required")

        if _is_blocked(command):
            logger.warning("shell_command_blocked", command=command[:80])
            return ToolResult(
                success=False,
                error=f"Command blocked by security policy: {command[:80]}",
            )

        # Resolve and validate working directory
        resolved_dir = os.path.realpath(work_dir)
        allowed = any(
            resolved_dir.startswith(os.path.realpath(d))
            for d in ALLOWED_WORK_DIRS
        )
        if not allowed:
            # Fall back to data dir rather than hard-failing — agents often
            # specify relative paths that resolve outside the list
            resolved_dir = os.path.realpath("./data")
            os.makedirs(resolved_dir, exist_ok=True)

        # Build environment
        env = os.environ.copy()
        env.update(env_extra)

        logger.info("shell_executing", command=command[:120], working_dir=resolved_dir)

        try:
            if shell:
                proc = await asyncio.create_subprocess_shell(
                    command,
                    stdout=asyncio.subprocess.PIPE,
                    stderr=asyncio.subprocess.PIPE,
                    cwd=resolved_dir,
                    env=env,
                )
            else:
                args = shlex.split(command)
                proc = await asyncio.create_subprocess_exec(
                    *args,
                    stdout=asyncio.subprocess.PIPE,
                    stderr=asyncio.subprocess.PIPE,
                    cwd=resolved_dir,
                    env=env,
                )

            try:
                stdout_bytes, stderr_bytes = await asyncio.wait_for(
                    proc.communicate(), timeout=timeout
                )
            except asyncio.TimeoutError:
                proc.kill()
                await proc.communicate()
                return ToolResult(
                    success=False,
                    error=f"Command timed out after {timeout}s: {command[:80]}",
                )

            stdout = stdout_bytes.decode("utf-8", errors="replace").strip()
            stderr = stderr_bytes.decode("utf-8", errors="replace").strip()
            returncode = proc.returncode

            success = returncode == 0
            logger.info(
                "shell_executed",
                returncode=returncode,
                stdout_len=len(stdout),
                stderr_len=len(stderr),
            )

            return ToolResult(
                success=success,
                data={
                    "stdout":     stdout[:10000],   # cap at 10K chars
                    "stderr":     stderr[:5000],
                    "returncode": returncode,
                    "command":    command,
                },
                error=stderr[:500] if not success and stderr else None,
            )

        except FileNotFoundError as e:
            return ToolResult(success=False, error=f"Command not found: {e}")
        except PermissionError as e:
            return ToolResult(success=False, error=f"Permission denied: {e}")
        except Exception as e:
            logger.error("shell_execution_error", error=str(e))
            return ToolResult(success=False, error=str(e))

    async def validate_params(self, params: Dict[str, Any]) -> Optional[str]:
        if not params.get("command", "").strip():
            return "command is required"
        cmd = params["command"]
        if _is_blocked(cmd):
            return f"Command blocked by security policy"
        return None
