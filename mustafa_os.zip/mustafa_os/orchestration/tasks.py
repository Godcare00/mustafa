"""
MUSTAFA OS - Celery Background Tasks
Long-running and scheduled background work.
"""

from __future__ import annotations

import asyncio
from typing import Any, Dict

from orchestration.celery_app import celery_app


def run_async(coro):
    """Run an async coroutine from a sync Celery task."""
    try:
        loop = asyncio.get_event_loop()
        if loop.is_running():
            import concurrent.futures
            with concurrent.futures.ThreadPoolExecutor() as pool:
                future = pool.submit(asyncio.run, coro)
                return future.result()
        else:
            return loop.run_until_complete(coro)
    except RuntimeError:
        return asyncio.run(coro)


@celery_app.task(name="execute_goal", bind=True, max_retries=2)
def execute_goal_task(self, goal: str, task_id: str) -> Dict[str, Any]:
    """Execute a goal asynchronously via Celery worker."""
    async def _run():
        from core.kernel import kernel
        if not kernel.is_running:
            await kernel.boot()

        orchestrator = kernel.get_orchestrator()
        if not orchestrator:
            raise RuntimeError("Orchestrator not available")

        from agents.base import TaskContext
        context = TaskContext(
            task_id=task_id,
            goal=goal,
            payload={"goal": goal, "task_id": task_id},
        )
        result = await orchestrator.handle_task("execute_goal", context)
        return result.to_dict()

    try:
        return run_async(_run())
    except Exception as exc:
        raise self.retry(exc=exc, countdown=10)


@celery_app.task(name="run_evolution_cycle")
def run_evolution_cycle_task() -> Dict[str, Any]:
    """Run a self-improvement evolution cycle in the background."""
    async def _run():
        from core.messaging import message_bus
        if not await message_bus.health_check():
            await message_bus.connect()

        correlation_id = await message_bus.send_task(
            sender="celery",
            recipient="evolution",
            task_type="run_evolution_cycle",
            payload={"triggered_by": "scheduler"},
        )
        return {"triggered": True, "correlation_id": correlation_id}

    return run_async(_run())


@celery_app.on_after_configure.connect
def setup_periodic_tasks(sender, **kwargs):
    """Register periodic (scheduled) tasks."""
    # Run evolution cycle every 24 hours
    sender.add_periodic_task(
        86400.0,  # 24 hours
        run_evolution_cycle_task.s(),
        name="daily_evolution_cycle",
    )
