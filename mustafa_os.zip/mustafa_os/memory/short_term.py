"""
MUSTAFA OS - Short-Term Memory
Redis-backed context memory for conversation and task state.
"""

from __future__ import annotations

import json
from datetime import datetime
from typing import Any, Dict, List, Optional

from core.logging_config import get_logger
from core.messaging import message_bus

logger = get_logger("short_term_memory")


class ShortTermMemory:
    """
    Fast, ephemeral memory backed by Redis.
    Stores conversation context, active task state, and inter-agent scratchpad.
    """

    CONTEXT_TTL = 3600        # 1 hour
    SCRATCHPAD_TTL = 1800     # 30 minutes
    MAX_HISTORY_ITEMS = 50

    async def store_context(
        self,
        session_id: str,
        key: str,
        value: Any,
        ttl: int = CONTEXT_TTL,
    ) -> None:
        """Store a context value for a session."""
        full_key = f"context:{session_id}:{key}"
        await message_bus.set_value(full_key, value, ttl=ttl)

    async def get_context(
        self,
        session_id: str,
        key: str,
    ) -> Optional[Any]:
        """Retrieve a context value."""
        full_key = f"context:{session_id}:{key}"
        return await message_bus.get_value(full_key)

    async def append_history(
        self,
        session_id: str,
        role: str,
        content: str,
    ) -> None:
        """Append a message to conversation history."""
        history = await self.get_history(session_id) or []
        history.append({
            "role": role,
            "content": content,
            "timestamp": datetime.utcnow().isoformat(),
        })
        # Keep only recent history
        history = history[-self.MAX_HISTORY_ITEMS:]
        await message_bus.set_value(
            f"history:{session_id}", history, ttl=self.CONTEXT_TTL
        )

    async def get_history(
        self,
        session_id: str,
        limit: int = 20,
    ) -> List[Dict[str, Any]]:
        """Retrieve conversation history."""
        history = await message_bus.get_value(f"history:{session_id}") or []
        return history[-limit:]

    async def clear_session(self, session_id: str) -> None:
        """Clear all context for a session."""
        await message_bus.delete_value(f"history:{session_id}")
        await message_bus.delete_value(f"context:{session_id}:*")

    async def set_scratchpad(
        self,
        agent_id: str,
        data: Dict[str, Any],
    ) -> None:
        """Set agent scratchpad (working memory)."""
        await message_bus.set_value(
            f"scratchpad:{agent_id}", data, ttl=self.SCRATCHPAD_TTL
        )

    async def get_scratchpad(self, agent_id: str) -> Dict[str, Any]:
        """Get agent scratchpad."""
        return await message_bus.get_value(f"scratchpad:{agent_id}") or {}


# Singleton
short_term_memory = ShortTermMemory()
