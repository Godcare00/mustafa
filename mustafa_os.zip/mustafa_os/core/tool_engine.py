"""
MUSTAFA OS - Tool Execution Engine
Dynamic plugin-based tool system with JSON schema validation,
sandboxing, permissions, and runtime tool creation.
"""
from __future__ import annotations

import asyncio
import importlib
import importlib.util
import json
import os
import subprocess
import sys
import tempfile
import time
import traceback
import uuid
from pathlib import Path
from typing import Any, Dict, List, Optional, Type

import httpx
import jsonschema

from core.config import get_settings
from core.database import get_db
from core.logger import get_logger

logger = get_logger("tool_engine")

TOOLS_DIR = Path(__file__).parent.parent / "tools"


class ToolResult:
    """Standardized tool execution result."""

    def __init__(
        self,
        tool_name: str,
        success: bool,
        output: Any = None,
        error: Optional[str] = None,
        duration_ms: float = 0.0,
    ):
        self.tool_name = tool_name
        self.success = success
        self.output = output
        self.error = error
        self.duration_ms = duration_ms

    def to_dict(self) -> Dict:
        return {
            "tool": self.tool_name,
            "success": self.success,
            "output": self.output,
            "error": self.error,
            "duration_ms": round(self.duration_ms, 1),
        }


class ToolPermissionError(Exception):
    """Raised when a tool execution is denied due to permissions."""
    pass


class ToolValidationError(Exception):
    """Raised when tool input fails JSON schema validation."""
    pass


class ToolNotFoundError(Exception):
    """Raised when a tool is not found in the registry."""
    pass


# ─── Built-in Tool Implementations ───────────────────────────────────────────

async def _tool_web_search(query: str, max_results: int = 5) -> Dict:
    """Web search using DuckDuckGo."""
    try:
        async with httpx.AsyncClient(timeout=20.0) as client:
            params = {
                "q": query,
                "format": "json",
                "no_html": "1",
                "skip_disambig": "1",
            }
            response = await client.get("https://api.duckduckgo.com/", params=params)
            data = response.json()

            results = []
            # Instant answer
            if data.get("AbstractText"):
                results.append({
                    "title": data.get("Heading", "Summary"),
                    "url": data.get("AbstractURL", ""),
                    "snippet": data["AbstractText"],
                })

            # Related topics
            for topic in data.get("RelatedTopics", [])[:max_results]:
                if isinstance(topic, dict) and topic.get("Text"):
                    results.append({
                        "title": topic.get("Text", "")[:80],
                        "url": topic.get("FirstURL", ""),
                        "snippet": topic.get("Text", ""),
                    })

            if not results:
                # Fallback: try search suggestion
                results = [{"title": query, "url": f"https://duckduckgo.com/?q={query}", "snippet": "Search performed - no instant results available."}]

            return {
                "results": results[:max_results],
                "query": query,
                "total_results": len(results),
            }
    except Exception as e:
        return {"results": [], "query": query, "total_results": 0, "error": str(e)}


async def _tool_read_file(path: str, encoding: str = "utf-8", max_bytes: int = 1_048_576) -> Dict:
    """Read file contents."""
    try:
        p = Path(path).expanduser().resolve()
        if not p.exists():
            return {"error": f"File not found: {path}", "content": None}
        if not p.is_file():
            return {"error": f"Not a file: {path}", "content": None}
        size = p.stat().st_size
        content = p.read_text(encoding=encoding)[:max_bytes]
        return {
            "content": content,
            "path": str(p),
            "size_bytes": size,
            "encoding": encoding,
        }
    except Exception as e:
        return {"error": str(e), "content": None, "path": path}


async def _tool_write_file(path: str, content: str, mode: str = "write", encoding: str = "utf-8") -> Dict:
    """Write content to file."""
    try:
        p = Path(path).expanduser().resolve()
        p.parent.mkdir(parents=True, exist_ok=True)
        write_mode = "a" if mode == "append" else "w"
        p.write_text(content, encoding=encoding) if write_mode == "w" else open(p, "a", encoding=encoding).write(content)
        return {"success": True, "path": str(p), "bytes_written": len(content.encode(encoding))}
    except Exception as e:
        return {"success": False, "error": str(e), "path": path}


async def _tool_execute_shell(
    command: str,
    working_directory: str = "/tmp/mustafa_sandbox",
    timeout: int = 30,
    env_vars: Optional[Dict] = None,
) -> Dict:
    """Execute a shell command in sandbox."""
    settings = get_settings()
    if not settings.security.sandbox_enabled:
        return {"error": "Shell execution is disabled", "return_code": -1}

    # Basic command allowlist check
    BLOCKED_PATTERNS = ["rm -rf /", "mkfs", "dd if=/dev/zero", "> /dev/sd", "chmod 777 /"]
    for pattern in BLOCKED_PATTERNS:
        if pattern in command:
            return {"error": f"Blocked command pattern: {pattern}", "return_code": -1, "stdout": "", "stderr": ""}

    try:
        work_dir = Path(working_directory)
        work_dir.mkdir(parents=True, exist_ok=True)
        env = {**os.environ, **(env_vars or {})}
        start = time.monotonic()
        proc = await asyncio.create_subprocess_shell(
            command,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
            cwd=str(work_dir),
            env=env,
        )
        try:
            stdout, stderr = await asyncio.wait_for(proc.communicate(), timeout=timeout)
            elapsed = (time.monotonic() - start) * 1000
            return {
                "stdout": stdout.decode("utf-8", errors="replace"),
                "stderr": stderr.decode("utf-8", errors="replace"),
                "return_code": proc.returncode,
                "execution_time": round(elapsed / 1000, 3),
                "timed_out": False,
            }
        except asyncio.TimeoutError:
            proc.kill()
            return {"stdout": "", "stderr": "", "return_code": -1, "execution_time": timeout, "timed_out": True}
    except Exception as e:
        return {"stdout": "", "stderr": str(e), "return_code": -1, "execution_time": 0, "timed_out": False}


async def _tool_python_eval(code: str, timeout: int = 15, capture_output: bool = True) -> Dict:
    """Execute Python code in a restricted environment."""
    start = time.monotonic()
    try:
        # Write code to a temp file and execute it
        with tempfile.NamedTemporaryFile(mode="w", suffix=".py", delete=False, dir="/tmp") as f:
            f.write(code)
            tmp_path = f.name

        try:
            proc = await asyncio.create_subprocess_exec(
                sys.executable, tmp_path,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
            )
            stdout, stderr = await asyncio.wait_for(proc.communicate(), timeout=timeout)
            elapsed = (time.monotonic() - start) * 1000
            return {
                "stdout": stdout.decode("utf-8", errors="replace"),
                "stderr": stderr.decode("utf-8", errors="replace"),
                "result": None,
                "execution_time": round(elapsed / 1000, 3),
                "success": proc.returncode == 0,
                "error": stderr.decode() if proc.returncode != 0 else None,
            }
        except asyncio.TimeoutError:
            proc.kill()
            return {"stdout": "", "stderr": "Execution timed out", "result": None, "execution_time": timeout, "success": False, "error": "Timeout"}
        finally:
            os.unlink(tmp_path)
    except Exception as e:
        return {"stdout": "", "stderr": str(e), "result": None, "execution_time": 0, "success": False, "error": str(e)}


async def _tool_http_request(
    url: str,
    method: str = "GET",
    headers: Optional[Dict] = None,
    body: Optional[Dict] = None,
    params: Optional[Dict] = None,
    timeout: int = 30,
) -> Dict:
    """Make HTTP requests."""
    try:
        start = time.monotonic()
        async with httpx.AsyncClient(timeout=timeout, follow_redirects=True) as client:
            response = await client.request(
                method=method,
                url=url,
                headers=headers,
                json=body,
                params=params,
            )
            elapsed_ms = (time.monotonic() - start) * 1000
            return {
                "status_code": response.status_code,
                "headers": dict(response.headers),
                "body": response.text[:50000],  # Cap at 50KB
                "elapsed_ms": round(elapsed_ms, 1),
                "success": 200 <= response.status_code < 300,
            }
    except Exception as e:
        return {"status_code": 0, "headers": {}, "body": "", "elapsed_ms": 0, "success": False, "error": str(e)}


async def _tool_list_directory(path: str, recursive: bool = False, show_hidden: bool = False) -> Dict:
    """List directory contents."""
    try:
        p = Path(path).expanduser().resolve()
        if not p.exists():
            return {"error": f"Path not found: {path}", "entries": []}
        if not p.is_dir():
            return {"error": f"Not a directory: {path}", "entries": []}

        entries = []
        iterator = p.rglob("*") if recursive else p.iterdir()
        for entry in iterator:
            if not show_hidden and entry.name.startswith("."):
                continue
            stat = entry.stat()
            entries.append({
                "name": entry.name,
                "path": str(entry),
                "type": "directory" if entry.is_dir() else "file",
                "size_bytes": stat.st_size if entry.is_file() else 0,
                "modified": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime(stat.st_mtime)),
            })
        return {"path": str(p), "entries": entries, "total_entries": len(entries)}
    except Exception as e:
        return {"error": str(e), "entries": [], "path": path}


# Map of builtin tool names to their implementations
BUILTIN_TOOLS: Dict[str, Any] = {
    "web_search": _tool_web_search,
    "read_file": _tool_read_file,
    "write_file": _tool_write_file,
    "execute_shell": _tool_execute_shell,
    "python_eval": _tool_python_eval,
    "http_request": _tool_http_request,
    "list_directory": _tool_list_directory,
}


class ToolEngine:
    """
    Plugin-based tool execution engine.
    Loads tools from config, supports dynamic registration, validates inputs,
    enforces permissions, and records execution metrics.
    """

    def __init__(self):
        self._dynamic_tools: Dict[str, Any] = {}
        self._settings = get_settings()
        self._initialized = False

    async def initialize(self) -> None:
        """Initialize tool engine: register builtins from config."""
        db = await get_db()
        tools_cfg = self._settings.tools_config

        for tool_name, tool_cfg in tools_cfg.items():
            schema = tool_cfg.get("schema", {})
            await db.register_tool(
                name=tool_name,
                description=tool_cfg.get("description", ""),
                json_schema=schema,
                permissions=tool_cfg.get("permissions", []),
                category=tool_cfg.get("category", "builtin"),
                is_builtin=True,
            )

        self._initialized = True
        logger.info("Tool engine initialized", tool_count=len(tools_cfg))

    async def execute(
        self,
        tool_name: str,
        params: Dict[str, Any],
        task_id: Optional[str] = None,
        agent_name: str = "system",
    ) -> ToolResult:
        """
        Execute a tool by name with given parameters.
        Validates input, checks permissions, runs tool, records metrics.
        """
        start = time.monotonic()

        try:
            # Get tool definition
            tool_def = await self._get_tool_def(tool_name)
            if not tool_def:
                raise ToolNotFoundError(f"Tool '{tool_name}' not found")

            # Validate input against JSON schema
            schema = tool_def.get("json_schema", {})
            input_schema = schema.get("input", schema)
            if input_schema:
                try:
                    jsonschema.validate(instance=params, schema=input_schema)
                except jsonschema.ValidationError as e:
                    raise ToolValidationError(f"Input validation failed: {e.message}")

            # Execute tool
            output = await self._dispatch(tool_name, params, tool_def)
            duration_ms = (time.monotonic() - start) * 1000

            # Record execution
            db = await get_db()
            await db.record_metric(f"tool.{tool_name}.latency_ms", duration_ms)
            await db.record_metric(f"tool.{tool_name}.success", 1.0)

            logger.info(
                "Tool executed",
                tool=tool_name,
                duration_ms=round(duration_ms, 1),
                agent=agent_name,
            )

            return ToolResult(
                tool_name=tool_name,
                success=True,
                output=output,
                duration_ms=duration_ms,
            )

        except (ToolNotFoundError, ToolValidationError, ToolPermissionError) as e:
            duration_ms = (time.monotonic() - start) * 1000
            logger.warning("Tool execution blocked", tool=tool_name, error=str(e))
            return ToolResult(tool_name=tool_name, success=False, error=str(e), duration_ms=duration_ms)
        except Exception as e:
            duration_ms = (time.monotonic() - start) * 1000
            logger.error("Tool execution failed", tool=tool_name, error=str(e))
            db = await get_db()
            await db.record_metric(f"tool.{tool_name}.error", 1.0)
            return ToolResult(
                tool_name=tool_name,
                success=False,
                error=str(e),
                duration_ms=duration_ms,
            )

    async def _get_tool_def(self, tool_name: str) -> Optional[Dict]:
        """Get tool definition from DB or dynamic registry."""
        db = await get_db()
        return await db.get_tool(tool_name)

    async def _dispatch(self, tool_name: str, params: Dict, tool_def: Dict) -> Any:
        """Dispatch tool execution to builtin or dynamic implementation."""
        # Check built-in tools
        if tool_name in BUILTIN_TOOLS:
            fn = BUILTIN_TOOLS[tool_name]
            return await fn(**params)

        # Check dynamic tools (created at runtime)
        if tool_name in self._dynamic_tools:
            fn = self._dynamic_tools[tool_name]
            return await fn(**params)

        # Try to execute code stored in DB
        tool_def_from_db = await (await get_db()).get_tool(tool_name)
        if tool_def_from_db and tool_def_from_db.get("code"):
            return await self._execute_dynamic_code(
                tool_name, tool_def_from_db["code"], params
            )

        raise ToolNotFoundError(f"No implementation found for tool: {tool_name}")

    async def _execute_dynamic_code(self, tool_name: str, code: str, params: Dict) -> Any:
        """Execute dynamically created tool code."""
        namespace: Dict = {}
        exec(compile(code, f"<tool:{tool_name}>", "exec"), namespace)

        # Find the main function
        fn = namespace.get("execute") or namespace.get(tool_name) or namespace.get("run")
        if not fn:
            raise ToolNotFoundError(f"Dynamic tool '{tool_name}' has no execute/run function")

        if asyncio.iscoroutinefunction(fn):
            return await fn(**params)
        else:
            return fn(**params)

    async def register_dynamic_tool(
        self,
        tool_name: str,
        description: str,
        code: str,
        json_schema: Dict,
        permissions: Optional[List[str]] = None,
        dependencies: Optional[List[str]] = None,
    ) -> bool:
        """Register a new tool created at runtime."""
        try:
            # Install dependencies if needed
            if dependencies:
                for dep in dependencies:
                    logger.info(f"Installing dependency: {dep}")
                    proc = await asyncio.create_subprocess_exec(
                        sys.executable, "-m", "pip", "install", dep, "-q",
                        stdout=asyncio.subprocess.PIPE,
                        stderr=asyncio.subprocess.PIPE,
                    )
                    await proc.communicate()

            # Validate code compiles
            compile(code, f"<tool:{tool_name}>", "exec")

            # Register in database
            db = await get_db()
            await db.register_tool(
                name=tool_name,
                description=description,
                json_schema=json_schema,
                code=code,
                permissions=permissions or [],
                category="custom",
                is_builtin=False,
            )

            logger.info("Dynamic tool registered", tool=tool_name)
            return True
        except SyntaxError as e:
            logger.error("Tool code has syntax error", tool=tool_name, error=str(e))
            return False
        except Exception as e:
            logger.error("Tool registration failed", tool=tool_name, error=str(e))
            return False

    async def list_all_tools(self) -> List[Dict]:
        """Get all registered tools with their schemas."""
        db = await get_db()
        return await db.list_tools()

    async def get_tools_manifest(self) -> str:
        """Get a compact manifest of all tools for agent context."""
        tools = await self.list_all_tools()
        manifest = []
        for t in tools:
            schema = t.get("json_schema", {})
            input_schema = schema.get("input", schema)
            manifest.append({
                "name": t["name"],
                "description": t["description"],
                "category": t.get("category", "unknown"),
                "input_schema": input_schema,
                "permissions": t.get("permissions", []),
            })
        return json.dumps(manifest, indent=2)


# Singleton
_tool_engine: Optional[ToolEngine] = None


def get_tool_engine() -> ToolEngine:
    """Get the global tool engine instance."""
    global _tool_engine
    if _tool_engine is None:
        _tool_engine = ToolEngine()
    return _tool_engine
