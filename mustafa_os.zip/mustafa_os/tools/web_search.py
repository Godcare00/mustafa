"""
MUSTAFA OS - Web Search Tool

Primary:  SerpAPI  — real Google results, reliable, requires SERPAPI_KEY in .env
Fallback: ddgs     — free DuckDuckGo search, no key needed, auto-installs

If SERPAPI_KEY is set in .env → uses SerpAPI.
If not → falls back to ddgs automatically.
"""

from __future__ import annotations

import asyncio
import sys
from typing import Any, Dict, List, Optional

from tools.base import BaseTool, ToolResult
from core.logging_config import get_logger

logger = get_logger("web_search_tool")

_ddgs_ready: Optional[bool] = None


# ─── SerpAPI ──────────────────────────────────────────────────────────────────

async def _search_serpapi(query: str, max_results: int, api_key: str) -> List[Dict[str, str]]:
    """Execute a search via SerpAPI and return normalised results."""
    import urllib.parse
    import urllib.request
    import json

    params = urllib.parse.urlencode({
        "q":       query,
        "num":     max_results,
        "api_key": api_key,
        "engine":  "google",
    })
    url = f"https://serpapi.com/search.json?{params}"

    def _fetch():
        with urllib.request.urlopen(url, timeout=30) as resp:
            return json.loads(resp.read().decode())

    data = await asyncio.get_event_loop().run_in_executor(None, _fetch)

    results = []

    # Organic results
    for r in data.get("organic_results", [])[:max_results]:
        results.append({
            "title":   r.get("title", ""),
            "url":     r.get("link", ""),
            "snippet": r.get("snippet", ""),
        })

    # Answer box (featured snippet) — prepend as first result
    answer_box = data.get("answer_box", {})
    if answer_box:
        snippet = (
            answer_box.get("answer") or
            answer_box.get("snippet") or
            answer_box.get("result") or ""
        )
        if snippet:
            results.insert(0, {
                "title":   answer_box.get("title", "Featured Answer"),
                "url":     answer_box.get("link", ""),
                "snippet": snippet,
            })

    return results[:max_results]


# ─── ddgs fallback ────────────────────────────────────────────────────────────

async def _ensure_ddgs() -> bool:
    global _ddgs_ready
    if _ddgs_ready is True:
        return True
    if _ddgs_ready is False:
        return False

    for pkg in ["ddgs", "duckduckgo_search"]:
        try:
            __import__(pkg)
            _ddgs_ready = True
            return True
        except ImportError:
            pass

    logger.info("ddgs_installing", message="Installing ddgs (SerpAPI key not set)...")
    try:
        proc = await asyncio.create_subprocess_exec(
            sys.executable, "-m", "pip", "install", "ddgs",
            "--quiet", "--no-warn-script-location",
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
        _, stderr = await asyncio.wait_for(proc.communicate(), timeout=120)
        if proc.returncode == 0:
            import importlib; importlib.invalidate_caches()
            try:
                import ddgs  # noqa: F401
                _ddgs_ready = True
                logger.info("ddgs_installed_successfully")
                return True
            except ImportError:
                pass
        else:
            logger.warning("ddgs_install_failed", stderr=stderr.decode()[:200])
    except Exception as e:
        logger.warning("ddgs_install_error", error=str(e))

    _ddgs_ready = False
    return False


async def _search_ddgs(query: str, max_results: int) -> List[Dict[str, str]]:
    """Execute a search via ddgs and return normalised results."""
    try:
        from ddgs import DDGS
    except ImportError:
        from duckduckgo_search import DDGS

    def _fetch():
        with DDGS() as ddgs:
            return list(ddgs.text(query, max_results=max_results))

    raw = await asyncio.get_event_loop().run_in_executor(None, _fetch)
    return [
        {
            "title":   r.get("title", ""),
            "url":     r.get("href", ""),
            "snippet": r.get("body", ""),
        }
        for r in (raw or [])
    ]


# ─── Tool ─────────────────────────────────────────────────────────────────────

class WebSearchTool(BaseTool):
    """
    Web search tool.
    Uses SerpAPI (real Google results) when SERPAPI_KEY is configured,
    falls back to DuckDuckGo (ddgs) automatically when it is not.
    """

    name = "web_search"
    description = (
        "Search the web for real, current information. "
        "Uses SerpAPI (Google) if SERPAPI_KEY is set, otherwise DuckDuckGo."
    )
    permissions = ["network.read"]
    timeout = 60
    params_schema = {
        "query":       "str — search query (required)",
        "max_results": "int — number of results to return, default 5 (optional)",
    }

    async def execute(self, params: Dict[str, Any]) -> ToolResult:
        query       = params.get("query", "").strip()
        max_results = min(int(params.get("max_results", 5)), 10)

        if not query:
            return ToolResult(success=False, error="query parameter required")

        try:
            from core.settings import settings
            api_key = getattr(settings, "serpapi_key", "").strip()
        except Exception:
            api_key = ""

        # ── SerpAPI path ──────────────────────────────────────────────────
        if api_key:
            try:
                results = await asyncio.wait_for(
                    _search_serpapi(query, max_results, api_key),
                    timeout=30,
                )
                logger.info("web_search_complete",
                            engine="serpapi", query=query[:60], results=len(results))
                return ToolResult(success=True, data={
                    "results": results,
                    "query":   query,
                    "engine":  "serpapi",
                })
            except Exception as e:
                logger.warning("serpapi_failed", error=str(e),
                               message="Falling back to ddgs")
                # Fall through to ddgs

        # ── ddgs fallback ─────────────────────────────────────────────────
        available = await _ensure_ddgs()
        if not available:
            return ToolResult(
                success=False,
                error=(
                    "Web search unavailable. "
                    "Set SERPAPI_KEY in .env for reliable search, "
                    "or run: pip install ddgs"
                ),
            )

        try:
            results = await asyncio.wait_for(
                _search_ddgs(query, max_results),
                timeout=30,
            )
            logger.info("web_search_complete",
                        engine="ddgs", query=query[:60], results=len(results))
            return ToolResult(success=True, data={
                "results": results,
                "query":   query,
                "engine":  "ddgs",
            })
        except Exception as e:
            logger.error("web_search_failed", error=str(e))
            return ToolResult(success=False, error=f"Search failed: {e}")

    async def validate_params(self, params: Dict[str, Any]) -> Optional[str]:
        if not params.get("query", "").strip():
            return "query is required"
        return None
