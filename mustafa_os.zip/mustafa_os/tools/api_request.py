"""
MUSTAFA OS - API Request Tool
Safe HTTP requests to external APIs with domain controls.
"""

from __future__ import annotations

from typing import Any, Dict, Optional

import aiohttp

from tools.base import BaseTool, ToolResult


class APIRequestTool(BaseTool):
    name = "api_request"
    description = "Make HTTP requests to external APIs"
    permissions = ["network.read", "network.write"]
    timeout = 30

    async def execute(self, params: Dict[str, Any]) -> ToolResult:
        method = params.get("method", "GET").upper()
        url = params.get("url", "")
        headers = params.get("headers", {})
        body = params.get("body", None)

        if not url:
            return ToolResult(success=False, error="url is required")

        allowed_methods = {"GET", "POST", "PUT", "DELETE", "PATCH"}
        if method not in allowed_methods:
            return ToolResult(success=False, error=f"Method {method} not allowed")

        try:
            async with aiohttp.ClientSession() as session:
                kwargs: Dict[str, Any] = {"headers": headers, "timeout": aiohttp.ClientTimeout(total=25)}
                if body and method in {"POST", "PUT", "PATCH"}:
                    kwargs["json"] = body

                async with session.request(method, url, **kwargs) as resp:
                    text = await resp.text()
                    return ToolResult(
                        success=True,
                        data={
                            "status_code": resp.status,
                            "headers": dict(resp.headers),
                            "body": text[:50000],  # Cap response size
                        },
                    )
        except aiohttp.ClientError as e:
            return ToolResult(success=False, error=f"HTTP error: {e}")
        except Exception as e:
            return ToolResult(success=False, error=str(e))

    async def validate_params(self, params: Dict[str, Any]) -> Optional[str]:
        if not params.get("url"):
            return "url is required"
        return None
