# MUSTAFA OS
## Modular Unified System for Task Automation and Autonomous Intelligence

```
╔═══════════════════════════════════════════════════════════╗
║              MUSTAFA OS  v1.0.0                           ║
║   Production-Grade Autonomous Multi-Agent OS             ║
╚═══════════════════════════════════════════════════════════╝
```

---

## What is MUSTAFA OS?

MUSTAFA OS is a **production-ready autonomous multi-agent operating system** that coordinates 10 specialized AI agents to execute complex goals autonomously. It handles everything from web research to code generation, self-improvement, and real-time system monitoring.

---

## Architecture

```
MUSTAFA OS
│
├── Agent Kernel          ← System bootstrap & lifecycle
├── Orchestrator Agent    ← Central command & control
├── Planner Agent         ← Structured execution plans
├── Research Agent        ← Web search & knowledge extraction
├── Developer Agent       ← Code generation & modification
├── Testing Agent         ← Unit tests & code verification
├── Critic Agent          ← Quality evaluation & scoring
├── Memory Agent          ← Short/long-term memory management
├── Tool Manager Agent    ← Plugin registration & permissions
├── Monitoring Agent      ← Health, metrics & alerts
├── Evolution Agent       ← Self-improvement experiments
│
├── FastAPI REST Server   ← Production API (port 8000)
├── Telegram Bot          ← Mobile interface (authorized users only)
├── CLI Interface         ← Rich terminal with history
├── Redis Message Bus     ← Async agent communication
├── PostgreSQL            ← Persistent task & metrics storage
├── ChromaDB              ← Vector memory (semantic search)
└── Celery                ← Background task queue
```

---

## Quick Start

### 1. Prerequisites
- Python 3.10+
- Redis
- PostgreSQL (optional but recommended)

### 2. Automated Setup
```bash
cd mustafa_os
chmod +x setup.sh
./setup.sh
```
The script will:
- Install all Python dependencies
- Set up Redis
- Configure PostgreSQL (if available)
- Prompt for your API keys
- Run health checks
- Execute unit tests

### 3. Configure
Edit `.env` with your keys:
```env
OPENROUTER_API_KEY=your_key_here
TELEGRAM_BOT_TOKEN=your_bot_token      # Optional
TELEGRAM_AUTHORIZED_USERS=123456789    # Your Telegram user ID
```

### 4. Run

```bash
# Interactive CLI chat
python main.py chat

# Full system (API + agents + Telegram bot)
python main.py

# API server only
python main.py server

# Execute a single goal and exit
python main.py run "Research the latest AI breakthroughs"
```

---

## Core Agents

| Agent | Role | Key Capabilities |
|-------|------|-----------------|
| **Orchestrator** | Central command | Goal parsing, task assignment, conflict resolution |
| **Planner** | Strategy | Breaks goals into executable steps with dependencies |
| **Research** | Intelligence | Web search, doc analysis, knowledge extraction |
| **Developer** | Engineering | Code generation, module modification, tool creation |
| **Testing** | Quality | Unit tests, code verification, coverage reports |
| **Critic** | Evaluation | Quality scoring, logic verification, security review |
| **Memory** | Persistence | Vector storage, semantic search, context management |
| **Tool Manager** | Plugins | Dynamic tool loading, permission enforcement |
| **Monitoring** | Observability | Health checks, metrics, alerting |
| **Evolution** | Self-improvement | A/B experiments, auto-deployment of improvements |

---

## API Reference

| Method | Endpoint | Description |
|--------|----------|-------------|
| `GET` | `/health` | System health status |
| `GET` | `/metrics` | Prometheus-style metrics |
| `GET` | `/agents` | All agent statuses |
| `GET` | `/tools` | Registered tool list |
| `GET` | `/tasks` | Recent task history |
| `POST` | `/goals` | Submit a new goal |
| `GET` | `/tasks/{id}` | Poll task status |
| `POST` | `/tools/execute` | Execute a tool directly |
| `POST` | `/memory/search` | Semantic memory search |
| `POST` | `/evolve` | Trigger evolution cycle |
| `WS` | `/ws` | WebSocket streaming |

---

## CLI Commands

```
/help           Show help
/status         System status dashboard
/agents         All agents with live status
/tools          Registered tools & usage stats
/tasks          Recent task history
/history        Conversation history
/clear          Clear screen
/evolve         Trigger self-improvement cycle
/search <q>     Search vector memory
/agent <id> <msg>  Send message to specific agent
/quit           Exit
```

---

## Tools (Plugins)

| Tool | Permissions | Description |
|------|-------------|-------------|
| `web_search` | network.read | DuckDuckGo web search |
| `file_manager` | filesystem.r/w | Safe file operations in ./data |
| `api_request` | network.r/w | HTTP requests to external APIs |
| `database_query` | database.read | Read-only SQL queries |
| `data_analysis` | compute | Stats, aggregation, correlation |
| `code_executor` | compute, sandbox | Sandboxed Python execution |
| `memory_search` | memory.read | Semantic vector search |
| `system_metrics` | monitoring.read | Live system metrics |

### Creating Custom Tools

Drop a Python file in `./plugins/`:

```python
from tools.base import BaseTool, ToolResult

class MyCustomTool(BaseTool):
    name = "my_tool"
    description = "Does something useful"
    permissions = ["network.read"]
    timeout = 30

    async def execute(self, params: dict) -> ToolResult:
        # Your implementation
        result = do_something(params.get("input"))
        return ToolResult(success=True, data={"output": result})
```

MUSTAFA OS auto-loads it on next start. You can also ask it to create tools for you:
```
> Create a new tool that fetches cryptocurrency prices from CoinGecko
```

---

## Memory System

```
┌─────────────────────────────────────────┐
│         MUSTAFA OS Memory               │
├─────────────────────────────────────────┤
│  Short-Term (Redis)                     │
│  • Conversation context (1hr TTL)       │
│  • Active task state                    │
│  • Agent scratchpads                    │
├─────────────────────────────────────────┤
│  Long-Term (ChromaDB Vector DB)         │
│  • Task history & outcomes              │
│  • Research findings                    │
│  • Agent knowledge base                 │
│  • Semantic search enabled              │
├─────────────────────────────────────────┤
│  Experiment Memory                      │
│  • Self-improvement results             │
│  • A/B test records                     │
│  • Deployed improvements                │
└─────────────────────────────────────────┘
```

---

## Self-Improvement Engine

MUSTAFA OS continuously improves itself:

```
Every 24 hours (or on /evolve command):
  1. Observe   → Collect performance metrics from all agents
  2. Identify  → Find weaknesses using LLM analysis
  3. Hypothesize → "If we change X, Y will improve by Z%"
  4. Implement → Developer Agent writes the improvement
  5. Test      → Testing Agent validates it
  6. Evaluate  → Compare metrics (requires 15% improvement)
  7. Deploy    → Auto-deploy if threshold met, else rollback
  8. Log       → Store experiment in memory for learning
```

---

## Reliability Features

- **Retry with exponential backoff** — All LLM calls, Redis ops, DB queries
- **Circuit breakers** — Prevent cascade failures across agents
- **Timeout management** — Every operation has enforced time limits
- **Graceful degradation** — System keeps running if Redis/DB temporarily unavailable
- **Health checks** — `/health` endpoint for load balancer integration
- **Structured JSON logging** — Machine-readable logs for log aggregators
- **Dead letter queue** — Failed messages preserved for debugging

---

## Security

- **Code sandbox** — Generated code runs in RestrictedPython with no filesystem/network access
- **Tool permissions** — Each agent has explicit tool allowlist
- **Path traversal protection** — File manager restricted to `./data` directory
- **API key isolation** — Keys in `.env`, never passed between agents (except orchestrator)
- **Telegram auth** — Bot only responds to pre-authorized user IDs
- **SQL injection protection** — Read-only DB access with parameterized queries

---

## Directory Structure

```
mustafa_os/
├── main.py                 ← Entry point
├── setup.sh                ← Automated setup script
├── requirements.txt        ← Python dependencies
├── .env.example            ← Environment template
├── pytest.ini              ← Test configuration
│
├── core/                   ← System foundation
│   ├── kernel.py           ← Boot & lifecycle management
│   ├── settings.py         ← Centralized configuration
│   ├── database.py         ← Async PostgreSQL (SQLAlchemy)
│   ├── messaging.py        ← Redis pub/sub message bus
│   ├── llm_client.py       ← OpenRouter LLM client
│   ├── registry.py         ← Agent registry
│   └── reliability.py      ← Retry, circuit breaker, timeout
│
├── agents/                 ← All agent implementations
│   ├── base.py             ← Abstract base agent class
│   ├── orchestrator.py     ← Orchestrator agent
│   ├── specialized.py      ← Planner, Research, Developer, Testing, Critic
│   └── system_agents.py    ← Memory, ToolManager, Monitoring, Evolution
│
├── tools/                  ← Built-in tool plugins
│   ├── base.py             ← Tool engine + BaseTool class
│   ├── web_search.py       ← DuckDuckGo search
│   ├── file_manager.py     ← Safe file I/O
│   ├── api_request.py      ← HTTP requests
│   ├── database_query.py   ← Read-only SQL
│   ├── data_analysis.py    ← Statistics & transforms
│   ├── code_executor.py    ← Sandboxed code execution
│   ├── memory_search.py    ← Vector memory search
│   └── system_metrics.py   ← Live system metrics
│
├── memory/                 ← Memory layer
│   ├── long_term.py        ← ChromaDB vector store
│   └── short_term.py       ← Redis context memory
│
├── api/                    ← FastAPI REST server
│   └── app.py              ← All routes + WebSocket
│
├── cli/                    ← Terminal interface
│   └── interface.py        ← Rich CLI with history
│
├── telegram_bot/           ← Telegram bot
│   └── bot.py              ← Authorized-user-only bot
│
├── orchestration/          ← Task queue
│   ├── celery_app.py       ← Celery configuration
│   └── tasks.py            ← Background tasks
│
├── monitoring/             ← Observability
│   └── metrics.py          ← Prometheus metrics
│
├── config/                 ← YAML configuration
│   ├── system.yaml         ← System settings
│   ├── agents.yaml         ← Agent configs & prompts
│   ├── tools.yaml          ← Tool definitions
│   └── models.yaml         ← LLM model config
│
├── tests/                  ← Test suite
│   └── test_core.py        ← Unit tests (40+ tests)
│
├── plugins/                ← Custom tool plugins (auto-loaded)
├── data/                   ← Persistent data
├── logs/                   ← Log files
└── docs/                   ← Documentation & examples
    └── examples.py         ← Usage examples
```

---

## Environment Variables

| Variable | Required | Description |
|----------|----------|-------------|
| `OPENROUTER_API_KEY` | **Yes** | LLM provider key from openrouter.ai |
| `TELEGRAM_BOT_TOKEN` | No | Telegram bot token from @BotFather |
| `TELEGRAM_AUTHORIZED_USERS` | No | Comma-separated Telegram user IDs |
| `DATABASE_URL` | No | PostgreSQL connection string |
| `REDIS_URL` | No | Redis connection URL |
| `API_SECRET_KEY` | Yes | Random secret for API security |
| `LOG_LEVEL` | No | INFO/DEBUG/WARNING (default: INFO) |

---

## Telegram Bot Setup

1. Message [@BotFather](https://t.me/botfather) on Telegram
2. Create a new bot: `/newbot`
3. Copy the token to `TELEGRAM_BOT_TOKEN` in `.env`
4. Get your Telegram user ID from [@userinfobot](https://t.me/userinfobot)
5. Add to `TELEGRAM_AUTHORIZED_USERS=your_user_id`
6. Start the system: `python main.py`
7. Message your bot on Telegram!

---

## License

MIT License — Build freely, deploy boldly.

---

*Built with Python, FastAPI, Redis, PostgreSQL, ChromaDB, and OpenRouter.*
*MUSTAFA OS — Autonomous intelligence, production-ready.*
