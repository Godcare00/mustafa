"""
MUSTAFA OS - Agent Kernel
Central system bootstrap, lifecycle management, and health orchestration.
"""

from __future__ import annotations

import asyncio
import signal
from datetime import datetime
from typing import Dict, List, Optional

from core.database import close_db, init_db
from core.llm_client import llm_client
from core.logging_config import configure_logging, get_logger
from core.messaging import message_bus
from core.registry import agent_registry
from core.settings import settings

logger = get_logger("kernel")


class AgentKernel:
    """
    The MUSTAFA OS kernel — responsible for:
    - System bootstrap and initialization
    - Agent lifecycle (start/stop all agents)
    - Graceful shutdown handling
    - Health monitoring
    - Service dependency management
    """

    def __init__(self) -> None:
        self._agents: Dict[str, object] = {}
        self._running = False
        self._start_time: Optional[datetime] = None

    async def boot(self) -> None:
        """Full system boot sequence."""
        configure_logging(settings.log_level, settings.log_format)
        logger.info("kernel_booting", version=settings.system_version, env=settings.environment)

        # Create necessary directories
        self._create_dirs()

        # Initialize services
        await self._init_database()
        await self._init_message_bus()
        await self._init_llm_client()

        # Start all agents
        await self._start_all_agents()

        self._running = True
        self._start_time = datetime.utcnow()

        # Setup signal handlers
        self._setup_signals()

        logger.info(
            "kernel_ready",
            agents_started=len(self._agents),
            uptime_started=self._start_time.isoformat(),
        )

    async def shutdown(self) -> None:
        """Graceful system shutdown."""
        if not self._running:
            return

        logger.info("kernel_shutting_down")
        self._running = False

        # Stop all agents
        await self._stop_all_agents()

        # Disconnect services
        await message_bus.disconnect()
        await llm_client.disconnect()
        await close_db()

        logger.info("kernel_shutdown_complete")

    def _create_dirs(self) -> None:
        """Create required directories."""
        import os
        dirs = [
            settings.data_dir,
            settings.logs_dir,
            settings.experiments_dir,
            settings.plugins_dir,
            f"{settings.data_dir}/generated",
            f"{settings.data_dir}/chroma",
        ]
        for d in dirs:
            os.makedirs(d, exist_ok=True)

    async def _init_database(self) -> None:
        """Initialize SQLite database and tables."""
        try:
            await init_db()
            logger.info("database_ready")
        except Exception as e:
            logger.error("database_init_failed", error=str(e))
            logger.warning("continuing_without_database")

    async def _init_message_bus(self) -> None:
        """Connect to Redis message bus."""
        try:
            await message_bus.connect()
            logger.info("message_bus_ready")
        except Exception as e:
            logger.error("message_bus_init_failed", error=str(e))
            raise RuntimeError(f"Redis connection failed: {e}. Ensure Redis is running.")

    async def _init_llm_client(self) -> None:
        """Initialize LLM client."""
        try:
            await llm_client.connect()
            if settings.openrouter_api_key and settings.openrouter_api_key != "your_openrouter_api_key_here":
                healthy = await llm_client.health_check()
                if healthy:
                    logger.info("llm_client_ready")
                else:
                    logger.warning("llm_client_health_check_failed")
            else:
                logger.warning("no_api_key_configured", message="Set OPENROUTER_API_KEY in .env")
        except Exception as e:
            logger.error("llm_client_init_failed", error=str(e))

    async def _start_all_agents(self) -> None:
        """Instantiate and start all agents concurrently."""
        from agents.orchestrator import OrchestratorAgent
        from agents.specialized import (
            PlannerAgent,
            ResearchAgent,
            DeveloperAgent,
            TestingAgent,
            CriticAgent,
        )
        from agents.system_agents import (
            MemoryAgent,
            ToolManagerAgent,
            MonitoringAgent,
            EvolutionAgent,
        )

        agent_classes = [
            OrchestratorAgent,
            PlannerAgent,
            ResearchAgent,
            DeveloperAgent,
            TestingAgent,
            CriticAgent,
            MemoryAgent,
            ToolManagerAgent,
            MonitoringAgent,
            EvolutionAgent,
        ]

        # Instantiate agents
        for cls in agent_classes:
            instance = cls()
            self._agents[instance.agent_id] = instance

        # Start them concurrently
        start_tasks = [agent.start() for agent in self._agents.values()]
        results = await asyncio.gather(*start_tasks, return_exceptions=True)

        for agent_id, result in zip(self._agents.keys(), results):
            if isinstance(result, Exception):
                logger.error("agent_start_failed", agent_id=agent_id, error=str(result))
            else:
                logger.info("agent_started_ok", agent_id=agent_id)

        # Set tool permissions for agents
        self._configure_tool_permissions()

    def _configure_tool_permissions(self) -> None:
        """Configure tool permissions per agent from YAML config."""
        from tools import get_tool_engine
        from core.settings import get_agents_config

        engine = get_tool_engine()
        agents_config = get_agents_config().get("agents", {})

        for agent_id, config in agents_config.items():
            allowed = config.get("allowed_tools", [])
            if not allowed:
                # Check if agent has full access
                if config.get("has_full_system_access"):
                    allowed = ["*"]
                else:
                    allowed = ["web_search", "file_manager"]  # Safe defaults

            engine.set_agent_permissions(agent_id, allowed)

        # Orchestrator gets all tools
        engine.set_agent_permissions("orchestrator", ["*"])

    async def _stop_all_agents(self) -> None:
        """Stop all agents gracefully."""
        stop_tasks = []
        for agent in self._agents.values():
            if hasattr(agent, "stop"):
                stop_tasks.append(agent.stop())

        if stop_tasks:
            await asyncio.gather(*stop_tasks, return_exceptions=True)
        logger.info("all_agents_stopped", count=len(stop_tasks))

    def _setup_signals(self) -> None:
        """Register OS signal handlers for graceful shutdown."""
        loop = asyncio.get_event_loop()

        def _handle_signal():
            logger.info("shutdown_signal_received")
            asyncio.create_task(self.shutdown())

        for sig in (signal.SIGTERM, signal.SIGINT):
            try:
                loop.add_signal_handler(sig, _handle_signal)
            except NotImplementedError:
                # Windows doesn't support add_signal_handler
                pass

    def get_agent(self, agent_id: str) -> Optional[object]:
        """Get a running agent instance."""
        return self._agents.get(agent_id)

    def get_orchestrator(self):
        """Get the Orchestrator agent for direct task submission."""
        return self._agents.get("orchestrator")

    @property
    def is_running(self) -> bool:
        return self._running

    @property
    def uptime_seconds(self) -> float:
        if not self._start_time:
            return 0.0
        return (datetime.utcnow() - self._start_time).total_seconds()

    def get_status(self) -> dict:
        return {
            "running": self._running,
            "version": settings.system_version,
            "environment": settings.environment,
            "uptime_seconds": self.uptime_seconds,
            "agents_loaded": list(self._agents.keys()),
            "agent_count": len(self._agents),
            "registry_summary": agent_registry.get_system_summary(),
        }


# Global kernel singleton
kernel = AgentKernel()
