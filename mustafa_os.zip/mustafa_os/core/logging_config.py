"""
MUSTAFA OS - Logging Configuration

Uses structlog's official stdlib bridge for reliable dual-channel output:
  Console  — essential events only, clean coloured single lines
  File     — everything (JSON, rotating 5 MB × 5 files, ~25 MB total max)

console_mode flags:
  "essential"  (default) — boot, goals, actions, errors/warnings
  "verbose"    --logs    — everything on console too
  "silent"     --no-logs — nothing on console, file only
"""

from __future__ import annotations

import logging
import logging.handlers
import os
import sys
from typing import Any

import structlog

# ─── Events shown on the console in "essential" mode ─────────────────────────

CONSOLE_EVENTS = frozenset({
    "kernel_booting", "kernel_ready", "memory_ready",
    "database_ready", "message_bus_ready", "llm_client_ready",
    "agent_started_ok",
    "executing_goal", "goal_completed", "goal_failed",
    "orchestrator_action", "orchestrator_tool_call", "orchestrator_agent_call",
    "system_context_built",
    "shell_executing", "shell_executed",
    "web_search_complete", "ddgs_installing", "ddgs_installed_successfully",
    "tool_hot_loaded", "tool_registered",
    "telegram_file_received", "telegram_attachment_sent",
    "evaluation_complete",
})

ALWAYS_SHOW_LEVELS = frozenset({"warning", "error", "critical"})

ICONS = {
    "kernel_booting":              "🚀",
    "kernel_ready":                "✅",
    "memory_ready":                "🧠",
    "database_ready":              "🗄",
    "message_bus_ready":           "📡",
    "llm_client_ready":            "🤖",
    "agent_started_ok":            "✓ ",
    "executing_goal":              "▶ ",
    "goal_completed":              "✅",
    "goal_failed":                 "❌",
    "orchestrator_action":         "⚙ ",
    "orchestrator_tool_call":      "🔧",
    "orchestrator_agent_call":     "📤",
    "system_context_built":        "📊",
    "shell_executing":             "💻",
    "shell_executed":              "💻",
    "web_search_complete":         "🔍",
    "ddgs_installing":             "📦",
    "ddgs_installed_successfully": "📦",
    "tool_hot_loaded":             "🔌",
    "tool_registered":             "🔌",
    "telegram_file_received":      "📥",
    "telegram_attachment_sent":    "📎",
    "evaluation_complete":         "🎯",
}

LEVEL_COLOUR = {
    "debug":    "\033[90m",
    "info":     "",
    "warning":  "\033[33m",
    "error":    "\033[31m",
    "critical": "\033[1;31m",
}
RESET = "\033[0m"

PRIORITY_KEYS = (
    "goal", "agent_id", "agent", "tool", "action", "thought",
    "agents", "tools", "actions", "error", "command",
    "query", "results", "filename", "path", "score", "verdict", "task_id",
)


# ─── Custom processors ────────────────────────────────────────────────────────

def _console_filter(logger, method: str, event_dict: dict) -> dict:
    """Drop events that don't belong on the console (essential mode only)."""
    event = event_dict.get("event", "")
    level = event_dict.get("level", method or "").lower()
    if level in ALWAYS_SHOW_LEVELS or event in CONSOLE_EVENTS:
        return event_dict
    raise structlog.DropEvent()


def _console_renderer(logger, method: str, event_dict: dict) -> str:
    """Render a compact, coloured single-line entry for the console."""
    event  = event_dict.get("event", "")
    level  = event_dict.get("level", method or "info").lower()
    ts     = str(event_dict.get("timestamp", ""))[:19].replace("T", " ")
    icon   = ICONS.get(event, "  ")
    colour = LEVEL_COLOUR.get(level, "")

    parts = []
    for key in PRIORITY_KEYS:
        val = event_dict.get(key)
        if val is None:
            continue
        v = str(val)
        if key == "task_id":
            v = v[:8] + "…"
        elif len(v) > 72:
            v = v[:69] + "…"
        parts.append(f"{key}={v}")

    detail = "  " + "  ".join(parts) if parts else ""
    return f"{colour}{ts}  {icon} {event}{detail}{RESET}"


def _file_json_renderer(logger, method: str, event_dict: dict) -> str:
    """Render every event as a JSON line for the log file."""
    import json
    return json.dumps(event_dict, default=str, ensure_ascii=False)


# ─── Main configure function ──────────────────────────────────────────────────

def configure_logging(
    log_level: str = "INFO",
    log_format: str = "json",
    console_mode: str = "essential",
) -> None:
    """
    Set up dual-channel logging via structlog's stdlib bridge.

    console_mode:
      "essential"  — only key events on console (file gets everything)
      "verbose"    — all events on console AND file
      "silent"     — nothing on console; file gets everything
    """
    os.makedirs("./logs", exist_ok=True)
    numeric_level = getattr(logging, log_level.upper(), logging.INFO)

    # ── Shared pre-chain: common processors run before handler-specific ones ─
    pre_chain = [
        structlog.stdlib.add_log_level,
        structlog.stdlib.add_logger_name,
        structlog.contextvars.merge_contextvars,
        structlog.processors.TimeStamper(fmt="iso"),
        structlog.processors.StackInfoRenderer(),
        structlog.processors.format_exc_info,
    ]

    # ── Configure structlog to emit through stdlib logging ───────────────────
    structlog.configure(
        processors=pre_chain + [
            structlog.stdlib.ProcessorFormatter.wrap_for_formatter,
        ],
        logger_factory=structlog.stdlib.LoggerFactory(),
        wrapper_class=structlog.make_filtering_bound_logger(logging.DEBUG),
        cache_logger_on_first_use=True,
    )

    # ── File handler — full JSON, rotating ───────────────────────────────────
    file_handler = logging.handlers.RotatingFileHandler(
        filename="./logs/mustafa_os.log",
        maxBytes=5 * 1024 * 1024,
        backupCount=5,
        encoding="utf-8",
    )
    file_handler.setLevel(logging.DEBUG)
    file_handler.setFormatter(
        structlog.stdlib.ProcessorFormatter(
            processors=[
                structlog.stdlib.ProcessorFormatter.remove_processors_meta,
                _file_json_renderer,
            ],
            foreign_pre_chain=pre_chain,
        )
    )

    # ── Console handler — filtered and pretty-printed ────────────────────────
    console_handler = logging.StreamHandler(sys.stdout)

    if console_mode == "silent":
        console_handler.setLevel(logging.CRITICAL + 1)   # effectively disabled
        console_handler.setFormatter(logging.Formatter())
    elif console_mode == "verbose":
        console_handler.setLevel(logging.DEBUG)
        console_handler.setFormatter(
            structlog.stdlib.ProcessorFormatter(
                processors=[
                    structlog.stdlib.ProcessorFormatter.remove_processors_meta,
                    _console_renderer,
                ],
                foreign_pre_chain=pre_chain,
            )
        )
    else:  # "essential"
        console_handler.setLevel(logging.DEBUG)
        console_handler.setFormatter(
            structlog.stdlib.ProcessorFormatter(
                processors=[
                    structlog.stdlib.ProcessorFormatter.remove_processors_meta,
                    _console_filter,   # drops non-essential events
                    _console_renderer,
                ],
                foreign_pre_chain=pre_chain,
            )
        )

    # ── Root stdlib logger ───────────────────────────────────────────────────
    root = logging.getLogger()
    root.handlers.clear()
    root.setLevel(logging.DEBUG)
    root.addHandler(file_handler)
    root.addHandler(console_handler)

    # Silence noisy third-party libraries on console
    # (they still go to file)
    for noisy in ("httpx", "httpcore", "telegram", "urllib3",
                  "asyncio", "hpack", "h2", "apscheduler", "uvicorn.access"):
        lg = logging.getLogger(noisy)
        lg.setLevel(logging.WARNING)
        # Override to only go to file, not console
        lg.propagate = True


# ─── Public API ───────────────────────────────────────────────────────────────

def get_logger(name: str, **kwargs: Any) -> Any:
    """Get a structured logger with optional context binding."""
    logger = structlog.get_logger(name)
    if kwargs:
        logger = logger.bind(**kwargs)
    return logger


class AgentLogger:
    """Context-aware logger for agents."""

    def __init__(self, agent_id: str, agent_name: str) -> None:
        self.logger = structlog.get_logger("agent").bind(
            agent_id=agent_id,
            agent_name=agent_name,
        )

    def info(self, event: str, **kwargs: Any) -> None:
        self.logger.info(event, **kwargs)

    def warning(self, event: str, **kwargs: Any) -> None:
        self.logger.warning(event, **kwargs)

    def error(self, event: str, **kwargs: Any) -> None:
        self.logger.error(event, **kwargs)

    def debug(self, event: str, **kwargs: Any) -> None:
        self.logger.debug(event, **kwargs)

    def bind(self, **kwargs: Any) -> "AgentLogger":
        self.logger = self.logger.bind(**kwargs)
        return self
