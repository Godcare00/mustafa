"""
MUSTAFA OS - Base Agent
Abstract base class for all MUSTAFA OS agents with full lifecycle management.
"""

from __future__ import annotations

import asyncio
import json
import re
import uuid
from abc import ABC, abstractmethod
from datetime import datetime
from typing import Any, Dict, List, Optional

from core.llm_client import LLMClient, LLMMessage, llm_client
from core.messaging import AgentMessage, MessagePriority, message_bus
from core.registry import AgentStatus, agent_registry
from core.reliability import retry_async, with_timeout
from core.logging_config import AgentLogger
from core.settings import get_agents_config


class TaskContext:
    """Context passed to agents for task execution."""

    def __init__(
        self,
        task_id: str,
        goal: str,
        payload: Dict[str, Any],
        correlation_id: Optional[str] = None,
        sender: Optional[str] = None,
    ) -> None:
        self.task_id = task_id
        self.goal = goal
        self.payload = payload
        self.correlation_id = correlation_id
        self.sender = sender
        self.created_at = datetime.utcnow()
        self.artifacts: Dict[str, Any] = {}

    def add_artifact(self, name: str, value: Any) -> None:
        self.artifacts[name] = value


class AgentResult:
    """Standardized result from agent task execution."""

    def __init__(
        self,
        success: bool,
        data: Any = None,
        error: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> None:
        self.success = success
        self.data = data
        self.error = error
        self.metadata = metadata or {}
        self.timestamp = datetime.utcnow().isoformat()

    def to_dict(self) -> Dict[str, Any]:
        return {
            "success": self.success,
            "data": self.data,
            "error": self.error,
            "metadata": self.metadata,
            "timestamp": self.timestamp,
        }

    @classmethod
    def ok(cls, data: Any, **metadata) -> "AgentResult":
        return cls(success=True, data=data, metadata=metadata)

    @classmethod
    def fail(cls, error: str, **metadata) -> "AgentResult":
        return cls(success=False, error=error, metadata=metadata)


class BaseAgent(ABC):
    """
    Abstract base class for all MUSTAFA OS agents.
    
    Provides:
    - Lifecycle management (start/stop/health)
    - Message handling loop
    - LLM interaction helpers
    - Automatic registry integration
    - Heartbeat monitoring
    - Error isolation
    """

    def __init__(
        self,
        agent_id: str,
        name: str,
        capabilities: List[str],
        allowed_tools: Optional[List[str]] = None,
    ) -> None:
        self.agent_id = agent_id
        self.name = name
        self.capabilities = capabilities
        self.allowed_tools = allowed_tools or []
        self.logger = AgentLogger(agent_id, name)

        # Load config from YAML
        self._config = get_agents_config().get("agents", {}).get(agent_id, {})
        self._model = self._config.get("model", "anthropic/claude-3.5-sonnet")
        self._max_tokens = self._config.get("max_tokens", 4096)
        self._temperature = self._config.get("temperature", 0.7)
        self._system_prompt = self._config.get("system_prompt", "")

        self._running = False
        self._task_loop: Optional[asyncio.Task] = None
        self._heartbeat_loop: Optional[asyncio.Task] = None
        self._message_queue: asyncio.Queue = asyncio.Queue(maxsize=100)

    # ─── Lifecycle ────────────────────────────────────────────────────────────

    async def start(self) -> None:
        """Start the agent and register with the system."""
        await agent_registry.register(
            agent_id=self.agent_id,
            name=self.name,
            capabilities=self.capabilities,
            instance=self,
        )
        await agent_registry.update_status(self.agent_id, AgentStatus.IDLE)

        # Subscribe to messages
        await message_bus.subscribe(self.agent_id, self._on_message)

        self._running = True
        self._task_loop = asyncio.create_task(self._process_loop())
        self._heartbeat_loop = asyncio.create_task(self._heartbeat())

        await self.on_start()
        self.logger.info("agent_started", capabilities=self.capabilities)

    async def stop(self) -> None:
        """Gracefully stop the agent."""
        self._running = False

        if self._task_loop and not self._task_loop.done():
            self._task_loop.cancel()
            try:
                await self._task_loop
            except asyncio.CancelledError:
                pass

        if self._heartbeat_loop and not self._heartbeat_loop.done():
            self._heartbeat_loop.cancel()
            try:
                await self._heartbeat_loop
            except asyncio.CancelledError:
                pass

        await agent_registry.update_status(self.agent_id, AgentStatus.STOPPED)
        await agent_registry.unregister(self.agent_id)
        await self.on_stop()
        self.logger.info("agent_stopped")

    async def on_start(self) -> None:
        """Override for custom initialization."""
        pass

    async def on_stop(self) -> None:
        """Override for custom cleanup."""
        pass

    # ─── Message Processing ───────────────────────────────────────────────────

    async def _on_message(self, message: AgentMessage) -> None:
        """Receive a message from the bus and queue it."""
        if not self._running:
            return
        try:
            await self._message_queue.put_nowait(message)
        except asyncio.QueueFull:
            self.logger.warning("message_queue_full", agent_id=self.agent_id)

    async def _process_loop(self) -> None:
        """Main processing loop — polls queue and processes messages."""
        while self._running:
            try:
                # Check message queue first
                try:
                    message = self._message_queue.get_nowait()
                    await self._handle_message(message)
                    continue
                except asyncio.QueueEmpty:
                    pass

                # Then check Redis queue
                message = await message_bus.dequeue(self.agent_id, timeout=1)
                if message:
                    await self._handle_message(message)
                else:
                    await asyncio.sleep(0.1)

            except asyncio.CancelledError:
                break
            except Exception as e:
                self.logger.error("process_loop_error", error=str(e))
                await asyncio.sleep(1)

    async def _handle_message(self, message: AgentMessage) -> None:
        """Handle an incoming message with error isolation."""
        await agent_registry.update_status(
            self.agent_id,
            AgentStatus.BUSY,
            current_task=message.payload.get("task_id"),
        )

        try:
            context = TaskContext(
                task_id=message.payload.get("task_id", str(uuid.uuid4())),
                goal=message.payload.get("goal", ""),
                payload=message.payload,
                correlation_id=message.correlation_id,
                sender=message.sender,
            )

            result = await with_timeout(
                self.handle_task(message.message_type, context),
                timeout_seconds=self._config.get("timeout", 300),
                error_message=f"Agent {self.agent_id} task timeout",
            )

            await agent_registry.record_task_result(self.agent_id, True)

            # Send result back if correlation_id exists
            if message.correlation_id and message.sender:
                await self._send_result(message, result)

        except Exception as e:
            self.logger.error("task_failed", error=str(e), task_type=message.message_type)
            await agent_registry.record_task_result(self.agent_id, False)
            await agent_registry.update_status(
                self.agent_id, AgentStatus.IDLE, current_task=None
            )

            if message.correlation_id and message.sender:
                error_result = AgentResult.fail(str(e))
                await self._send_result(message, error_result)

        finally:
            await agent_registry.update_status(
                self.agent_id, AgentStatus.IDLE, current_task=None
            )

    async def _send_result(self, original_message: AgentMessage, result: AgentResult) -> None:
        """Send task result back to the sender."""
        response = AgentMessage(
            sender=self.agent_id,
            recipient=original_message.sender,
            message_type=f"{original_message.message_type}_result",
            payload={
                "result": result.to_dict(),
                "original_task_id": original_message.payload.get("task_id"),
            },
            correlation_id=original_message.correlation_id,
        )
        await message_bus.publish(response)

    async def _heartbeat(self) -> None:
        """Periodic heartbeat to signal agent is alive."""
        from core.settings import settings
        while self._running:
            try:
                await agent_registry.heartbeat(self.agent_id)
                await asyncio.sleep(settings.agent_heartbeat_interval)
            except asyncio.CancelledError:
                break
            except Exception as e:
                self.logger.error("heartbeat_failed", error=str(e))
                await asyncio.sleep(5)

    # ─── LLM Helpers ─────────────────────────────────────────────────────────

    async def think(
        self,
        prompt: str,
        conversation: Optional[List[LLMMessage]] = None,
        model: Optional[str] = None,
        max_tokens: Optional[int] = None,
        temperature: Optional[float] = None,
    ) -> str:
        """Send a prompt to the LLM and return the response."""
        messages = conversation or []
        messages.append(LLMMessage(role="user", content=prompt))

        response = await llm_client.complete(
            messages=messages,
            model=model or self._model,
            max_tokens=max_tokens or self._max_tokens,
            temperature=temperature if temperature is not None else self._temperature,
            system_prompt=self._system_prompt,
        )
        return response.content

    async def think_json(
        self,
        prompt: str,
        conversation: Optional[List[LLMMessage]] = None,
        model: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Get a structured JSON response from the LLM."""
        json_prompt = (
            f"{prompt}\n\n"
            "IMPORTANT: Respond ONLY with valid JSON. "
            "No markdown, no explanation, no code blocks. Pure JSON only."
        )
        response = await self.think(json_prompt, conversation, model)

        # Strip markdown code blocks if present
        cleaned = re.sub(r"```(?:json)?\s*", "", response).strip()
        cleaned = re.sub(r"```\s*$", "", cleaned).strip()

        try:
            return json.loads(cleaned)
        except json.JSONDecodeError as e:
            self.logger.error("json_parse_failed", error=str(e), response_preview=cleaned[:200])
            # Attempt to extract JSON from response
            match = re.search(r"\{.*\}", cleaned, re.DOTALL)
            if match:
                return json.loads(match.group())
            raise ValueError(f"Could not parse JSON from LLM response: {cleaned[:200]}")

    # ─── Messaging Helpers ────────────────────────────────────────────────────

    async def send_to_agent(
        self,
        recipient: str,
        task_type: str,
        payload: Dict[str, Any],
        priority: MessagePriority = MessagePriority.NORMAL,
    ) -> str:
        """Send a task to another agent."""
        return await message_bus.send_task(
            sender=self.agent_id,
            recipient=recipient,
            task_type=task_type,
            payload=payload,
            priority=priority,
        )

    async def broadcast(
        self,
        message_type: str,
        payload: Dict[str, Any],
    ) -> None:
        """Broadcast a message to all agents."""
        msg = AgentMessage(
            sender=self.agent_id,
            recipient="broadcast",
            message_type=message_type,
            payload=payload,
        )
        await message_bus.publish(msg)

    # ─── Abstract Method ──────────────────────────────────────────────────────

    @abstractmethod
    async def handle_task(
        self,
        task_type: str,
        context: TaskContext,
    ) -> AgentResult:
        """
        Handle an incoming task.
        Must be implemented by all concrete agents.
        """
        ...
