"""
MUSTAFA OS - Structured Logging Configuration
Machine-readable JSON logs for production observability.
"""

from __future__ import annotations

import logging
import sys
from typing import Any

import structlog


def configure_logging(log_level: str = "INFO", log_format: str = "json") -> None:
    """Configure structlog for production use with JSON output."""

    shared_processors = [
        structlog.contextvars.merge_contextvars,
        structlog.stdlib.add_log_level,
        structlog.stdlib.add_logger_name,
        structlog.processors.TimeStamper(fmt="iso"),
        structlog.processors.StackInfoRenderer(),
        structlog.processors.format_exc_info,
    ]

    if log_format == "json":
        renderer = structlog.processors.JSONRenderer()
    else:
        renderer = structlog.dev.ConsoleRenderer(colors=True)

    structlog.configure(
        processors=shared_processors + [renderer],
        wrapper_class=structlog.make_filtering_bound_logger(
            getattr(logging, log_level.upper(), logging.INFO)
        ),
        context_class=dict,
        logger_factory=structlog.PrintLoggerFactory(),
        cache_logger_on_first_use=True,
    )

    # Also configure standard logging to use structlog
    logging.basicConfig(
        format="%(message)s",
        stream=sys.stdout,
        level=getattr(logging, log_level.upper(), logging.INFO),
    )


def get_logger(name: str, **kwargs: Any) -> structlog.BoundLogger:
    """Get a structured logger with optional context binding."""
    logger = structlog.get_logger(name)
    if kwargs:
        logger = logger.bind(**kwargs)
    return logger


class AgentLogger:
    """Context-aware logger for agents."""

    def __init__(self, agent_id: str, agent_name: str) -> None:
        self.logger = structlog.get_logger("agent").bind(
            agent_id=agent_id,
            agent_name=agent_name,
        )

    def info(self, event: str, **kwargs: Any) -> None:
        self.logger.info(event, **kwargs)

    def warning(self, event: str, **kwargs: Any) -> None:
        self.logger.warning(event, **kwargs)

    def error(self, event: str, **kwargs: Any) -> None:
        self.logger.error(event, **kwargs)

    def debug(self, event: str, **kwargs: Any) -> None:
        self.logger.debug(event, **kwargs)

    def bind(self, **kwargs: Any) -> "AgentLogger":
        self.logger = self.logger.bind(**kwargs)
        return self
