"""
MUSTAFA OS - Example Workflows
Demonstrates common use cases and agent interactions.
"""

# ─── Example 1: Research Task ─────────────────────────────────────────────────

EXAMPLE_RESEARCH = """
Goal: "Research the latest developments in quantum computing and summarize the top 5 breakthroughs in 2024"

What MUSTAFA OS does:
1. Orchestrator receives the goal, asks Planner for a structured plan
2. Planner creates steps:
   - Step 1 → Research Agent: Search "quantum computing breakthroughs 2024"
   - Step 2 → Research Agent: Analyze and extract key findings
   - Step 3 → Critic Agent: Evaluate the summary quality
3. Research Agent uses web_search tool to gather info
4. Results synthesized into a final answer
5. Memory Agent stores findings for future recall

CLI Usage:
    python main.py run "Research the latest developments in quantum computing"

API Usage:
    curl -X POST http://localhost:8000/goals \\
      -H "Content-Type: application/json" \\
      -d '{"goal": "Research quantum computing breakthroughs 2024"}'
"""

# ─── Example 2: Code Generation ───────────────────────────────────────────────

EXAMPLE_CODE_GEN = """
Goal: "Write a Python async function that fetches stock prices from Yahoo Finance and caches results in Redis"

What MUSTAFA OS does:
1. Orchestrator routes to Developer Agent (detects code task)
2. Developer Agent writes the code with:
   - Type hints and docstrings
   - Async/await patterns
   - Error handling
   - Redis caching logic
3. Testing Agent writes unit tests for the function
4. Critic Agent reviews code quality
5. Result delivered with code + tests + quality score

CLI Usage:
    python main.py run "Write a Python async function that fetches stock prices and caches in Redis"
"""

# ─── Example 3: Multi-Step Analysis ──────────────────────────────────────────

EXAMPLE_ANALYSIS = """
Goal: "Analyze our system performance and identify the 3 biggest bottlenecks"

What MUSTAFA OS does:
1. Planner creates a multi-agent plan:
   - Step 1 → Monitoring Agent: collect_metrics
   - Step 2 → Research Agent: analyze performance data
   - Step 3 → Developer Agent: propose optimizations
   - Step 4 → Critic Agent: validate proposals
2. Each step runs in sequence with dependency tracking
3. Final report synthesized across all agent outputs
"""

# ─── Example 4: Self-Improvement ─────────────────────────────────────────────

EXAMPLE_EVOLUTION = """
Triggering Evolution Cycle:

    # Via CLI
    python main.py chat
    > /evolve

    # Via API
    curl -X POST http://localhost:8000/evolve

    # What happens:
    1. Evolution Agent collects performance metrics
    2. Analyzes weaknesses (e.g., slow research, high LLM failures)
    3. Proposes a targeted improvement
    4. Developer Agent implements the change
    5. Testing Agent validates it
    6. If improvement >= 15%, automatically deployed
    7. Experiment logged to database and memory
"""

# ─── Example 5: Dynamic Tool Creation ────────────────────────────────────────

EXAMPLE_NEW_TOOL = """
Creating a new tool dynamically:

    # Ask MUSTAFA OS to create a new tool
    Goal: "Create a new tool called 'weather_api' that fetches real-time weather data
           for any city using the OpenWeatherMap API"

    # MUSTAFA OS will:
    1. Developer Agent writes the tool class
    2. Tool Manager Agent validates and registers it
    3. Tool is saved to ./plugins/weather_api.py
    4. Auto-loaded on next system start
    5. Available to all agents immediately

    # Manual tool creation (place in ./plugins/):
    from tools.base import BaseTool, ToolResult

    class WeatherTool(BaseTool):
        name = "weather_api"
        description = "Get real-time weather data for any city"
        permissions = ["network.read"]
        timeout = 15

        async def execute(self, params):
            city = params.get("city", "London")
            # ... implementation
            return ToolResult(success=True, data={"temp": 22, "condition": "sunny"})
"""

# ─── Example 6: Direct API Calls ─────────────────────────────────────────────

EXAMPLE_API = """
# Submit a goal (async)
curl -X POST http://localhost:8000/goals \\
  -H "Content-Type: application/json" \\
  -d '{"goal": "Summarize the history of AI", "async_mode": true}'

# Response: {"task_id": "uuid", "status": "pending", ...}

# Poll for result
curl http://localhost:8000/tasks/{task_id}

# Check system health
curl http://localhost:8000/health

# List all agents
curl http://localhost:8000/agents

# Execute a tool directly
curl -X POST http://localhost:8000/tools/execute \\
  -H "Content-Type: application/json" \\
  -d '{"tool_name": "web_search", "agent_id": "api", "params": {"query": "MUSTAFA OS AI"}}'

# Search memory
curl -X POST "http://localhost:8000/memory/search?query=quantum+computing&collection=task_history"

# WebSocket streaming
wscat -c ws://localhost:8000/ws
{"goal": "What is the meaning of life?"}
"""

if __name__ == "__main__":
    print("MUSTAFA OS - Example Workflows")
    print("=" * 60)
    print(EXAMPLE_RESEARCH)
    print(EXAMPLE_CODE_GEN)
    print(EXAMPLE_API)
