"""
MUSTAFA OS - Long-Term Memory Layer
Vector database backed by ChromaDB for semantic knowledge storage and retrieval.
"""

from __future__ import annotations

import hashlib
import json
import uuid
from datetime import datetime
from typing import Any, Dict, List, Optional

from core.logging_config import get_logger
from core.settings import settings

logger = get_logger("long_term_memory")


class LongTermMemory:
    """
    Persistent vector memory using ChromaDB.
    Supports semantic search across stored knowledge, task history,
    and experiment records.
    """

    def __init__(self) -> None:
        self._client = None
        self._collections: Dict[str, Any] = {}
        self._initialized = False

    async def initialize(self) -> None:
        """Initialize ChromaDB client and default collections."""
        try:
            import chromadb
            from chromadb.config import Settings as ChromaSettings

            self._client = chromadb.PersistentClient(
                path=settings.chroma_persist_dir,
                settings=ChromaSettings(anonymized_telemetry=False),
            )

            # Create default collections
            for collection_name in ["general", "task_history", "experiments", "agent_knowledge"]:
                self._collections[collection_name] = self._client.get_or_create_collection(
                    name=collection_name,
                    metadata={"hnsw:space": "cosine"},
                )

            self._initialized = True
            logger.info("long_term_memory_initialized", path=settings.chroma_persist_dir)

        except ImportError:
            logger.warning("chromadb_not_installed", message="Long-term memory unavailable. Install chromadb.")
        except Exception as e:
            logger.error("memory_init_failed", error=str(e))

    async def store(
        self,
        content: str,
        metadata: Optional[Dict[str, Any]] = None,
        collection: str = "general",
    ) -> str:
        """Store a memory entry and return its ID."""
        if not self._initialized:
            return ""

        try:
            coll = self._get_or_create_collection(collection)
            mem_id = str(uuid.uuid4())
            content_hash = hashlib.sha256(content.encode()).hexdigest()

            meta = {
                "timestamp": datetime.utcnow().isoformat(),
                "content_hash": content_hash,
                **(metadata or {}),
            }
            # ChromaDB metadata values must be str/int/float/bool
            clean_meta = {k: str(v) if not isinstance(v, (str, int, float, bool)) else v
                         for k, v in meta.items()}

            coll.add(
                documents=[content],
                metadatas=[clean_meta],
                ids=[mem_id],
            )

            logger.debug("memory_stored", id=mem_id, collection=collection)
            return mem_id

        except Exception as e:
            logger.error("memory_store_failed", error=str(e))
            return ""

    async def search(
        self,
        query: str,
        collection: str = "general",
        top_k: int = 5,
        where: Optional[Dict] = None,
    ) -> List[Dict[str, Any]]:
        """Semantic search over stored memories."""
        if not self._initialized:
            return []

        try:
            coll = self._get_or_create_collection(collection)
            query_params: Dict[str, Any] = {
                "query_texts": [query],
                "n_results": min(top_k, max(coll.count(), 1)),
            }
            if where:
                query_params["where"] = where

            results = coll.query(**query_params)

            memories = []
            if results and results.get("documents"):
                docs = results["documents"][0]
                metas = results.get("metadatas", [[]])[0]
                distances = results.get("distances", [[]])[0]

                for doc, meta, dist in zip(docs, metas, distances):
                    memories.append({
                        "content": doc,
                        "metadata": meta,
                        "relevance_score": round(1.0 - dist, 4),
                    })

            return memories

        except Exception as e:
            logger.error("memory_search_failed", error=str(e))
            return []

    async def delete(self, memory_id: str, collection: str = "general") -> bool:
        """Delete a specific memory by ID."""
        if not self._initialized:
            return False
        try:
            coll = self._get_or_create_collection(collection)
            coll.delete(ids=[memory_id])
            return True
        except Exception as e:
            logger.error("memory_delete_failed", error=str(e))
            return False

    async def get_collection_stats(self, collection: str = "general") -> Dict[str, Any]:
        """Get statistics about a memory collection."""
        if not self._initialized:
            return {"available": False}
        try:
            coll = self._get_or_create_collection(collection)
            return {"collection": collection, "count": coll.count(), "available": True}
        except Exception as e:
            return {"available": False, "error": str(e)}

    def _get_or_create_collection(self, name: str):
        """Get or create a named collection."""
        if name not in self._collections:
            if self._client:
                self._collections[name] = self._client.get_or_create_collection(
                    name=name,
                    metadata={"hnsw:space": "cosine"},
                )
        return self._collections.get(name)

    @property
    def is_available(self) -> bool:
        return self._initialized
