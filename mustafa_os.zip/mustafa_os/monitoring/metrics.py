"""
MUSTAFA OS - Prometheus Metrics
Exports system metrics in Prometheus format for scraping.
"""

from __future__ import annotations

from prometheus_client import (
    Counter,
    Gauge,
    Histogram,
    Summary,
    generate_latest,
    CONTENT_TYPE_LATEST,
)

# ─── Metric Definitions ───────────────────────────────────────────────────────

# Counters
TASKS_TOTAL = Counter("mustafa_tasks_total", "Total tasks submitted", ["status"])
AGENT_TASKS_TOTAL = Counter("mustafa_agent_tasks_total", "Tasks per agent", ["agent_id", "status"])
LLM_REQUESTS_TOTAL = Counter("mustafa_llm_requests_total", "LLM API requests", ["model", "status"])
TOOL_EXECUTIONS_TOTAL = Counter("mustafa_tool_executions_total", "Tool executions", ["tool_name", "status"])

# Gauges
AGENTS_ACTIVE = Gauge("mustafa_agents_active", "Number of active agents")
AGENTS_IDLE = Gauge("mustafa_agents_idle", "Number of idle agents")
AGENTS_BUSY = Gauge("mustafa_agents_busy", "Number of busy agents")
SYSTEM_UPTIME = Gauge("mustafa_uptime_seconds", "System uptime in seconds")
REDIS_QUEUE_SIZE = Gauge("mustafa_redis_queue_size", "Redis queue size", ["agent_id"])

# Histograms
TASK_DURATION = Histogram(
    "mustafa_task_duration_seconds",
    "Task execution duration",
    ["agent_id"],
    buckets=[1, 5, 10, 30, 60, 120, 300],
)
LLM_LATENCY = Histogram(
    "mustafa_llm_latency_seconds",
    "LLM API latency",
    ["model"],
    buckets=[0.5, 1, 2, 5, 10, 30, 60],
)
TOOL_LATENCY = Histogram(
    "mustafa_tool_latency_seconds",
    "Tool execution latency",
    ["tool_name"],
    buckets=[0.1, 0.5, 1, 5, 10, 30],
)


def update_agent_metrics() -> None:
    """Refresh agent count gauges."""
    from core.registry import agent_registry
    summary = agent_registry.get_system_summary()
    AGENTS_ACTIVE.set(summary["total_agents"])
    AGENTS_IDLE.set(summary["idle"])
    AGENTS_BUSY.set(summary["busy"])


def get_metrics_output() -> bytes:
    """Generate Prometheus-format metrics output."""
    update_agent_metrics()
    return generate_latest()
