"""
MUSTAFA OS - LLM Client
Async client for OpenRouter API with circuit breaker, retry, and structured output.
"""
from __future__ import annotations

import json
import time
from typing import Any, Dict, List, Optional

import httpx

from core.config import get_settings
from core.logger import get_logger
from core.reliability import CircuitBreaker, get_circuit_breaker, retry

logger = get_logger("llm_client")


class LLMMessage:
    """A message in an LLM conversation."""

    def __init__(self, role: str, content: str):
        self.role = role
        self.content = content

    def to_dict(self) -> Dict[str, str]:
        return {"role": self.role, "content": self.content}

    @classmethod
    def system(cls, content: str) -> "LLMMessage":
        return cls("system", content)

    @classmethod
    def user(cls, content: str) -> "LLMMessage":
        return cls("user", content)

    @classmethod
    def assistant(cls, content: str) -> "LLMMessage":
        return cls("assistant", content)


class LLMResponse:
    """Parsed LLM response."""

    def __init__(
        self,
        content: str,
        model: str,
        usage: Optional[Dict] = None,
        finish_reason: str = "stop",
        latency_ms: float = 0.0,
    ):
        self.content = content
        self.model = model
        self.usage = usage or {}
        self.finish_reason = finish_reason
        self.latency_ms = latency_ms

    def parse_json(self) -> Any:
        """Attempt to parse response content as JSON."""
        text = self.content.strip()
        # Strip markdown code fences if present
        if text.startswith("```"):
            lines = text.split("\n")
            # Remove first and last fence lines
            if lines[0].startswith("```"):
                lines = lines[1:]
            if lines and lines[-1].strip() == "```":
                lines = lines[:-1]
            text = "\n".join(lines)
        try:
            return json.loads(text)
        except json.JSONDecodeError as e:
            logger.warning("Failed to parse LLM response as JSON", error=str(e))
            raise

    def __repr__(self) -> str:
        return f"LLMResponse(model={self.model}, tokens={self.usage.get('total_tokens')}, latency={self.latency_ms:.0f}ms)"


class LLMClient:
    """
    Async LLM client for OpenRouter.
    Features: circuit breaker, retry, timeout management, structured outputs.
    """

    def __init__(self):
        self._settings = get_settings()
        self._circuit_breaker: CircuitBreaker = get_circuit_breaker(
            "llm",
            failure_threshold=self._settings.circuit_breaker.failure_threshold,
            recovery_timeout=float(self._settings.circuit_breaker.recovery_timeout),
        )
        self._client: Optional[httpx.AsyncClient] = None

    async def _get_client(self) -> httpx.AsyncClient:
        """Get or create the HTTP client."""
        if self._client is None or self._client.is_closed:
            self._client = httpx.AsyncClient(
                base_url=self._settings.llm.base_url,
                headers={
                    "Authorization": f"Bearer {self._settings.llm.api_key}",
                    "Content-Type": "application/json",
                    "HTTP-Referer": "https://mustafa-os.local",
                    "X-Title": "MUSTAFA OS",
                },
                timeout=httpx.Timeout(
                    connect=10.0,
                    read=self._settings.llm.timeout,
                    write=30.0,
                    pool=5.0,
                ),
            )
        return self._client

    async def close(self) -> None:
        """Close the HTTP client."""
        if self._client and not self._client.is_closed:
            await self._client.aclose()

    async def complete(
        self,
        messages: List[LLMMessage],
        model: Optional[str] = None,
        max_tokens: Optional[int] = None,
        temperature: Optional[float] = None,
        system_prompt: Optional[str] = None,
        json_mode: bool = False,
    ) -> LLMResponse:
        """
        Send a completion request to the LLM.
        Circuit breaker wraps a retry-enabled inner call.
        """
        @retry(max_attempts=3, backoff=2.0, exceptions=(httpx.TimeoutException, httpx.NetworkError))
        async def _call_with_retry() -> LLMResponse:
            return await self._raw_complete(
                messages=messages,
                model=model,
                max_tokens=max_tokens,
                temperature=temperature,
                system_prompt=system_prompt,
                json_mode=json_mode,
            )

        return await self._circuit_breaker.call(_call_with_retry)

    async def _raw_complete(
        self,
        messages: List[LLMMessage],
        model: Optional[str] = None,
        max_tokens: Optional[int] = None,
        temperature: Optional[float] = None,
        system_prompt: Optional[str] = None,
        json_mode: bool = False,
    ) -> LLMResponse:
        """Execute the actual HTTP call."""
        client = await self._get_client()
        effective_model = model or self._settings.llm.default_model
        effective_max_tokens = max_tokens or self._settings.llm.max_tokens
        effective_temperature = temperature if temperature is not None else self._settings.llm.temperature

        # Build message list
        api_messages: List[Dict] = []
        if system_prompt:
            api_messages.append({"role": "system", "content": system_prompt})
        api_messages.extend([m.to_dict() for m in messages])

        payload: Dict[str, Any] = {
            "model": effective_model,
            "messages": api_messages,
            "max_tokens": effective_max_tokens,
            "temperature": effective_temperature,
        }

        if json_mode:
            payload["response_format"] = {"type": "json_object"}

        start = time.monotonic()
        logger.debug(
            "LLM request",
            model=effective_model,
            messages=len(api_messages),
            max_tokens=effective_max_tokens,
        )

        response = await client.post("/chat/completions", json=payload)

        if response.status_code != 200:
            error_body = response.text[:500]
            logger.error(
                "LLM API error",
                status=response.status_code,
                body=error_body,
                model=effective_model,
            )
            raise LLMError(
                f"LLM API returned {response.status_code}: {error_body}"
            )

        data = response.json()
        latency_ms = (time.monotonic() - start) * 1000

        content = data["choices"][0]["message"]["content"]
        finish_reason = data["choices"][0].get("finish_reason", "stop")
        usage = data.get("usage", {})

        logger.info(
            "LLM response received",
            model=effective_model,
            latency_ms=round(latency_ms, 1),
            tokens=usage.get("total_tokens"),
            finish_reason=finish_reason,
        )

        return LLMResponse(
            content=content,
            model=effective_model,
            usage=usage,
            finish_reason=finish_reason,
            latency_ms=latency_ms,
        )

    async def complete_json(
        self,
        messages: List[LLMMessage],
        model: Optional[str] = None,
        max_tokens: Optional[int] = None,
        temperature: Optional[float] = None,
        system_prompt: Optional[str] = None,
    ) -> Any:
        """Complete and parse response as JSON. Retries with correction hint on bad JSON."""
        current_messages = list(messages)
        last_error: Optional[Exception] = None

        for attempt in range(3):
            response = await self.complete(
                messages=current_messages,
                model=model,
                max_tokens=max_tokens,
                temperature=temperature,
                system_prompt=system_prompt,
                json_mode=True,
            )
            try:
                return response.parse_json()
            except json.JSONDecodeError as e:
                last_error = e
                logger.warning(f"JSON parse failed on attempt {attempt + 1}/3", error=str(e))
                if attempt < 2:
                    current_messages = current_messages + [
                        LLMMessage.assistant(response.content),
                        LLMMessage.user(
                            "Your previous response was not valid JSON. "
                            "Please respond ONLY with a valid JSON object, no markdown, no explanation."
                        ),
                    ]

        raise LLMError(f"Failed to get valid JSON after 3 attempts. Last error: {last_error}")

    def health(self) -> Dict:
        """Return health status of the LLM client."""
        return {
            "circuit_breaker": self._circuit_breaker.get_status(),
            "api_key_configured": bool(self._settings.llm.api_key),
            "model": self._settings.llm.default_model,
        }


class LLMError(Exception):
    """LLM client error."""
    pass


# Singleton
_llm_client: Optional[LLMClient] = None


def get_llm_client() -> LLMClient:
    """Get or create the global LLM client."""
    global _llm_client
    if _llm_client is None:
        _llm_client = LLMClient()
    return _llm_client
