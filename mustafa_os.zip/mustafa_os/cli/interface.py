"""
MUSTAFA OS - CLI Interface
Production-grade interactive terminal for direct system interaction.
"""

from __future__ import annotations

import asyncio
import sys
import uuid
from datetime import datetime
from typing import Optional

import click
from rich.console import Console
from rich.markdown import Markdown
from rich.panel import Panel
from rich.progress import Progress, SpinnerColumn, TextColumn
from rich.table import Table
from prompt_toolkit import PromptSession
from prompt_toolkit.history import InMemoryHistory
from prompt_toolkit.auto_suggest import AutoSuggestFromHistory

console = Console()

BANNER = """
[bold cyan]╔═══════════════════════════════════════════════════════════╗[/bold cyan]
[bold cyan]║[/bold cyan]  [bold white]MUSTAFA OS[/bold white] [dim]v1.0.0[/dim]                                         [bold cyan]║[/bold cyan]
[bold cyan]║[/bold cyan]  [dim]Modular Unified System for Task Automation[/dim]            [bold cyan]║[/bold cyan]
[bold cyan]║[/bold cyan]  [dim]and Autonomous Intelligence[/dim]                           [bold cyan]║[/bold cyan]
[bold cyan]╚═══════════════════════════════════════════════════════════╝[/bold cyan]

[dim]Type your goal or command. Type [bold]/help[/bold] to see all commands.[/dim]
"""

HELP_TEXT = """
[bold]Available Commands:[/bold]

  [cyan]/help[/cyan]              Show this help
  [cyan]/status[/cyan]            Show system status
  [cyan]/agents[/cyan]            List all agents and status
  [cyan]/tools[/cyan]             List available tools
  [cyan]/tasks[/cyan]             Show recent tasks
  [cyan]/history[/cyan]           Show conversation history
  [cyan]/clear[/cyan]             Clear the screen
  [cyan]/evolve[/cyan]            Trigger self-improvement cycle
  [cyan]/search <query>[/cyan]    Search system memory
  [cyan]/quit[/cyan]              Exit MUSTAFA OS

[bold]Examples:[/bold]
  Research the latest developments in quantum computing
  Write a Python function to parse JSON from URLs
  /agents
  /evolve
"""


class MustafaOSCLI:
    """Rich terminal interface for MUSTAFA OS."""

    def __init__(self) -> None:
        self.session_id = str(uuid.uuid4())
        self.history: list = []
        self.kernel = None
        self._prompt_session = PromptSession(
            history=InMemoryHistory(),
            auto_suggest=AutoSuggestFromHistory(),
        )

    async def start(self) -> None:
        """Boot the kernel and start the interactive loop."""
        console.print(BANNER)

        with Progress(
            SpinnerColumn(),
            TextColumn("[bold cyan]{task.description}"),
            console=console,
            transient=True,
        ) as progress:
            task = progress.add_task("Booting MUSTAFA OS...", total=None)
            try:
                from core.kernel import kernel
                self.kernel = kernel
                await kernel.boot()
                progress.update(task, description="[green]✓ System ready")
                await asyncio.sleep(0.5)
            except Exception as e:
                console.print(f"[red]Boot failed: {e}[/red]")
                console.print("[yellow]Running in limited mode (check your .env file)[/yellow]")
                self.kernel = None

        await self._interactive_loop()

    async def _interactive_loop(self) -> None:
        """Main interactive command loop."""
        while True:
            try:
                user_input = await asyncio.get_event_loop().run_in_executor(
                    None,
                    lambda: self._prompt_session.prompt(
                        "\n[MUSTAFA OS] → ",
                    )
                )
            except (KeyboardInterrupt, EOFError):
                await self._quit()
                return

            user_input = user_input.strip()
            if not user_input:
                continue

            self.history.append({"role": "user", "content": user_input, "time": datetime.utcnow().isoformat()})

            if user_input.startswith("/"):
                await self._handle_command(user_input)
            else:
                await self._handle_goal(user_input)

    async def _handle_goal(self, goal: str) -> None:
        """Send a goal to the orchestrator and stream the result."""
        console.print(f"\n[dim]→ Submitting goal to MUSTAFA OS...[/dim]")

        with Progress(
            SpinnerColumn(),
            TextColumn("[bold cyan]{task.description}"),
            console=console,
            transient=True,
        ) as progress:
            task = progress.add_task("Orchestrating...", total=None)

            try:
                if self.kernel and self.kernel.is_running:
                    orchestrator = self.kernel.get_orchestrator()
                    if orchestrator:
                        from agents.base import TaskContext
                        task_id = str(uuid.uuid4())
                        context = TaskContext(
                            task_id=task_id,
                            goal=goal,
                            payload={"goal": goal, "task_id": task_id, "session_id": self.session_id},
                        )
                        progress.update(task, description="Executing agents...")
                        result = await orchestrator.handle_task("execute_goal", context)

                        progress.update(task, description="[green]Complete")
                        await asyncio.sleep(0.3)

                        if result.success:
                            answer = result.data.get("answer", str(result.data)) if isinstance(result.data, dict) else str(result.data)
                            self._display_answer(answer, result)
                        else:
                            console.print(Panel(
                                f"[red]{result.error}[/red]",
                                title="[red]Error[/red]",
                                border_style="red",
                            ))
                    else:
                        progress.stop()
                        self._display_no_kernel(goal)
                else:
                    progress.stop()
                    self._display_no_kernel(goal)

            except Exception as e:
                progress.update(task, description=f"[red]Failed: {e}")
                console.print(f"\n[red]Error: {e}[/red]")

    def _display_answer(self, answer: str, result) -> None:
        """Render the answer in a beautiful panel."""
        try:
            md = Markdown(answer)
            console.print(Panel(
                md,
                title="[bold green]MUSTAFA OS Response[/bold green]",
                border_style="green",
                padding=(1, 2),
            ))
        except Exception:
            console.print(Panel(
                answer,
                title="[bold green]MUSTAFA OS Response[/bold green]",
                border_style="green",
            ))

        # Show critique if available
        if isinstance(result.data, dict) and result.data.get("critique"):
            critique = result.data["critique"]
            score = critique.get("score", "N/A")
            console.print(f"[dim]Quality score: {score} | Verdict: {critique.get('verdict', 'N/A')}[/dim]")

    def _display_no_kernel(self, goal: str) -> None:
        """Fallback display when kernel is not running."""
        console.print(Panel(
            f"[yellow]Kernel not running. To use MUSTAFA OS fully:\n"
            f"1. Set up your .env file with API keys\n"
            f"2. Start Redis: redis-server\n"
            f"3. Run: python main.py\n\n"
            f"Your goal was: {goal}[/yellow]",
            title="[yellow]Limited Mode[/yellow]",
            border_style="yellow",
        ))

    async def _handle_command(self, cmd: str) -> None:
        """Handle slash commands."""
        parts = cmd.split(maxsplit=2)
        command = parts[0].lower()

        if command == "/help":
            console.print(Panel(HELP_TEXT, title="MUSTAFA OS Help", border_style="cyan"))

        elif command == "/status":
            await self._show_status()

        elif command == "/agents":
            await self._show_agents()

        elif command == "/tools":
            await self._show_tools()

        elif command == "/tasks":
            await self._show_tasks()

        elif command == "/history":
            self._show_history()

        elif command == "/clear":
            console.clear()
            console.print(BANNER)

        elif command == "/evolve":
            await self._trigger_evolution()

        elif command == "/search" and len(parts) > 1:
            await self._search_memory(parts[1])

        elif command in ("/quit", "/exit", "/q"):
            await self._quit()
            sys.exit(0)

        else:
            console.print(f"[yellow]Unknown command: {command}. Type /help for help.[/yellow]")

    async def _show_status(self) -> None:
        if not self.kernel:
            console.print("[yellow]Kernel not running[/yellow]")
            return

        status = self.kernel.get_status()
        table = Table(title="System Status", border_style="cyan")
        table.add_column("Property", style="cyan")
        table.add_column("Value", style="white")

        table.add_row("Status", "[green]Running[/green]" if status["running"] else "[red]Stopped[/red]")
        table.add_row("Version", status["version"])
        table.add_row("Environment", status["environment"])
        table.add_row("Uptime", f"{int(status['uptime_seconds'])}s")
        table.add_row("Agents", str(status["agent_count"]))

        console.print(table)

    async def _show_agents(self) -> None:
        from core.registry import agent_registry

        agents = agent_registry.get_all_agents()
        if not agents:
            console.print("[yellow]No agents registered[/yellow]")
            return

        table = Table(title="Registered Agents", border_style="cyan")
        table.add_column("ID", style="cyan")
        table.add_column("Name", style="white")
        table.add_column("Status", style="white")
        table.add_column("Tasks", justify="right")
        table.add_column("Success Rate", justify="right")

        for agent in agents:
            status_color = {
                "idle": "green", "busy": "yellow",
                "error": "red", "stopped": "dim"
            }.get(agent.status, "white")
            table.add_row(
                agent.agent_id,
                agent.name,
                f"[{status_color}]{agent.status}[/{status_color}]",
                str(agent.task_count),
                f"{agent.success_rate:.0%}",
            )
        console.print(table)

    async def _show_tools(self) -> None:
        from tools import get_tool_engine
        engine = get_tool_engine()
        tools = engine.get_all_tools()

        table = Table(title="Available Tools", border_style="cyan")
        table.add_column("Name", style="cyan")
        table.add_column("Description")
        table.add_column("Calls", justify="right")
        table.add_column("Errors", justify="right")

        for t in tools:
            d = t.to_dict()
            table.add_row(d["name"], d["description"][:60], str(d["call_count"]), str(d["error_count"]))
        console.print(table)

    async def _show_tasks(self) -> None:
        from api.app import _active_tasks
        if not _active_tasks:
            console.print("[dim]No tasks recorded this session[/dim]")
            return

        table = Table(title="Recent Tasks", border_style="cyan")
        table.add_column("Task ID", style="dim")
        table.add_column("Status")
        table.add_column("Goal")
        table.add_column("Created")

        for task in list(_active_tasks.values())[-10:]:
            status_color = {"completed": "green", "failed": "red", "running": "yellow"}.get(task["status"], "white")
            table.add_row(
                task["task_id"][:8] + "...",
                f"[{status_color}]{task['status']}[/{status_color}]",
                task["goal"][:50] + "..." if len(task["goal"]) > 50 else task["goal"],
                task["created_at"][:19],
            )
        console.print(table)

    def _show_history(self) -> None:
        if not self.history:
            console.print("[dim]No history[/dim]")
            return
        for item in self.history[-20:]:
            role_style = "bold cyan" if item["role"] == "user" else "bold green"
            console.print(f"[{role_style}]{item['role'].upper()}[/{role_style}]: {item['content'][:200]}")

    async def _trigger_evolution(self) -> None:
        console.print("[cyan]Triggering evolution cycle via Orchestrator...[/cyan]")
        if self.kernel and self.kernel.is_running:
            orchestrator = self.kernel.get_orchestrator()
            if orchestrator:
                from agents.base import TaskContext
                ctx = TaskContext(
                    task_id=str(uuid.uuid4()),
                    goal="Run a self-improvement evolution cycle: analyse system performance, identify weaknesses, propose and implement targeted improvements.",
                    payload={"triggered_by": "cli"},
                )
                asyncio.create_task(orchestrator.handle_task("execute_goal", ctx))
                console.print("[green]Evolution cycle triggered. Check logs for results.[/green]")
            else:
                console.print("[red]Orchestrator not available[/red]")
        else:
            console.print("[yellow]Kernel not running[/yellow]")

    async def _search_memory(self, query: str) -> None:
        console.print(f"[dim]Searching memory for: {query}[/dim]")
        try:
            from memory.long_term import LongTermMemory
            mem = LongTermMemory()
            await mem.initialize()
            results = await mem.search(query=query, top_k=5)
            if results:
                for i, r in enumerate(results, 1):
                    console.print(Panel(
                        r.get("content", "")[:300],
                        title=f"[cyan]Memory {i} (score: {r.get('relevance_score', 0):.2f})[/cyan]",
                        border_style="dim",
                    ))
            else:
                console.print("[dim]No relevant memories found[/dim]")
        except Exception as e:
            console.print(f"[red]Memory search failed: {e}[/red]")

    async def _quit(self) -> None:
        console.print("\n[cyan]Shutting down MUSTAFA OS...[/cyan]")
        if self.kernel and self.kernel.is_running:
            await self.kernel.shutdown()
        console.print("[green]Goodbye.[/green]")


# ─── Click CLI Entry Points ───────────────────────────────────────────────────

@click.group()
def cli():
    """MUSTAFA OS - Autonomous Multi-Agent Operating System"""
    pass


@cli.command()
def chat():
    """Start the interactive CLI chat."""
    interface = MustafaOSCLI()
    asyncio.run(interface.start())


@cli.command()
@click.argument("goal")
def run(goal: str):
    """Execute a single goal and exit."""
    async def _run():
        from core.kernel import kernel
        await kernel.boot()
        orchestrator = kernel.get_orchestrator()
        if orchestrator:
            from agents.base import TaskContext
            context = TaskContext(
                task_id=str(uuid.uuid4()),
                goal=goal,
                payload={"goal": goal, "task_id": str(uuid.uuid4())},
            )
            result = await orchestrator.handle_task("execute_goal", context)
            if result.success:
                console.print(Panel(
                    str(result.data.get("answer", result.data)),
                    title="Result",
                    border_style="green",
                ))
            else:
                console.print(f"[red]Failed: {result.error}[/red]")
        await kernel.shutdown()

    asyncio.run(_run())


@cli.command()
def server():
    """Start the API server only."""
    import uvicorn
    uvicorn.run(
        "api.app:app",
        host=settings_module.api_host,
        port=settings_module.api_port,
        workers=1,
        log_level="info",
    )


if __name__ == "__main__":
    cli()


# Import settings for server command
try:
    from core.settings import settings as settings_module
except Exception:
    pass
