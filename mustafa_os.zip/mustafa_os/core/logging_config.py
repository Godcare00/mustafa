"""
MUSTAFA OS - Logging Configuration

Two-channel logging:
  Console  — essential events only, clean coloured single lines
  File     — everything (JSON, rotating 5 MB × 5 files, ~25 MB max total)

Works with any structlog >= 19.x
"""

from __future__ import annotations

import json
import logging
import logging.handlers
import os
import sys
from typing import Any

import structlog

# ─── Essential events shown on the console ────────────────────────────────────

CONSOLE_EVENTS = frozenset({
    # Boot
    "kernel_booting", "kernel_ready", "memory_ready",
    "database_ready", "message_bus_ready", "llm_client_ready",
    "agent_started_ok",
    # Goals
    "executing_goal", "goal_completed", "goal_failed",
    # Orchestrator
    "orchestrator_action", "orchestrator_tool_call", "orchestrator_agent_call",
    "system_context_built",
    # Tools
    "shell_executing", "shell_executed",
    "web_search_complete", "ddgs_installing", "ddgs_installed_successfully",
    "tool_hot_loaded", "tool_registered",
    # Files / Telegram
    "telegram_file_received", "telegram_attachment_sent",
    # Critic
    "evaluation_complete",
})

# Warnings + errors always reach the console
ALWAYS_CONSOLE_LEVELS = frozenset({"warning", "error", "critical"})

ICONS = {
    "kernel_booting":              "🚀",
    "kernel_ready":                "✅",
    "memory_ready":                "🧠",
    "database_ready":              "🗄",
    "message_bus_ready":           "📡",
    "llm_client_ready":            "🤖",
    "agent_started_ok":            "✓",
    "executing_goal":              "▶",
    "goal_completed":              "✅",
    "goal_failed":                 "❌",
    "orchestrator_action":         "⚙",
    "orchestrator_tool_call":      "🔧",
    "orchestrator_agent_call":     "📤",
    "system_context_built":        "📊",
    "shell_executing":             "💻",
    "shell_executed":              "💻",
    "web_search_complete":         "🔍",
    "ddgs_installing":             "📦",
    "ddgs_installed_successfully": "📦",
    "tool_hot_loaded":             "🔌",
    "tool_registered":             "🔌",
    "telegram_file_received":      "📥",
    "telegram_attachment_sent":    "📎",
    "evaluation_complete":         "🎯",
}

LEVEL_COLOUR = {
    "debug":    "\033[90m",   # grey
    "info":     "",           # default terminal colour
    "warning":  "\033[33m",   # yellow
    "error":    "\033[31m",   # red
    "critical": "\033[1;31m", # bold red
}
RESET = "\033[0m"

PRIORITY_KEYS = (
    "goal", "agent_id", "agent", "tool", "action", "thought",
    "agents", "tools", "actions", "error", "command",
    "query", "results", "filename", "path", "score", "verdict", "task_id",
)


# ─── Structlog processors ─────────────────────────────────────────────────────

class ConsoleFilter:
    """
    Structlog processor: drops events that should not reach the console.
    Applied only in the console render chain.
    """
    def __call__(self, logger, method: str, event_dict: dict) -> dict:
        event = event_dict.get("event", "")
        level = method.lower()
        if level in ALWAYS_CONSOLE_LEVELS or event in CONSOLE_EVENTS:
            return event_dict
        raise structlog.DropEvent()


class ConsoleRenderer:
    """Renders a compact, coloured single-line entry for the console."""

    def __call__(self, logger, method: str, event_dict: dict) -> str:
        event  = event_dict.get("event", "")
        level  = event_dict.get("level", method).lower()
        ts     = str(event_dict.get("timestamp", ""))[:19].replace("T", " ")
        icon   = ICONS.get(event, " ")
        colour = LEVEL_COLOUR.get(level, "")

        parts = []
        for key in PRIORITY_KEYS:
            val = event_dict.get(key)
            if val is None:
                continue
            v = str(val)
            if key == "task_id":
                v = v[:8] + "…"
            elif len(v) > 72:
                v = v[:69] + "…"
            parts.append(f"{key}={v}")

        detail = "  " + "  ".join(parts) if parts else ""
        return f"{colour}{ts}  {icon} {event}{detail}{RESET}"


class FileJSONRenderer:
    """Renders every event as a JSON line for the log file."""

    def __call__(self, logger, method: str, event_dict: dict) -> str:
        return json.dumps(event_dict, default=str, ensure_ascii=False)


# ─── Two separate print-logger factories ─────────────────────────────────────

class _FileWriter:
    """Writes to the rotating file handler only."""
    def __init__(self, handler: logging.Handler) -> None:
        self._h = handler

    def msg(self, message: str) -> None:
        record = logging.LogRecord("mustafa", logging.INFO, "", 0, message, (), None)
        self._h.emit(record)

    log = debug = info = warning = error = critical = msg


class _ConsoleWriter:
    """Writes to stdout only."""
    def msg(self, message: str) -> None:
        print(message, flush=True)

    log = debug = info = warning = error = critical = msg


# ─── Public configure function ────────────────────────────────────────────────

def configure_logging(
    log_level: str = "INFO",
    log_format: str = "json",
    console_mode: str = "essential",
) -> None:
    """
    Configure dual-channel logging.

    console_mode:
      "essential"  — only key events (boot, goals, actions, errors)
      "verbose"    — everything shown on console AND written to file
      "silent"     — nothing on console; file receives everything
    """
    os.makedirs("./logs", exist_ok=True)

    # ── Rotating file handler ─────────────────────────────────────────────
    file_handler = logging.handlers.RotatingFileHandler(
        filename="./logs/mustafa_os.log",
        maxBytes=5 * 1024 * 1024,   # 5 MB per file
        backupCount=5,               # 5 backups → ~25 MB total
        encoding="utf-8",
    )

    # ── Silence noisy stdlib loggers ─────────────────────────────────────
    for lib in ("httpx", "httpcore", "telegram", "urllib3",
                "asyncio", "hpack", "h2", "apscheduler"):
        logging.getLogger(lib).setLevel(logging.WARNING)

    # Suppress stdlib logging noise on console (it still goes to file via handler)
    root = logging.getLogger()
    root.setLevel(logging.DEBUG)
    root.handlers.clear()
    root.addHandler(file_handler)
    root.addHandler(logging.StreamHandler(sys.stdout))

    # File handler gets everything; console handler only gets WARNING+
    root.handlers[0].setLevel(logging.DEBUG)    # file: all
    root.handlers[1].setLevel(logging.WARNING)  # console stdlib: warnings only

    # ── Structlog: console pipeline — mode-aware ──────────────────────────
    _base = [
        structlog.contextvars.merge_contextvars,
        structlog.stdlib.add_log_level,
        structlog.stdlib.add_logger_name,
        structlog.processors.TimeStamper(fmt="iso"),
        structlog.processors.StackInfoRenderer(),
        structlog.processors.format_exc_info,
    ]

    if console_mode == "silent":
        # Nothing on console — all output goes to file only
        class _DropAll:
            def __call__(self, l, m, e):
                raise structlog.DropEvent()
        console_processors = _base[:4] + [_DropAll()]
        # Also suppress the stdlib console handler
        root.handlers[1].setLevel(logging.CRITICAL + 1)
    elif console_mode == "verbose":
        # Everything on console (JSON lines, no filtering)
        console_processors = _base + [ConsoleRenderer()]
    else:
        # "essential" — default: filter to key events + pretty one-liner
        console_processors = _base + [ConsoleFilter(), ConsoleRenderer()]

    file_processors = [
        structlog.contextvars.merge_contextvars,
        structlog.stdlib.add_log_level,
        structlog.stdlib.add_logger_name,
        structlog.processors.TimeStamper(fmt="iso"),
        structlog.processors.StackInfoRenderer(),
        structlog.processors.format_exc_info,
        FileJSONRenderer(),   # full JSON
    ]

    # Build a custom dual-output logger factory
    _file_writer    = _FileWriter(file_handler)
    _console_writer = _ConsoleWriter()

    class DualLoggerFactory:
        def __call__(self, *args):
            return _DualLogger(
                console_processors=console_processors,
                file_processors=file_processors,
                file_writer=_file_writer,
                console_writer=_console_writer,
            )

    structlog.configure(
        processors=[],  # processors applied per-channel in DualLogger
        wrapper_class=structlog.BoundLogger,
        context_class=dict,
        logger_factory=DualLoggerFactory(),
        cache_logger_on_first_use=False,
    )


class _DualLogger:
    """
    Custom structlog logger that sends every event through both chains.
    One chain filters + prettifies for console; the other writes full JSON to file.
    """

    def __init__(self, console_processors, file_processors, file_writer, console_writer):
        self._cp = console_processors
        self._fp = file_processors
        self._fw = file_writer
        self._cw = console_writer

    def _emit(self, method: str, event: str, **kw) -> None:
        event_dict = {"event": event, "level": method, **kw}

        # File: always write full JSON
        try:
            d = dict(event_dict)
            for proc in self._fp:
                d = proc(self, method, d)
            if isinstance(d, str):
                self._fw.msg(d)
        except structlog.DropEvent:
            pass
        except Exception:
            pass

        # Console: filter + pretty-print
        try:
            d = dict(event_dict)
            for proc in self._cp:
                d = proc(self, method, d)
            if isinstance(d, str):
                self._cw.msg(d)
        except structlog.DropEvent:
            pass
        except Exception:
            pass

    def msg(self, event="", **kw):    self._emit("info",     event, **kw)
    def debug(self, event="", **kw):  self._emit("debug",    event, **kw)
    def info(self, event="", **kw):   self._emit("info",     event, **kw)
    def warning(self, event="", **kw):self._emit("warning",  event, **kw)
    def warn(self, event="", **kw):   self._emit("warning",  event, **kw)
    def error(self, event="", **kw):  self._emit("error",    event, **kw)
    def critical(self, event="", **kw):self._emit("critical",event, **kw)
    log = msg


# ─── Public API (unchanged for the rest of the codebase) ──────────────────────

def get_logger(name: str, **kwargs: Any) -> Any:
    """Get a structured logger with optional context binding."""
    logger = structlog.get_logger(name)
    if kwargs:
        logger = logger.bind(**kwargs)
    return logger


class AgentLogger:
    """Context-aware logger for agents."""

    def __init__(self, agent_id: str, agent_name: str) -> None:
        self.logger = structlog.get_logger("agent").bind(
            agent_id=agent_id,
            agent_name=agent_name,
        )

    def info(self, event: str, **kwargs: Any) -> None:
        self.logger.info(event, **kwargs)

    def warning(self, event: str, **kwargs: Any) -> None:
        self.logger.warning(event, **kwargs)

    def error(self, event: str, **kwargs: Any) -> None:
        self.logger.error(event, **kwargs)

    def debug(self, event: str, **kwargs: Any) -> None:
        self.logger.debug(event, **kwargs)

    def bind(self, **kwargs: Any) -> "AgentLogger":
        self.logger = self.logger.bind(**kwargs)
        return self
