"""
MUSTAFA OS - Message Bus
Redis pub/sub messaging for agent communication with reliability guarantees.
"""

from __future__ import annotations

import asyncio
import json
import uuid
from datetime import datetime
from enum import Enum
from typing import Any, Callable, Dict, List, Optional, Set

import redis.asyncio as aioredis
from pydantic import BaseModel, Field

from core.settings import settings
from core.logging_config import get_logger

logger = get_logger("message_bus")


class MessagePriority(int, Enum):
    LOW = 1
    NORMAL = 5
    HIGH = 8
    CRITICAL = 10


class AgentMessage(BaseModel):
    """Structured inter-agent message."""

    message_id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    sender: str
    recipient: str  # "broadcast" for all agents
    message_type: str  # task_assign, task_complete, task_failed, heartbeat, etc.
    payload: Dict[str, Any] = Field(default_factory=dict)
    priority: MessagePriority = MessagePriority.NORMAL
    timestamp: str = Field(default_factory=lambda: datetime.utcnow().isoformat())
    correlation_id: Optional[str] = None  # For request-response tracking
    ttl_seconds: int = 300

    def to_json(self) -> str:
        return self.model_dump_json()

    @classmethod
    def from_json(cls, data: str) -> "AgentMessage":
        return cls.model_validate_json(data)


class MessageBus:
    """
    Redis-backed async message bus with pub/sub and queue support.
    Provides reliable message delivery between agents.
    """

    CHANNEL_PREFIX = "mustafa_os:channel:"
    QUEUE_PREFIX = "mustafa_os:queue:"
    BROADCAST_CHANNEL = "mustafa_os:broadcast"
    DEAD_LETTER_QUEUE = "mustafa_os:dead_letter"

    def __init__(self) -> None:
        self._redis: Optional[aioredis.Redis] = None
        self._pubsub: Optional[aioredis.client.PubSub] = None
        self._subscribers: Dict[str, List[Callable]] = {}
        self._running = False
        self._listener_task: Optional[asyncio.Task] = None
        self._subscribed_channels: Set[str] = set()

    async def connect(self) -> None:
        """Establish Redis connection."""
        redis_kwargs = {
            "host": settings.redis_host,
            "port": settings.redis_port,
            "db": settings.redis_db,
            "decode_responses": True,
            "socket_keepalive": True,
            "socket_connect_timeout": 5,
            "retry_on_timeout": True,
        }
        if settings.redis_password:
            redis_kwargs["password"] = settings.redis_password

        self._redis = aioredis.Redis(**redis_kwargs)
        await self._redis.ping()
        self._pubsub = self._redis.pubsub()
        self._running = True
        logger.info("message_bus_connected", host=settings.redis_host)

    async def disconnect(self) -> None:
        """Gracefully disconnect."""
        self._running = False
        if self._listener_task:
            self._listener_task.cancel()
            try:
                await self._listener_task
            except asyncio.CancelledError:
                pass
        if self._pubsub:
            await self._pubsub.close()
        if self._redis:
            await self._redis.aclose()
        logger.info("message_bus_disconnected")

    async def publish(self, message: AgentMessage) -> None:
        """Publish a message to the appropriate channel."""
        if not self._redis:
            raise RuntimeError("Message bus not connected")

        channel = (
            self.BROADCAST_CHANNEL
            if message.recipient == "broadcast"
            else f"{self.CHANNEL_PREFIX}{message.recipient}"
        )

        try:
            await self._redis.publish(channel, message.to_json())
            logger.debug(
                "message_published",
                message_id=message.message_id,
                sender=message.sender,
                recipient=message.recipient,
                message_type=message.message_type,
            )
        except Exception as e:
            logger.error("message_publish_failed", error=str(e), message_id=message.message_id)
            raise

    async def enqueue(self, agent_id: str, message: AgentMessage) -> None:
        """Enqueue a message for reliable delivery (survives disconnects)."""
        if not self._redis:
            raise RuntimeError("Message bus not connected")

        queue_key = f"{self.QUEUE_PREFIX}{agent_id}"
        await self._redis.lpush(queue_key, message.to_json())
        await self._redis.expire(queue_key, message.ttl_seconds)

    async def dequeue(self, agent_id: str, timeout: int = 1) -> Optional[AgentMessage]:
        """Dequeue the next message for an agent."""
        if not self._redis:
            raise RuntimeError("Message bus not connected")

        queue_key = f"{self.QUEUE_PREFIX}{agent_id}"
        result = await self._redis.brpop(queue_key, timeout=timeout)

        if result:
            _, data = result
            try:
                return AgentMessage.from_json(data)
            except Exception as e:
                logger.error("message_deserialize_failed", error=str(e))
                await self._redis.lpush(self.DEAD_LETTER_QUEUE, data)
        return None

    async def subscribe(self, agent_id: str, callback: Callable) -> None:
        """Subscribe an agent to its channel and broadcast."""
        channels = [
            f"{self.CHANNEL_PREFIX}{agent_id}",
            self.BROADCAST_CHANNEL,
        ]

        for channel in channels:
            if channel not in self._subscribed_channels:
                self._subscribers.setdefault(channel, [])

            if callback not in self._subscribers.get(channel, []):
                self._subscribers.setdefault(channel, []).append(callback)

        if self._pubsub:
            await self._pubsub.subscribe(*[
                c for c in channels if c not in self._subscribed_channels
            ])
            self._subscribed_channels.update(channels)

        # Start listener if not running
        if not self._listener_task or self._listener_task.done():
            self._listener_task = asyncio.create_task(self._listen_loop())

        logger.debug("agent_subscribed", agent_id=agent_id)

    async def _listen_loop(self) -> None:
        """Background loop to process incoming messages."""
        if not self._pubsub:
            return

        while self._running:
            try:
                message = await self._pubsub.get_message(
                    ignore_subscribe_messages=True, timeout=0.1
                )
                if message and message["type"] == "message":
                    channel = message["channel"]
                    data = message["data"]
                    await self._dispatch(channel, data)
            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.error("listener_loop_error", error=str(e))
                await asyncio.sleep(1)

    async def _dispatch(self, channel: str, data: str) -> None:
        """Dispatch message to all subscribers for a channel."""
        callbacks = self._subscribers.get(channel, [])
        if not callbacks:
            return

        try:
            message = AgentMessage.from_json(data)
        except Exception as e:
            logger.error("message_parse_failed", channel=channel, error=str(e))
            return

        for callback in callbacks:
            try:
                if asyncio.iscoroutinefunction(callback):
                    await callback(message)
                else:
                    callback(message)
            except Exception as e:
                logger.error("message_callback_failed", error=str(e), channel=channel)

    async def send_task(
        self,
        sender: str,
        recipient: str,
        task_type: str,
        payload: Dict[str, Any],
        priority: MessagePriority = MessagePriority.NORMAL,
    ) -> str:
        """Convenience method to send a task message."""
        correlation_id = str(uuid.uuid4())
        msg = AgentMessage(
            sender=sender,
            recipient=recipient,
            message_type=task_type,
            payload=payload,
            priority=priority,
            correlation_id=correlation_id,
        )
        await self.enqueue(recipient, msg)
        return correlation_id

    async def get_queue_length(self, agent_id: str) -> int:
        """Get number of pending messages for an agent."""
        if not self._redis:
            return 0
        return await self._redis.llen(f"{self.QUEUE_PREFIX}{agent_id}")

    async def set_value(self, key: str, value: Any, ttl: int = 3600) -> None:
        """Generic key-value storage in Redis."""
        if not self._redis:
            raise RuntimeError("Message bus not connected")
        serialized = json.dumps(value)
        await self._redis.set(f"mustafa_os:kv:{key}", serialized, ex=ttl)

    async def get_value(self, key: str) -> Optional[Any]:
        """Generic key-value retrieval from Redis."""
        if not self._redis:
            return None
        data = await self._redis.get(f"mustafa_os:kv:{key}")
        if data:
            return json.loads(data)
        return None

    async def delete_value(self, key: str) -> None:
        """Delete a key from Redis."""
        if not self._redis:
            return
        await self._redis.delete(f"mustafa_os:kv:{key}")

    async def health_check(self) -> bool:
        """Check if Redis is reachable."""
        try:
            if not self._redis:
                return False
            await self._redis.ping()
            return True
        except Exception:
            return False


# Global singleton
message_bus = MessageBus()
