"""
MUSTAFA OS - Structured JSON Logger
All logs are machine-readable JSON for observability pipelines.
"""
from __future__ import annotations

import json
import logging
import os
import sys
import traceback
from datetime import datetime, timezone
from logging.handlers import RotatingFileHandler
from pathlib import Path
from typing import Any, Dict, Optional

_loggers: Dict[str, "MustafaLogger"] = {}


class JSONFormatter(logging.Formatter):
    """Format log records as clean JSON lines."""

    def format(self, record: logging.LogRecord) -> str:
        log_entry: Dict[str, Any] = {
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "level": record.levelname,
            "logger": record.name,
            "message": record.getMessage(),
            "module": record.module,
            "function": record.funcName,
            "line": record.lineno,
        }

        # Add extra fields if present
        for key in ("agent", "task_id", "tool", "duration_ms", "trace_id"):
            if hasattr(record, key):
                log_entry[key] = getattr(record, key)

        # Add exception info
        if record.exc_info:
            log_entry["exception"] = {
                "type": record.exc_info[0].__name__ if record.exc_info[0] else None,
                "message": str(record.exc_info[1]),
                "traceback": traceback.format_exception(*record.exc_info),
            }

        # Add any extra dict fields
        if hasattr(record, "extra_data"):
            log_entry["data"] = record.extra_data

        return json.dumps(log_entry, default=str, ensure_ascii=False)


class MustafaLogger:
    """Wrapper providing structured logging with context injection."""

    def __init__(self, name: str, log_file: Optional[str] = None, level: str = "INFO"):
        self._logger = logging.getLogger(name)
        self._logger.setLevel(getattr(logging, level.upper(), logging.INFO))
        self._context: Dict[str, Any] = {}

        if not self._logger.handlers:
            formatter = JSONFormatter()

            # Console handler — stderr so it doesn't mix with CLI stdout output.
            # Set MUSTAFA_LOG_CONSOLE=0 to suppress console logs entirely (e.g. in CLI mode).
            if os.environ.get("MUSTAFA_LOG_CONSOLE", "1") != "0":
                console_handler = logging.StreamHandler(sys.stderr)
                console_handler.setFormatter(formatter)
                self._logger.addHandler(console_handler)

            # File handler (always active when log_file is provided)
            if log_file:
                log_path = Path(log_file)
                log_path.parent.mkdir(parents=True, exist_ok=True)
                file_handler = RotatingFileHandler(
                    log_file,
                    maxBytes=52_428_800,  # 50MB
                    backupCount=10,
                    encoding="utf-8",
                )
                file_handler.setFormatter(formatter)
                self._logger.addHandler(file_handler)

        self._logger.propagate = False

    def bind(self, **kwargs: Any) -> "MustafaLogger":
        """Return a new logger with bound context fields."""
        new_logger = MustafaLogger.__new__(MustafaLogger)
        new_logger._logger = self._logger
        new_logger._context = {**self._context, **kwargs}
        return new_logger

    # Fields that Python's logging.LogRecord reserves — passing these as extras crashes
    _RESERVED_LOG_FIELDS = frozenset({
        "message", "msg", "args", "created", "filename", "funcName",
        "levelname", "levelno", "lineno", "module", "msecs", "name",
        "pathname", "process", "processName", "relativeCreated",
        "thread", "threadName", "exc_info", "exc_text", "stack_info", "taskName",
    })

    def _log(self, level: int, msg: str, **kwargs: Any) -> None:
        extra: Dict[str, Any] = {**self._context, **kwargs}
        extra_data = extra.pop("data", None)
        # Rename any key that collides with a reserved LogRecord field
        record_extra: Dict[str, Any] = {}
        for k, v in extra.items():
            safe_key = f"field_{k}" if k in self._RESERVED_LOG_FIELDS else k
            record_extra[safe_key] = v
        if extra_data:
            record_extra["extra_data"] = extra_data
        self._logger.log(level, msg, extra=record_extra, stacklevel=3)

    def debug(self, msg: str, **kwargs: Any) -> None:
        self._log(logging.DEBUG, msg, **kwargs)

    def info(self, msg: str, **kwargs: Any) -> None:
        self._log(logging.INFO, msg, **kwargs)

    def warning(self, msg: str, **kwargs: Any) -> None:
        self._log(logging.WARNING, msg, **kwargs)

    def error(self, msg: str, **kwargs: Any) -> None:
        self._log(logging.ERROR, msg, **kwargs)

    def critical(self, msg: str, **kwargs: Any) -> None:
        self._log(logging.CRITICAL, msg, **kwargs)


def get_logger(name: str, log_file: Optional[str] = "logs/mustafa_os.jsonl", level: str = "INFO") -> MustafaLogger:
    """Get or create a named logger."""
    if name not in _loggers:
        Path("logs").mkdir(exist_ok=True)
        _loggers[name] = MustafaLogger(name, log_file=log_file, level=level)
    return _loggers[name]
