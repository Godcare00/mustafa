"""
MUSTAFA OS - Agent Registry
Central registry for tracking all agents, their status, and capabilities.
"""

from __future__ import annotations

import asyncio
from datetime import datetime
from typing import Dict, List, Optional, Type

from core.logging_config import get_logger
from core.messaging import message_bus

logger = get_logger("agent_registry")


class AgentStatus:
    INITIALIZING = "initializing"
    IDLE = "idle"
    BUSY = "busy"
    ERROR = "error"
    STOPPED = "stopped"


class AgentInfo:
    """Runtime information about a registered agent."""

    def __init__(
        self,
        agent_id: str,
        name: str,
        capabilities: List[str],
        instance: Optional[object] = None,
    ) -> None:
        self.agent_id = agent_id
        self.name = name
        self.capabilities = capabilities
        self.instance = instance
        self.status = AgentStatus.INITIALIZING
        self.current_task: Optional[str] = None
        self.task_count = 0
        self.success_count = 0
        self.failure_count = 0
        self.last_heartbeat = datetime.utcnow()
        self.created_at = datetime.utcnow()
        self.error_message: Optional[str] = None

    @property
    def success_rate(self) -> float:
        if self.task_count == 0:
            return 1.0
        return self.success_count / self.task_count

    def to_dict(self) -> dict:
        return {
            "agent_id": self.agent_id,
            "name": self.name,
            "capabilities": self.capabilities,
            "status": self.status,
            "current_task": self.current_task,
            "task_count": self.task_count,
            "success_count": self.success_count,
            "failure_count": self.failure_count,
            "success_rate": round(self.success_rate, 3),
            "last_heartbeat": self.last_heartbeat.isoformat(),
            "created_at": self.created_at.isoformat(),
            "error_message": self.error_message,
        }


class AgentRegistry:
    """
    Central registry for all MUSTAFA OS agents.
    Provides discovery, status tracking, and load balancing.
    """

    def __init__(self) -> None:
        self._agents: Dict[str, AgentInfo] = {}
        self._lock = asyncio.Lock()

    async def register(
        self,
        agent_id: str,
        name: str,
        capabilities: List[str],
        instance: Optional[object] = None,
    ) -> AgentInfo:
        """Register a new agent."""
        async with self._lock:
            if agent_id in self._agents:
                logger.warning("agent_already_registered", agent_id=agent_id)
                return self._agents[agent_id]

            info = AgentInfo(
                agent_id=agent_id,
                name=name,
                capabilities=capabilities,
                instance=instance,
            )
            self._agents[agent_id] = info
            logger.info("agent_registered", agent_id=agent_id, name=name, capabilities=capabilities)
            return info

    async def unregister(self, agent_id: str) -> None:
        """Remove an agent from the registry."""
        async with self._lock:
            if agent_id in self._agents:
                del self._agents[agent_id]
                logger.info("agent_unregistered", agent_id=agent_id)

    async def update_status(
        self,
        agent_id: str,
        status: str,
        current_task: Optional[str] = None,
        error_message: Optional[str] = None,
    ) -> None:
        """Update agent status."""
        async with self._lock:
            if agent_id not in self._agents:
                return
            agent = self._agents[agent_id]
            agent.status = status
            agent.last_heartbeat = datetime.utcnow()
            if current_task is not None:
                agent.current_task = current_task
            if error_message is not None:
                agent.error_message = error_message

    async def record_task_result(
        self, agent_id: str, success: bool
    ) -> None:
        """Record a task completion result for an agent."""
        async with self._lock:
            if agent_id not in self._agents:
                return
            agent = self._agents[agent_id]
            agent.task_count += 1
            if success:
                agent.success_count += 1
            else:
                agent.failure_count += 1
            agent.current_task = None

    async def heartbeat(self, agent_id: str) -> None:
        """Update agent heartbeat timestamp."""
        async with self._lock:
            if agent_id in self._agents:
                self._agents[agent_id].last_heartbeat = datetime.utcnow()

    def get_agent(self, agent_id: str) -> Optional[AgentInfo]:
        """Get agent info by ID."""
        return self._agents.get(agent_id)

    def get_all_agents(self) -> List[AgentInfo]:
        """Get all registered agents."""
        return list(self._agents.values())

    def get_agents_by_capability(self, capability: str) -> List[AgentInfo]:
        """Find agents with a specific capability."""
        return [
            agent for agent in self._agents.values()
            if capability in agent.capabilities
        ]

    def get_idle_agent(self, capability: Optional[str] = None) -> Optional[AgentInfo]:
        """Find an available idle agent, optionally filtering by capability."""
        candidates = [
            agent for agent in self._agents.values()
            if agent.status == AgentStatus.IDLE
        ]
        if capability:
            candidates = [a for a in candidates if capability in a.capabilities]

        if not candidates:
            return None

        # Return agent with highest success rate (load balance by quality)
        return max(candidates, key=lambda a: a.success_rate)

    def get_system_summary(self) -> dict:
        """Get a high-level system summary."""
        all_agents = list(self._agents.values())
        return {
            "total_agents": len(all_agents),
            "idle": sum(1 for a in all_agents if a.status == AgentStatus.IDLE),
            "busy": sum(1 for a in all_agents if a.status == AgentStatus.BUSY),
            "error": sum(1 for a in all_agents if a.status == AgentStatus.ERROR),
            "stopped": sum(1 for a in all_agents if a.status == AgentStatus.STOPPED),
            "total_tasks_completed": sum(a.task_count for a in all_agents),
            "overall_success_rate": (
                sum(a.success_count for a in all_agents) /
                max(sum(a.task_count for a in all_agents), 1)
            ),
        }


# Global singleton
agent_registry = AgentRegistry()
