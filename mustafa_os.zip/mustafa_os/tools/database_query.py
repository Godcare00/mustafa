"""
MUSTAFA OS - Database Query Tool
Read-only SQL query execution against PostgreSQL.
"""
from __future__ import annotations
from typing import Any, Dict, List, Optional
from tools.base import BaseTool, ToolResult


class DatabaseQueryTool(BaseTool):
    name = "database_query"
    description = "Execute read-only SQL SELECT queries against the database"
    permissions = ["database.read"]
    timeout = 30

    ALLOWED_STARTS = ("SELECT", "WITH", "EXPLAIN")

    async def execute(self, params: Dict[str, Any]) -> ToolResult:
        query = params.get("query", "").strip()
        query_params = params.get("params", {})

        if not query:
            return ToolResult(success=False, error="query is required")

        # Safety: only allow SELECT statements
        upper = query.upper().lstrip()
        if not any(upper.startswith(start) for start in self.ALLOWED_STARTS):
            return ToolResult(
                success=False,
                error=f"Only SELECT/WITH/EXPLAIN queries allowed. Got: {query[:50]}"
            )

        try:
            from core.database import async_session_factory
            from sqlalchemy import text

            async with async_session_factory() as session:
                result = await session.execute(text(query), query_params)
                rows = [dict(row._mapping) for row in result]

            return ToolResult(
                success=True,
                data={"rows": rows, "count": len(rows)}
            )
        except Exception as e:
            return ToolResult(success=False, error=f"Query failed: {e}")

    async def validate_params(self, params: Dict[str, Any]) -> Optional[str]:
        if not params.get("query"):
            return "query is required"
        return None
