#!/usr/bin/env bash
# ============================================================
# MUSTAFA OS - Automated Setup Script
# ============================================================

set -euo pipefail

RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; CYAN='\033[0;36m'; BOLD='\033[1m'; NC='\033[0m'

log()    { echo -e "${CYAN}[MUSTAFA OS]${NC} $1"; }
success(){ echo -e "${GREEN}[✓]${NC} $1"; }
warn()   { echo -e "${YELLOW}[!]${NC} $1"; }
error()  { echo -e "${RED}[✗]${NC} $1"; exit 1; }

echo -e "${BOLD}${CYAN}"
echo "╔═══════════════════════════════════════════════════════════╗"
echo "║              MUSTAFA OS - Setup Script                    ║"
echo "║   Modular Unified System for Task Automation &            ║"
echo "║                Autonomous Intelligence                    ║"
echo "╚═══════════════════════════════════════════════════════════╝"
echo -e "${NC}"

# ─── 1. Check Prerequisites ───────────────────────────────────
log "Checking prerequisites..."

command -v python3 >/dev/null 2>&1 || error "Python 3 is required. Install from https://python.org"
PYTHON_VER=$(python3 --version | awk '{print $2}')
PY_MAJOR=$(echo $PYTHON_VER | cut -d. -f1)
PY_MINOR=$(echo $PYTHON_VER | cut -d. -f2)
if [[ $PY_MAJOR -lt 3 || ($PY_MAJOR -eq 3 && $PY_MINOR -lt 10) ]]; then
    error "Python 3.10+ required. You have $PYTHON_VER"
fi
success "Python $PYTHON_VER OK"

# ─── 2. Setup Virtual Environment ────────────────────────────
log "Setting up Python virtual environment..."

if [ ! -d "venv" ]; then
    python3 -m venv venv
    success "Virtual environment created"
else
    warn "Virtual environment already exists, reusing"
fi

source venv/bin/activate
pip install --upgrade pip --quiet
success "Virtual environment activated"

# ─── 3. Install Python Dependencies ──────────────────────────
log "Installing Python dependencies (this may take a few minutes)..."
echo "$(date)"

pip install -r requirements.txt --quiet \
    || { warn "Some packages failed; trying one by one..."
         while IFS= read -r line; do
             [[ "$line" =~ ^#.*$ || -z "$line" ]] && continue
             pip install "$line" --quiet 2>/dev/null || warn "Could not install: $line"
         done < requirements.txt; }

success "Python dependencies installed"

# ─── 4. Install & Start Redis ────────────────────────────────
log "Checking Redis..."

if ! command -v redis-server >/dev/null 2>&1; then
    log "Redis not found. Attempting to install..."
    if command -v apt-get >/dev/null 2>&1; then
        sudo apt-get update -qq && sudo apt-get install -y redis-server
    elif command -v brew >/dev/null 2>&1; then
        brew install redis
    elif command -v yum >/dev/null 2>&1; then
        sudo yum install -y redis
    else
        warn "Could not auto-install Redis. Please install manually: https://redis.io/download"
        warn "Then run: redis-server --daemonize yes"
    fi
fi

if command -v redis-server >/dev/null 2>&1; then
    if ! redis-cli ping >/dev/null 2>&1; then
        log "Starting Redis..."
        redis-server --daemonize yes --logfile ./logs/redis.log
        sleep 1
    fi
    redis-cli ping >/dev/null 2>&1 && success "Redis is running" || warn "Redis may not have started. Check logs/redis.log"
fi

# ─── 5. Configure Environment Variables ──────────────────────
log "Configuring environment..."

if [ ! -f ".env" ]; then
    cp .env.example .env
    success ".env file created from template"

    echo ""
    echo -e "${YELLOW}╔══════════════════════════════════════════════════╗${NC}"
    echo -e "${YELLOW}║  ACTION REQUIRED: Configure your API keys         ║${NC}"
    echo -e "${YELLOW}╚══════════════════════════════════════════════════╝${NC}"
    echo ""

    read -r -p "Enter your OpenRouter API key (or press Enter to skip): " OR_KEY
    if [ -n "$OR_KEY" ]; then
        sed -i "s|your_openrouter_api_key_here|$OR_KEY|g" .env
        success "OpenRouter API key configured"
    else
        warn "No API key provided. Set OPENROUTER_API_KEY in .env later"
    fi

    read -r -p "Enter Telegram bot token (or press Enter to skip): " TG_TOKEN
    if [ -n "$TG_TOKEN" ]; then
        sed -i "s|your_telegram_bot_token_here|$TG_TOKEN|g" .env
        success "Telegram bot token configured"
        read -r -p "Enter authorized Telegram user IDs (comma-separated): " TG_USERS
        if [ -n "$TG_USERS" ]; then
            sed -i "s|123456789,987654321|$TG_USERS|g" .env
            success "Telegram authorized users configured"
        fi
    fi

    SECRET_KEY=$(python3 -c "import secrets; print(secrets.token_urlsafe(64))")
    sed -i "s|your_very_long_random_secret_key_here|$SECRET_KEY|g" .env
    success "API secret key generated"
else
    warn ".env file already exists, skipping configuration"
fi

# ─── 6. Create Directory Structure ───────────────────────────
log "Creating directory structure..."

mkdir -p data/generated data/chroma logs experiments plugins data/task_outputs

touch agents/__init__.py tools/__init__.py memory/__init__.py \
      api/__init__.py cli/__init__.py telegram_bot/__init__.py \
      orchestration/__init__.py monitoring/__init__.py tests/__init__.py \
      core/__init__.py 2>/dev/null || true

success "Directories created"

# ─── 7. Initialize SQLite Database ───────────────────────────
log "Initializing SQLite database..."

python3 -c "
import asyncio, sys
sys.path.insert(0, '.')
async def init():
    try:
        from core.database import init_db
        await init_db()
        print('SQLite database initialized at ./data/mustafa_os.db')
    except Exception as e:
        print(f'Database init failed: {e}')
asyncio.run(init())
" 2>/dev/null && success "SQLite database ready" || warn "Database init failed — will retry on first run"

# ─── 8. Run System Health Test ────────────────────────────────
log "Running system health check..."

python3 -c "
import asyncio, sys
sys.path.insert(0, '.')
async def health_check():
    results = {'settings': False, 'redis': False, 'sqlite': False, 'tools': False}

    try:
        from core.settings import get_settings
        s = get_settings()
        assert s.system_name == 'MUSTAFA_OS'
        results['settings'] = True
    except Exception as e:
        print(f'Settings check failed: {e}')

    try:
        from core.messaging import MessageBus
        bus = MessageBus()
        await bus.connect()
        ok = await bus.health_check()
        await bus.disconnect()
        results['redis'] = ok
    except Exception as e:
        print(f'Redis check failed: {e}')

    try:
        from core.database import init_db, engine
        await init_db()
        results['sqlite'] = True
    except Exception as e:
        print(f'SQLite check failed: {e}')

    try:
        from tools.base import ToolExecutionEngine, BaseTool, ToolResult
        class TestTool(BaseTool):
            name = 'test'; description = 'test'; permissions = []
            async def execute(self, params): return ToolResult(success=True, data={})
        engine = ToolExecutionEngine()
        engine.register(TestTool())
        engine.set_agent_permissions('tester', ['test'])
        r = await engine.execute('test', 'tester', {})
        results['tools'] = r.success
    except Exception as e:
        print(f'Tools check failed: {e}')

    print('Health check results:')
    for k, v in results.items():
        print(f'  {chr(10003) if v else chr(10007)} {k}: {\"ok\" if v else \"failed\"}')
    return all(results.values())

result = asyncio.run(health_check())
sys.exit(0 if result else 1)
" && success "Health checks passed" || warn "Some health checks failed (check .env configuration)"

# ─── 9. Run Unit Tests ───────────────────────────────────────
log "Running unit tests..."

python3 -m pytest tests/test_core.py -v --tb=short -x \
    -k "not TestSettings" 2>/dev/null \
    && success "Unit tests passed" \
    || warn "Some tests failed (may require Redis)"

# ─── Done ─────────────────────────────────────────────────────
echo ""
echo -e "${GREEN}${BOLD}╔═══════════════════════════════════════════════════════════╗${NC}"
echo -e "${GREEN}${BOLD}║           MUSTAFA OS Setup Complete!                      ║${NC}"
echo -e "${GREEN}${BOLD}╚═══════════════════════════════════════════════════════════╝${NC}"
echo ""
echo -e "${BOLD}Next steps:${NC}"
echo ""
echo -e "  1. ${CYAN}Edit .env${NC} with your API keys (OpenRouter, Telegram)"
echo -e "  2. ${CYAN}Start interactive CLI:${NC}  python main.py chat"
echo -e "  3. ${CYAN}Start API server:${NC}       python main.py server"
echo -e "  4. ${CYAN}Run a single goal:${NC}      python main.py run \"Your goal here\""
echo -e "  5. ${CYAN}Start full system:${NC}      python main.py"
echo ""
echo -e "${BOLD}API endpoints:${NC}"
echo -e "  • ${CYAN}http://localhost:8000/health${NC}  — System health"
echo -e "  • ${CYAN}http://localhost:8000/metrics${NC} — Metrics"
echo -e "  • ${CYAN}http://localhost:8000/agents${NC}  — Agent status"
echo -e "  • ${CYAN}http://localhost:8000/docs${NC}    — API docs (dev mode)"
echo ""
echo -e "Database: ${CYAN}./data/mustafa_os.db${NC} (SQLite — no server needed)"
echo -e "Logs:     ${CYAN}./logs/${NC}"
echo ""
