"""
MUSTAFA OS - Main Entry Point

Usage:
  python main.py                  # Full system, essential logs on console
  python main.py --logs           # Full system, ALL logs on console (verbose)
  python main.py --no-logs        # Full system, no console output (file only)
  python main.py chat             # Interactive CLI, essential logs
  python main.py chat --logs      # Interactive CLI, verbose logs
  python main.py chat --no-logs   # Interactive CLI, silent
  python main.py server           # API server only
  python main.py run <goal>       # One-shot goal execution
  python main.py worker           # Celery worker
"""

from __future__ import annotations

import asyncio
import sys

import uvicorn

from core.logging_config import configure_logging
from core.settings import settings


def _parse_log_flag() -> str:
    """
    Parse --logs / --no-logs from argv and return the console_mode string.
    Removes the flag from sys.argv so subcommand parsing is unaffected.

    Returns:
      "essential"  — default: only key events shown on console (file gets all)
      "verbose"    — --logs: everything shown on console AND file
      "silent"     — --no-logs: nothing on console, file only
    """
    if "--logs" in sys.argv:
        sys.argv.remove("--logs")
        return "verbose"
    if "--no-logs" in sys.argv:
        sys.argv.remove("--no-logs")
        return "silent"
    return "essential"


async def run_system(console_mode: str = "essential") -> None:
    """Boot kernel, start Telegram bot, then serve the API."""
    configure_logging(settings.log_level, settings.log_format, console_mode=console_mode)

    from telegram_bot.bot import telegram_bot
    from core.kernel import kernel

    await kernel.boot()
    await telegram_bot.start(kernel)

    config = uvicorn.Config(
        "api.app:app",
        host=settings.api_host,
        port=settings.api_port,
        log_level=settings.log_level.lower(),
        access_log=False,  # HTTP access logs go to file only
    )
    server = uvicorn.Server(config)

    try:
        await server.serve()
    finally:
        await telegram_bot.stop()
        if kernel.is_running:
            await kernel.shutdown()


def main() -> None:
    """Main entry point with --logs / --no-logs support on all subcommands."""
    console_mode = _parse_log_flag()

    if len(sys.argv) > 1:
        cmd = sys.argv[1]

        if cmd == "chat":
            configure_logging(settings.log_level, settings.log_format, console_mode=console_mode)
            from cli.interface import MustafaOSCLI
            interface = MustafaOSCLI()
            asyncio.run(interface.start())

        elif cmd == "server":
            configure_logging(settings.log_level, settings.log_format, console_mode=console_mode)
            from api.app import app
            uvicorn.run(
                app,
                host=settings.api_host,
                port=settings.api_port,
                log_level=settings.log_level.lower(),
                access_log=console_mode == "verbose",
            )

        elif cmd == "run" and len(sys.argv) > 2:
            configure_logging(settings.log_level, settings.log_format, console_mode=console_mode)
            goal = " ".join(sys.argv[2:])
            from cli.interface import cli
            sys.argv = ["mustafa", "run", goal]
            cli()

        elif cmd == "worker":
            from orchestration.celery_app import celery_app
            celery_app.worker_main(["worker", "--loglevel=info"])

        else:
            print(f"Unknown command: {cmd}")
            print(
                "Usage:\n"
                "  python main.py [--logs|--no-logs]          Full system\n"
                "  python main.py chat [--logs|--no-logs]     Interactive CLI\n"
                "  python main.py server [--logs|--no-logs]   API server only\n"
                "  python main.py run <goal> [--logs]         Single goal\n"
                "  python main.py worker                      Celery worker\n"
            )
            sys.exit(1)
    else:
        asyncio.run(run_system(console_mode=console_mode))


if __name__ == "__main__":
    main()
