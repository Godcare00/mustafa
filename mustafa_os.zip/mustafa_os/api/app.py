"""
MUSTAFA OS - FastAPI Application
Production REST API with health checks, metrics, agent control, and task management.
"""

from __future__ import annotations

import asyncio
import uuid
from contextlib import asynccontextmanager
from datetime import datetime
from typing import Any, Dict, List, Optional

from fastapi import BackgroundTasks, FastAPI, HTTPException, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field

from core.kernel import kernel
from core.logging_config import get_logger
from core.messaging import AgentMessage, MessagePriority, message_bus
from core.registry import agent_registry
from core.reliability import get_all_circuit_breaker_stats
from core.settings import settings

logger = get_logger("api")

# ─── Request/Response Models ──────────────────────────────────────────────────

class GoalRequest(BaseModel):
    goal: str = Field(..., min_length=1, max_length=10000, description="The goal to execute")
    priority: int = Field(default=5, ge=1, le=10)
    async_mode: bool = Field(default=False, description="Return immediately with task_id")
    session_id: Optional[str] = None


class TaskResponse(BaseModel):
    task_id: str
    status: str
    result: Optional[Any] = None
    error: Optional[str] = None
    created_at: str


class AgentMessageRequest(BaseModel):
    sender: str = "api"
    recipient: str
    message_type: str
    payload: Dict[str, Any] = Field(default_factory=dict)
    priority: int = Field(default=5, ge=1, le=10)


class ToolExecuteRequest(BaseModel):
    tool_name: str
    agent_id: str = "api"
    params: Dict[str, Any] = Field(default_factory=dict)


# ─── Active Tasks Store ───────────────────────────────────────────────────────

_active_tasks: Dict[str, Dict[str, Any]] = {}
_ws_connections: List[WebSocket] = []


# ─── Lifespan ─────────────────────────────────────────────────────────────────

@asynccontextmanager
async def lifespan(app: FastAPI):
    """Boot system on startup (if not already running), shutdown on exit."""
    already_running = kernel.is_running
    try:
        if not already_running:
            await kernel.boot()
        logger.info("api_ready", host=settings.api_host, port=settings.api_port)
        yield
    finally:
        if not already_running and kernel.is_running:
            await kernel.shutdown()


# ─── App Factory ──────────────────────────────────────────────────────────────

def create_app() -> FastAPI:
    app = FastAPI(
        title="MUSTAFA OS",
        description="Modular Unified System for Task Automation and Autonomous Intelligence",
        version=settings.system_version,
        lifespan=lifespan,
        docs_url="/docs" if not settings.is_production else None,
        redoc_url="/redoc" if not settings.is_production else None,
    )

    app.add_middleware(
        CORSMiddleware,
        allow_origins=["*"],
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    # ── Health & Status ──────────────────────────────────────────────────────

    @app.get("/health", tags=["system"])
    async def health_check():
        """System health endpoint for load balancers and monitors."""
        redis_ok = await message_bus.health_check()
        agents = agent_registry.get_system_summary()
        status = "healthy" if redis_ok and agents["total_agents"] > 0 else "degraded"

        return {
            "status": status,
            "timestamp": datetime.utcnow().isoformat(),
            "version": settings.system_version,
            "environment": settings.environment,
            "uptime_seconds": kernel.uptime_seconds,
            "components": {
                "redis": "ok" if redis_ok else "error",
                "agents": "ok" if agents["total_agents"] > 0 else "error",
                "llm": "configured" if settings.openrouter_api_key else "not_configured",
            },
        }

    @app.get("/metrics", tags=["system"])
    async def metrics():
        """Prometheus-style metrics endpoint."""
        from core.llm_client import llm_client
        agents = agent_registry.get_system_summary()
        llm_stats = llm_client.get_stats()

        return {
            "timestamp": datetime.utcnow().isoformat(),
            "uptime_seconds": kernel.uptime_seconds,
            "agents": agents,
            "llm": llm_stats,
            "circuit_breakers": get_all_circuit_breaker_stats(),
            "active_tasks": len(_active_tasks),
        }

    @app.get("/status", tags=["system"])
    async def system_status():
        """Full system status."""
        return kernel.get_status()

    # ── Goals & Tasks ────────────────────────────────────────────────────────

    @app.post("/goals", response_model=TaskResponse, tags=["tasks"])
    async def submit_goal(request: GoalRequest, background_tasks: BackgroundTasks):
        """
        Submit a goal to MUSTAFA OS for autonomous execution.
        
        In async_mode=False (default), waits for completion (up to 5 min).
        In async_mode=True, returns immediately with a task_id to poll.
        """
        task_id = str(uuid.uuid4())
        session_id = request.session_id or str(uuid.uuid4())

        _active_tasks[task_id] = {
            "task_id": task_id,
            "goal": request.goal,
            "status": "pending",
            "created_at": datetime.utcnow().isoformat(),
        }

        orchestrator = kernel.get_orchestrator()
        if not orchestrator:
            raise HTTPException(503, "Orchestrator agent not available")

        if request.async_mode:
            # Fire and forget
            background_tasks.add_task(
                _run_goal_task, task_id, request.goal, session_id
            )
            return TaskResponse(
                task_id=task_id,
                status="pending",
                created_at=_active_tasks[task_id]["created_at"],
            )
        else:
            # Synchronous wait
            result = await _run_goal_task(task_id, request.goal, session_id)
            task = _active_tasks.get(task_id, {})
            return TaskResponse(
                task_id=task_id,
                status=task.get("status", "unknown"),
                result=task.get("result"),
                error=task.get("error"),
                created_at=task.get("created_at", ""),
            )

    @app.get("/tasks/{task_id}", response_model=TaskResponse, tags=["tasks"])
    async def get_task(task_id: str):
        """Get task status and result."""
        task = _active_tasks.get(task_id)
        if not task:
            # Try database
            try:
                from core.database import TaskRecord, async_session_factory
                from sqlalchemy import select
                async with async_session_factory() as session:
                    result = await session.execute(
                        select(TaskRecord).where(TaskRecord.id == task_id)
                    )
                    db_task = result.scalar_one_or_none()
                    if db_task:
                        return TaskResponse(
                            task_id=db_task.id,
                            status=db_task.status,
                            result=db_task.result,
                            error=db_task.error,
                            created_at=db_task.created_at.isoformat(),
                        )
            except Exception:
                pass
            raise HTTPException(404, f"Task {task_id} not found")

        return TaskResponse(
            task_id=task_id,
            status=task["status"],
            result=task.get("result"),
            error=task.get("error"),
            created_at=task["created_at"],
        )

    @app.get("/tasks", tags=["tasks"])
    async def list_tasks(limit: int = 20):
        """List recent tasks."""
        tasks = list(_active_tasks.values())[-limit:]
        return {"tasks": tasks, "total": len(_active_tasks)}

    # ── Agents ───────────────────────────────────────────────────────────────

    @app.get("/agents", tags=["agents"])
    async def list_agents():
        """List all registered agents and their status."""
        agents = agent_registry.get_all_agents()
        return {
            "agents": [a.to_dict() for a in agents],
            "summary": agent_registry.get_system_summary(),
        }

    @app.get("/agents/{agent_id}", tags=["agents"])
    async def get_agent(agent_id: str):
        """Get details for a specific agent."""
        agent = agent_registry.get_agent(agent_id)
        if not agent:
            raise HTTPException(404, f"Agent {agent_id} not found")
        return agent.to_dict()

    @app.post("/agents/message", tags=["agents"])
    async def send_agent_message(request: AgentMessageRequest):
        """Send a direct message to an agent."""
        msg = AgentMessage(
            sender=request.sender,
            recipient=request.recipient,
            message_type=request.message_type,
            payload=request.payload,
            priority=MessagePriority(request.priority),
        )
        await message_bus.enqueue(request.recipient, msg)
        return {"sent": True, "message_id": msg.message_id}

    # ── Tools ────────────────────────────────────────────────────────────────

    @app.get("/tools", tags=["tools"])
    async def list_tools():
        """List all registered tools."""
        from tools import get_tool_engine
        engine = get_tool_engine()
        return {"tools": [t.to_dict() for t in engine.get_all_tools()]}

    @app.post("/tools/execute", tags=["tools"])
    async def execute_tool(request: ToolExecuteRequest):
        """Execute a tool directly via the API."""
        from tools import get_tool_engine
        engine = get_tool_engine()
        result = await engine.execute(
            tool_name=request.tool_name,
            agent_id=request.agent_id,
            params=request.params,
        )
        return result.to_dict()

    # ── Memory ───────────────────────────────────────────────────────────────

    @app.post("/memory/search", tags=["memory"])
    async def search_memory(query: str, collection: str = "general", top_k: int = 5):
        """Search the vector memory store."""
        from memory.long_term import LongTermMemory
        mem = LongTermMemory()
        # Note: in production this would use the shared instance
        results = await mem.search(query=query, collection=collection, top_k=top_k)
        return {"results": results, "query": query}

    # ── Self-Improvement ─────────────────────────────────────────────────────

    @app.post("/evolve", tags=["system"])
    async def trigger_evolution(background_tasks: BackgroundTasks):
        """Trigger a self-improvement evolution cycle."""
        evolution_agent = kernel.get_agent("evolution")
        if not evolution_agent:
            raise HTTPException(503, "Evolution agent not available")

        correlation_id = await message_bus.send_task(
            sender="api",
            recipient="evolution",
            task_type="run_evolution_cycle",
            payload={"triggered_by": "api"},
        )
        return {"triggered": True, "correlation_id": correlation_id}

    @app.get("/experiments", tags=["system"])
    async def list_experiments():
        """List self-improvement experiments."""
        evolution_agent = kernel.get_agent("evolution")
        if evolution_agent and hasattr(evolution_agent, "_experiments"):
            return {"experiments": evolution_agent._experiments}
        return {"experiments": []}

    # ── WebSocket ────────────────────────────────────────────────────────────

    @app.websocket("/ws")
    async def websocket_endpoint(websocket: WebSocket):
        """Real-time streaming connection for goal execution."""
        await websocket.accept()
        _ws_connections.append(websocket)
        try:
            while True:
                data = await websocket.receive_json()
                goal = data.get("goal", "")
                task_id = str(uuid.uuid4())

                await websocket.send_json({"type": "task_started", "task_id": task_id})

                result = await _run_goal_task(task_id, goal, task_id)
                task = _active_tasks.get(task_id, {})

                await websocket.send_json({
                    "type": "task_complete",
                    "task_id": task_id,
                    "status": task.get("status"),
                    "result": task.get("result"),
                })
        except WebSocketDisconnect:
            pass
        finally:
            if websocket in _ws_connections:
                _ws_connections.remove(websocket)

    return app


# ─── Background Task Runner ───────────────────────────────────────────────────

async def _run_goal_task(task_id: str, goal: str, session_id: str) -> None:
    """Execute a goal through the orchestrator."""
    _active_tasks[task_id]["status"] = "running"

    try:
        from agents.base import TaskContext
        orchestrator = kernel.get_orchestrator()
        if not orchestrator:
            raise RuntimeError("Orchestrator not available")

        context = TaskContext(
            task_id=task_id,
            goal=goal,
            payload={"goal": goal, "task_id": task_id, "session_id": session_id},
        )

        result = await orchestrator.handle_task("execute_goal", context)

        _active_tasks[task_id].update({
            "status": "completed" if result.success else "failed",
            "result": result.data,
            "error": result.error,
            "completed_at": datetime.utcnow().isoformat(),
        })

        # Notify WebSocket clients
        for ws in list(_ws_connections):
            try:
                await ws.send_json({
                    "type": "task_update",
                    "task_id": task_id,
                    "status": _active_tasks[task_id]["status"],
                })
            except Exception:
                pass

    except Exception as e:
        logger.error("goal_task_failed", task_id=task_id, error=str(e))
        _active_tasks[task_id].update({
            "status": "failed",
            "error": str(e),
            "completed_at": datetime.utcnow().isoformat(),
        })


# ─── App Instance ─────────────────────────────────────────────────────────────

app = create_app()
