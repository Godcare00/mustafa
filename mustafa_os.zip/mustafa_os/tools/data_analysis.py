"""
MUSTAFA OS - Data Analysis Tool
Re-exports DataAnalysisTool from the combined analysis_executor module.
"""
from tools.analysis_executor import DataAnalysisTool

__all__ = ["DataAnalysisTool"]
