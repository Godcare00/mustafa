"""
MUSTAFA OS - Memory Layer
Multi-tier memory: short-term (Redis), long-term (ChromaDB vector store), experiment memory (SQLite).
"""
from __future__ import annotations

import json
import time
import uuid
from dataclasses import dataclass
from typing import Any, Dict, List, Optional

from core.config import get_settings
from core.logger import get_logger

logger = get_logger("memory")


@dataclass
class Memory:
    """A single memory record."""
    id: str
    content: str
    memory_type: str
    metadata: Dict[str, Any]
    created_at: float
    relevance_score: float = 1.0


class ShortTermMemory:
    """
    Redis-backed short-term memory for active task context.
    TTL-based expiration, fast key-value access.
    """

    def __init__(self, redis_client: Any, ttl: int = 3600, max_items: int = 1000):
        self._redis = redis_client
        self._ttl = ttl
        self._max_items = max_items
        self._prefix = "mustafa:stm:"

    async def set(self, key: str, value: Any, ttl: Optional[int] = None) -> None:
        """Store a value in short-term memory."""
        try:
            effective_ttl = ttl or self._ttl
            serialized = json.dumps(value, default=str)
            await self._redis.setex(f"{self._prefix}{key}", effective_ttl, serialized)
        except Exception as e:
            logger.error("Short-term memory set failed", key=key, error=str(e))

    async def get(self, key: str) -> Optional[Any]:
        """Retrieve a value from short-term memory."""
        try:
            data = await self._redis.get(f"{self._prefix}{key}")
            return json.loads(data) if data else None
        except Exception as e:
            logger.error("Short-term memory get failed", key=key, error=str(e))
            return None

    async def delete(self, key: str) -> None:
        """Delete a key from short-term memory."""
        try:
            await self._redis.delete(f"{self._prefix}{key}")
        except Exception as e:
            logger.error("Short-term memory delete failed", key=key, error=str(e))

    async def get_context(self, task_id: str) -> Dict[str, Any]:
        """Get all context for a task."""
        try:
            pattern = f"{self._prefix}task:{task_id}:*"
            keys = await self._redis.keys(pattern)
            result = {}
            for key in keys:
                data = await self._redis.get(key)
                if data:
                    short_key = key.replace(f"{self._prefix}task:{task_id}:", "")
                    result[short_key] = json.loads(data)
            return result
        except Exception as e:
            logger.error("Context retrieval failed", task_id=task_id, error=str(e))
            return {}

    async def set_context(self, task_id: str, key: str, value: Any) -> None:
        """Set a context value for a task."""
        await self.set(f"task:{task_id}:{key}", value)

    async def append_conversation(self, session_id: str, role: str, content: str) -> None:
        """Append a message to a conversation history."""
        key = f"{self._prefix}conv:{session_id}"
        try:
            existing = await self._redis.get(key)
            history = json.loads(existing) if existing else []
            history.append({
                "role": role,
                "content": content,
                "timestamp": time.time(),
            })
            # Keep last 50 messages
            history = history[-50:]
            await self._redis.setex(key, self._ttl, json.dumps(history))
        except Exception as e:
            logger.error("Conversation append failed", session_id=session_id, error=str(e))

    async def get_conversation(self, session_id: str) -> List[Dict]:
        """Get conversation history for a session."""
        try:
            key = f"{self._prefix}conv:{session_id}"
            data = await self._redis.get(key)
            return json.loads(data) if data else []
        except Exception as e:
            logger.error("Conversation retrieval failed", session_id=session_id, error=str(e))
            return []


class LongTermMemory:
    """
    ChromaDB-backed vector memory for semantic search over knowledge.
    Falls back gracefully if ChromaDB is unavailable.
    """

    def __init__(self, chroma_path: str, collection_name: str):
        self._chroma_path = chroma_path
        self._collection_name = collection_name
        self._client: Optional[Any] = None
        self._collection: Optional[Any] = None
        self._available = False

    async def initialize(self) -> bool:
        """Initialize ChromaDB. Returns True if successful."""
        try:
            import chromadb
            from chromadb.config import Settings as ChromaSettings

            self._client = chromadb.PersistentClient(
                path=self._chroma_path,
                settings=ChromaSettings(
                    anonymized_telemetry=False,
                    allow_reset=False,
                ),
            )
            self._collection = self._client.get_or_create_collection(
                name=self._collection_name,
                metadata={"hnsw:space": "cosine"},
            )
            self._available = True
            logger.info(
                "Long-term memory initialized",
                path=self._chroma_path,
                collection=self._collection_name,
            )
            return True
        except ImportError:
            logger.warning("ChromaDB not available — long-term memory disabled")
            return False
        except Exception as e:
            logger.error("ChromaDB initialization failed", error=str(e))
            return False

    async def store(
        self,
        content: str,
        metadata: Optional[Dict] = None,
        memory_type: str = "knowledge",
        memory_id: Optional[str] = None,
    ) -> str:
        """Store content in long-term memory."""
        if not self._available:
            return str(uuid.uuid4())
        try:
            mid = memory_id or str(uuid.uuid4())
            meta = {
                **(metadata or {}),
                "memory_type": memory_type,
                "created_at": time.time(),
            }
            self._collection.add(
                ids=[mid],
                documents=[content],
                metadatas=[meta],
            )
            logger.debug("Memory stored", memory_id=mid, memory_type=memory_type)
            return mid
        except Exception as e:
            logger.error("Memory store failed", error=str(e))
            return str(uuid.uuid4())

    async def search(
        self,
        query: str,
        top_k: int = 5,
        memory_type: Optional[str] = None,
    ) -> List[Memory]:
        """Semantic search over long-term memory."""
        if not self._available:
            return []
        try:
            where = {"memory_type": memory_type} if memory_type and memory_type != "all" else None
            results = self._collection.query(
                query_texts=[query],
                n_results=min(top_k, self._collection.count() or 1),
                where=where,
            )

            memories = []
            if results and results.get("ids"):
                for i, mid in enumerate(results["ids"][0]):
                    doc = results["documents"][0][i]
                    meta = results["metadatas"][0][i] if results.get("metadatas") else {}
                    distance = results["distances"][0][i] if results.get("distances") else 0
                    relevance = 1.0 - min(distance, 1.0)
                    memories.append(Memory(
                        id=mid,
                        content=doc,
                        memory_type=meta.get("memory_type", "knowledge"),
                        metadata=meta,
                        created_at=meta.get("created_at", 0),
                        relevance_score=relevance,
                    ))
            return sorted(memories, key=lambda m: m.relevance_score, reverse=True)
        except Exception as e:
            logger.error("Memory search failed", error=str(e))
            return []

    async def delete(self, memory_id: str) -> bool:
        """Delete a memory by ID."""
        if not self._available:
            return False
        try:
            self._collection.delete(ids=[memory_id])
            return True
        except Exception as e:
            logger.error("Memory delete failed", error=str(e))
            return False

    def get_stats(self) -> Dict:
        """Get memory store statistics."""
        if not self._available:
            return {"available": False, "count": 0}
        try:
            return {
                "available": True,
                "count": self._collection.count(),
                "collection": self._collection_name,
            }
        except Exception:
            return {"available": False, "count": 0}


class MemorySystem:
    """
    Unified memory system orchestrating short-term and long-term memory.
    Single interface for all memory operations.
    """

    def __init__(self):
        self._short_term: Optional[ShortTermMemory] = None
        self._long_term: Optional[LongTermMemory] = None
        self._initialized = False

    async def initialize(self, redis_client: Any) -> None:
        """Initialize both memory tiers."""
        settings = get_settings()

        self._short_term = ShortTermMemory(
            redis_client=redis_client,
            ttl=settings.memory.short_term_ttl,
            max_items=settings.memory.max_short_term_items,
        )

        self._long_term = LongTermMemory(
            chroma_path=settings.memory.chroma_path,
            collection_name=settings.memory.collection_name,
        )
        await self._long_term.initialize()
        self._initialized = True
        logger.info("Memory system initialized")

    @property
    def short_term(self) -> ShortTermMemory:
        if not self._short_term:
            raise RuntimeError("Memory system not initialized")
        return self._short_term

    @property
    def long_term(self) -> LongTermMemory:
        if not self._long_term:
            raise RuntimeError("Memory system not initialized")
        return self._long_term

    async def remember(
        self,
        content: str,
        memory_type: str = "knowledge",
        metadata: Optional[Dict] = None,
        also_cache: bool = False,
        cache_key: Optional[str] = None,
        cache_ttl: int = 3600,
    ) -> str:
        """Store content in long-term memory."""
        memory_id = await self.long_term.store(
            content=content,
            memory_type=memory_type,
            metadata=metadata,
        )
        if also_cache and cache_key and self._short_term:
            await self._short_term.set(cache_key, content, ttl=cache_ttl)
        return memory_id

    async def recall(
        self,
        query: str,
        top_k: int = 5,
        memory_type: Optional[str] = None,
    ) -> List[Memory]:
        """Retrieve relevant memories via semantic search."""
        return await self.long_term.search(query=query, top_k=top_k, memory_type=memory_type)

    def get_stats(self) -> Dict:
        """Get memory system statistics."""
        return {
            "initialized": self._initialized,
            "long_term": self.long_term.get_stats() if self._long_term else {},
        }


# Singleton
_memory_system: Optional[MemorySystem] = None


def get_memory_system() -> MemorySystem:
    """Get the global memory system instance."""
    global _memory_system
    if _memory_system is None:
        _memory_system = MemorySystem()
    return _memory_system
