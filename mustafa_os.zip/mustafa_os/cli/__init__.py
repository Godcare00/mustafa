"""MUSTAFA OS - CLI Package"""
