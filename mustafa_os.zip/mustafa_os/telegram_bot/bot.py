"""
MUSTAFA OS - Telegram Bot Interface
Authorized-users-only Telegram bot that routes messages to the MUSTAFA OS Orchestrator.
Uses long-polling. Requires python-telegram-bot.
"""
from __future__ import annotations

import asyncio
import json
import sys
import uuid
from pathlib import Path
from typing import Dict, Optional

sys.path.insert(0, str(Path(__file__).parent.parent))

from core.config import get_settings
from core.logger import get_logger

logger = get_logger("telegram_bot")


def format_response_for_telegram(result: dict) -> str:
    """Format an orchestrator result for Telegram (Markdown-safe)."""
    if not isinstance(result, dict):
        return str(result)[:4000]

    status = result.get("status", "unknown")
    task_id = result.get("task_id", "")
    iterations = result.get("iterations")
    ms = result.get("processing_time_ms")

    lines = []

    # Header
    if status == "completed":
        lines.append("✅ *Task Complete*")
    elif status == "error":
        lines.append("❌ *Error*")
    elif status == "needs_input":
        lines.append("❓ *Input Needed*")
    else:
        lines.append(f"⚙️ *Status: {status}*")

    # Metadata
    meta = []
    if task_id:
        meta.append(f"ID: `{task_id[:8]}`")
    if iterations:
        meta.append(f"{iterations} steps")
    if ms:
        meta.append(f"{ms:.0f}ms")
    if meta:
        lines.append(" | ".join(meta))

    lines.append("")  # blank line

    # Main content
    main_result = result.get("result") or result.get("message") or result.get("error", "")
    if isinstance(main_result, dict):
        content = json.dumps(main_result, indent=2, default=str)
        # Telegram max 4096 chars
        if len(content) > 3000:
            content = content[:3000] + "\n... (truncated)"
        lines.append(f"```\n{content}\n```")
    elif isinstance(main_result, str):
        lines.append(main_result[:3500])
    elif main_result:
        lines.append(str(main_result)[:3500])

    # Alternatives
    if result.get("alternatives"):
        lines.append("\n*Alternatives:*")
        for alt in result["alternatives"][:5]:
            lines.append(f"• {alt}")

    return "\n".join(lines)


async def run_bot() -> None:
    """Start the Telegram bot."""
    try:
        from telegram import Update
        from telegram.ext import Application, CommandHandler, MessageHandler, filters
        from telegram.constants import ParseMode
    except ImportError:
        logger.error("python-telegram-bot not installed. Run: pip install python-telegram-bot")
        return

    settings = get_settings()

    if not settings.telegram.bot_token:
        logger.error("TELEGRAM_BOT_TOKEN not set in .env")
        return

    if not settings.telegram.enabled:
        logger.info("Telegram bot is disabled in config")
        return

    authorized_users = set(settings.telegram.authorized_users)
    logger.info("Telegram bot starting", authorized_users=len(authorized_users))

    # Boot kernel
    from core.kernel import get_kernel
    kernel = get_kernel()

    if not kernel._started:
        logger.info("Booting kernel for Telegram bot...")
        await kernel.boot()

    # Session mapping: telegram_user_id -> session_id
    sessions: Dict[int, str] = {}

    def get_session(user_id: int) -> str:
        if user_id not in sessions:
            sessions[user_id] = str(uuid.uuid4())
        return sessions[user_id]

    def is_authorized(update: Update) -> bool:
        user_id = update.effective_user.id if update.effective_user else None
        if not authorized_users:
            return True  # If no list set, allow all (not recommended for production)
        return user_id in authorized_users

    async def start_command(update: Update, context) -> None:
        if not is_authorized(update):
            await update.message.reply_text("⛔ Unauthorized. Contact the administrator.")
            logger.warning("Unauthorized access attempt", user_id=update.effective_user.id)
            return
        session_id = get_session(update.effective_user.id)
        await update.message.reply_text(
            f"*MUSTAFA OS Online* 🤖\n\n"
            f"I'm your autonomous AI assistant. Send me any task.\n\n"
            f"Session: `{session_id[:8]}`\n\n"
            "Commands:\n"
            "/start - Show this message\n"
            "/status - System status\n"
            "/health - Health check\n"
            "/agents - List agents\n"
            "/tools - List tools\n"
            "/tasks - Recent tasks\n"
            "/new - New session\n"
            "/help - Help",
            parse_mode=ParseMode.MARKDOWN,
        )

    async def help_command(update: Update, context) -> None:
        if not is_authorized(update):
            return
        await update.message.reply_text(
            "*MUSTAFA OS Commands*\n\n"
            "Just send any message to process it as a task.\n\n"
            "/status - System metrics\n"
            "/health - Health check\n"
            "/agents - Active agents\n"
            "/tools - Available tools\n"
            "/tasks - Recent tasks\n"
            "/new - Fresh session\n"
            "/start - Welcome",
            parse_mode=ParseMode.MARKDOWN,
        )

    async def status_command(update: Update, context) -> None:
        if not is_authorized(update):
            return
        await update.message.reply_text("⏳ Fetching status...")
        status = await kernel.get_status()
        text = (
            f"*System Status*\n\n"
            f"State: {'🟢 Online' if status['status'] == 'online' else '🔴 Offline'}\n"
            f"Uptime: `{status['uptime_seconds']:.0f}s`\n"
            f"Requests: `{status['requests_processed']}`\n"
            f"Agents: `{len(status['agents'])}`\n"
            f"Tools: `{status['tools_count']}`\n"
            f"Redis: {'✅' if status['redis_connected'] else '⚠️'}\n"
        )
        await update.message.reply_text(text, parse_mode=ParseMode.MARKDOWN)

    async def health_command(update: Update, context) -> None:
        if not is_authorized(update):
            return
        health = await kernel.health_check()
        overall = "🟢 Healthy" if health['overall'] == 'healthy' else "🟡 Degraded"
        check_lines = []
        for k, v in health['checks'].items():
            ok = v == "ok" or isinstance(v, dict)
            check_lines.append(f"{'✅' if ok else '❌'} {k}")
        text = f"*Health Check*: {overall}\n\n" + "\n".join(check_lines)
        await update.message.reply_text(text, parse_mode=ParseMode.MARKDOWN)

    async def agents_command(update: Update, context) -> None:
        if not is_authorized(update):
            return
        if not kernel._registry:
            await update.message.reply_text("System not initialized.")
            return
        agents = kernel._registry.list_agents()
        lines = ["*Registered Agents*\n"]
        for a in agents:
            icon = "🟢" if a['status'] == 'idle' else "🔄"
            lines.append(f"{icon} `{a['name']}`")
        await update.message.reply_text("\n".join(lines), parse_mode=ParseMode.MARKDOWN)

    async def tools_command(update: Update, context) -> None:
        if not is_authorized(update):
            return
        from core.tool_engine import get_tool_engine
        engine = get_tool_engine()
        tools = await engine.list_all_tools()
        lines = [f"*Available Tools* ({len(tools)})\n"]
        for t in tools[:20]:  # Cap at 20 for telegram
            lines.append(f"• `{t['name']}` — {t['description'][:50]}")
        if len(tools) > 20:
            lines.append(f"... and {len(tools) - 20} more")
        await update.message.reply_text("\n".join(lines), parse_mode=ParseMode.MARKDOWN)

    async def tasks_command(update: Update, context) -> None:
        if not is_authorized(update):
            return
        from core.database import get_db
        db = await get_db()
        tasks = await db.list_tasks(limit=8)
        lines = ["*Recent Tasks*\n"]
        if not tasks:
            lines.append("No tasks yet.")
        else:
            for t in tasks:
                icon = "✅" if t['status'] == 'completed' else ("❌" if t['status'] == 'failed' else "⏳")
                goal = t['goal'][:40] + "..." if len(t['goal']) > 40 else t['goal']
                lines.append(f"{icon} `{t['id'][:8]}` {goal}")
        await update.message.reply_text("\n".join(lines), parse_mode=ParseMode.MARKDOWN)

    async def new_session_command(update: Update, context) -> None:
        if not is_authorized(update):
            return
        sessions[update.effective_user.id] = str(uuid.uuid4())
        await update.message.reply_text(
            f"✅ New session started: `{sessions[update.effective_user.id][:8]}`",
            parse_mode=ParseMode.MARKDOWN,
        )

    async def handle_message(update: Update, context) -> None:
        """Route all text messages to the orchestrator."""
        if not is_authorized(update):
            await update.message.reply_text("⛔ Unauthorized.")
            return

        user_id = update.effective_user.id
        text = update.message.text
        session_id = get_session(user_id)

        # Acknowledge immediately
        thinking_msg = await update.message.reply_text("⏳ Processing...")

        try:
            result = await kernel.process(
                goal=text,
                session_id=session_id,
            )
            formatted = format_response_for_telegram(result)
            # Delete thinking message, send result
            await thinking_msg.delete()
            # Telegram max message length is 4096
            if len(formatted) > 4096:
                formatted = formatted[:4090] + "..."
            await update.message.reply_text(formatted, parse_mode=ParseMode.MARKDOWN)

        except Exception as e:
            logger.error("Telegram message handling failed", error=str(e))
            await thinking_msg.edit_text(f"❌ Error: {str(e)[:200]}")

    # Build application
    app = (
        Application.builder()
        .token(settings.telegram.bot_token)
        .build()
    )

    # Register handlers
    app.add_handler(CommandHandler("start", start_command))
    app.add_handler(CommandHandler("help", help_command))
    app.add_handler(CommandHandler("status", status_command))
    app.add_handler(CommandHandler("health", health_command))
    app.add_handler(CommandHandler("agents", agents_command))
    app.add_handler(CommandHandler("tools", tools_command))
    app.add_handler(CommandHandler("tasks", tasks_command))
    app.add_handler(CommandHandler("new", new_session_command))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_message))

    logger.info("Telegram bot polling started")

    # Run polling
    async with app:
        await app.start()
        await app.updater.start_polling(
            poll_interval=settings.telegram.polling_interval,
            allowed_updates=["message"],
        )
        # Keep running until interrupted
        await asyncio.Event().wait()
        await app.updater.stop()
        await app.stop()


def main() -> None:
    """Entry point for Telegram bot."""
    asyncio.run(run_bot())


if __name__ == "__main__":
    main()
