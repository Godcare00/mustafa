"""
MUSTAFA OS - Orchestrator Agent
Central controller that receives goals, builds plans, assigns tasks, and tracks progress.
"""

from __future__ import annotations

import asyncio
import uuid
from datetime import datetime
from typing import Any, Dict, List, Optional

from agents.base import AgentResult, BaseAgent, TaskContext
from core.database import TaskRecord, async_session_factory
from core.logging_config import get_logger
from core.registry import agent_registry
from sqlalchemy import select

logger = get_logger("orchestrator")


class OrchestratorAgent(BaseAgent):
    """
    Master Orchestrator Agent — the brain of MUSTAFA OS.
    
    Responsibilities:
    - Parse incoming goals from users
    - Coordinate with Planner to build execution plans
    - Assign tasks to specialized agents
    - Track progress and handle failures
    - Resolve inter-agent conflicts
    - Report final results
    """

    def __init__(self) -> None:
        super().__init__(
            agent_id="orchestrator",
            name="Orchestrator Agent",
            capabilities=[
                "goal_parsing",
                "task_assignment",
                "plan_coordination",
                "conflict_resolution",
                "result_aggregation",
            ],
            allowed_tools=["*"],  # Orchestrator has all tool access
        )
        self._active_tasks: Dict[str, Dict[str, Any]] = {}

    async def _execute_goal(self, context: TaskContext) -> AgentResult:
        """
        Main goal execution pipeline:
        1. Parse and validate goal
        2. Get execution plan from Planner
        3. Execute plan steps
        4. Aggregate results
        5. Return final answer
        """
        goal = context.goal
        task_id = context.task_id
        self.logger.info("executing_goal", goal=goal[:100], task_id=task_id)

        # Store task in database
        await self._persist_task(task_id, goal, "planning")

        try:
            # Step 1: Get a plan from the planner agent
            plan = await self._request_plan(goal, task_id)
            if not plan:
                return AgentResult.fail("Failed to generate execution plan")

            await self._persist_task(task_id, goal, "executing", plan=plan)
            self.logger.info("plan_received", task_id=task_id, steps=len(plan.get("steps", [])))

            # Step 2: Execute plan steps
            results = await self._execute_plan(plan, task_id)

            # Step 3: Synthesize results
            final_answer = await self._synthesize_results(goal, results, task_id)

            # Step 4: Have Critic evaluate
            critique = await self._request_critique(goal, final_answer, task_id)

            # Step 5: Store in memory
            await self._store_in_memory(goal, final_answer, task_id)

            await self._persist_task(
                task_id, goal, "completed",
                result={"answer": final_answer, "critique": critique}
            )

            self.logger.info("goal_completed", task_id=task_id)
            return AgentResult.ok(
                data={"answer": final_answer, "plan": plan, "critique": critique},
                task_id=task_id,
            )

        except Exception as e:
            await self._persist_task(task_id, goal, "failed", error=str(e))
            self.logger.error("goal_failed", task_id=task_id, error=str(e))
            return AgentResult.fail(str(e), task_id=task_id)

    async def _request_plan(
        self, goal: str, task_id: str
    ) -> Optional[Dict[str, Any]]:
        """
        Request an execution plan from the Planner agent.
        Falls back to LLM-generated plan if Planner is unavailable or slow.
        """
        planner = agent_registry.get_agent("planner")
        if planner and planner.instance:
            try:
                from agents.base import TaskContext
                ctx = TaskContext(
                    task_id=task_id,
                    goal=goal,
                    payload={"goal": goal, "task_id": task_id},
                )
                result = await planner.instance.handle_task("create_plan", ctx)
                if result.success and result.data:
                    return result.data
            except Exception as e:
                self.logger.error("planner_direct_call_failed", error=str(e))

        # Fallback: generate plan with our own LLM call
        return await self._generate_fallback_plan(goal)

    async def _generate_fallback_plan(self, goal: str) -> Dict[str, Any]:
        """Generate a simple plan using LLM if Planner is unavailable."""
        plan_json = await self.think_json(
            f"""Create a simple execution plan for this goal:

GOAL: {goal}

Return a JSON plan with steps. Keep it simple and practical."""
        )
        return plan_json

    async def _execute_plan(
        self, plan: Dict[str, Any], task_id: str
    ) -> List[Dict[str, Any]]:
        """Execute plan steps, respecting dependencies."""
        steps = plan.get("steps", [])
        results = []
        completed_steps = set()

        for step in steps:
            step_id = step.get("step_id", 1)
            depends_on = step.get("depends_on", [])

            # Check dependencies
            if depends_on and not all(d in completed_steps for d in depends_on):
                self.logger.warning("step_dependencies_not_met", step_id=step_id)
                continue

            # Execute step
            step_result = await self._execute_step(step, task_id)
            results.append({"step": step, "result": step_result})
            completed_steps.add(step_id)

            # Short delay between steps
            await asyncio.sleep(0.1)

        return results

    async def _execute_step(
        self, step: Dict[str, Any], task_id: str
    ) -> Dict[str, Any]:
        """Execute a single plan step by calling the target agent directly."""
        agent_id = step.get("agent", "research")
        description = step.get("description", "")
        tools = step.get("tools", [])

        self.logger.info(
            "executing_step",
            step_id=step.get("step_id"),
            agent=agent_id,
            description=description[:80],
        )

        # Resolve the live agent instance from kernel
        from core.kernel import kernel
        agent_instance = kernel.get_agent(agent_id)
        if not agent_instance:
            self.logger.warning("agent_not_found_using_fallback", requested=agent_id)
            agent_instance = kernel.get_agent("research")

        if not agent_instance:
            return {"success": False, "error": f"Agent '{agent_id}' not available"}

        try:
            from agents.base import TaskContext
            ctx = TaskContext(
                task_id=task_id,
                goal=description,
                payload={
                    "goal": description,
                    "task_id": task_id,
                    "tools": tools,
                    "step": step,
                },
                sender=self.agent_id,
            )
            result = await asyncio.wait_for(
                agent_instance.handle_task("execute_step", ctx),
                timeout=120,
            )
            return result.to_dict()

        except asyncio.TimeoutError:
            self.logger.error("step_timeout", step_id=step.get("step_id"), agent=agent_id)
            return {"success": False, "error": f"Step timed out after 120s"}
        except Exception as e:
            self.logger.error("step_execution_failed", error=str(e), step_id=step.get("step_id"))
            return {"success": False, "error": str(e)}

    async def _synthesize_results(
        self,
        goal: str,
        results: List[Dict[str, Any]],
        task_id: str,
    ) -> str:
        """Synthesize all step results into a final answer."""
        results_summary = "\n".join([
            f"Step {i+1}: {r.get('step', {}).get('description', '')} -> "
            f"{'SUCCESS' if r.get('result', {}).get('success') else 'FAILED'}: "
            f"{str(r.get('result', {}).get('data', r.get('result', {}).get('error', '')))[:300]}"
            for i, r in enumerate(results)
        ])

        return await self.think(
            f"""You are synthesizing results from a multi-step task execution.

ORIGINAL GOAL: {goal}

STEP RESULTS:
{results_summary}

Please provide a comprehensive, well-structured final answer that directly addresses the original goal.
Be specific, accurate, and actionable. Include all important findings."""
        )

    async def _request_critique(
        self, goal: str, answer: str, task_id: str
    ) -> Dict[str, Any]:
        """Request a quality evaluation from the Critic agent (direct call)."""
        try:
            from core.kernel import kernel
            critic = kernel.get_agent("critic")
            if critic:
                from agents.base import TaskContext
                ctx = TaskContext(
                    task_id=task_id,
                    goal=goal,
                    payload={"goal": goal, "answer": answer, "task_id": task_id},
                    sender=self.agent_id,
                )
                result = await asyncio.wait_for(
                    critic.handle_task("evaluate", ctx), timeout=30
                )
                if result.success:
                    return result.data or {}
        except Exception as e:
            self.logger.warning("critique_failed", error=str(e))
        return {"score": 0.8, "feedback": "Critique unavailable", "verdict": "accept"}

    async def _store_in_memory(
        self, goal: str, answer: str, task_id: str
    ) -> None:
        """Store task result in the memory system (direct call, fire-and-forget)."""
        try:
            from core.kernel import kernel
            mem_agent = kernel.get_agent("memory_agent")
            if mem_agent:
                from agents.base import TaskContext
                ctx = TaskContext(
                    task_id=task_id,
                    goal=goal,
                    payload={
                        "goal": goal,
                        "result": answer,
                        "task_id": task_id,
                        "collection": "task_history",
                    },
                    sender=self.agent_id,
                )
                asyncio.create_task(mem_agent.handle_task("store_memory", ctx))
        except Exception as e:
            self.logger.warning("memory_store_failed", error=str(e))

    async def handle_task(self, task_type: str, context: TaskContext) -> AgentResult:
        """Route incoming tasks to the appropriate handler."""
        handlers = {
            "execute_goal": self._execute_goal,
            "task_status": self._get_task_status,
            "system_status": self._get_system_status,
        }
        handler = handlers.get(task_type)
        if not handler:
            return AgentResult.fail(f"Unknown task type: {task_type}")
        return await handler(context)

    async def _get_task_status(self, context: TaskContext) -> AgentResult:
        """Get status of a specific task."""
        task_id = context.payload.get("task_id")
        if not task_id:
            return AgentResult.fail("task_id required")

        async with async_session_factory() as session:
            result = await session.execute(
                select(TaskRecord).where(TaskRecord.id == task_id)
            )
            task = result.scalar_one_or_none()

        if not task:
            return AgentResult.fail(f"Task {task_id} not found")

        return AgentResult.ok({
            "task_id": task.id,
            "status": task.status,
            "goal": task.goal,
            "result": task.result,
            "created_at": task.created_at.isoformat(),
        })

    async def _get_system_status(self, context: TaskContext) -> AgentResult:
        """Get overall system status."""
        summary = agent_registry.get_system_summary()
        return AgentResult.ok(summary)

    async def _persist_task(
        self,
        task_id: str,
        goal: str,
        status: str,
        plan: Optional[Dict] = None,
        result: Optional[Dict] = None,
        error: Optional[str] = None,
    ) -> None:
        """Persist task state to the database."""
        try:
            async with async_session_factory() as session:
                existing = await session.get(TaskRecord, task_id)
                if existing:
                    existing.status = status
                    if plan:
                        existing.plan = plan
                    if result:
                        existing.result = result
                    if error:
                        existing.error = error
                    if status == "completed":
                        existing.completed_at = datetime.utcnow()
                else:
                    record = TaskRecord(
                        id=task_id,
                        goal=goal,
                        status=status,
                        assigned_agent=self.agent_id,
                        plan=plan,
                        result=result,
                        error=error,
                    )
                    session.add(record)
                await session.commit()
        except Exception as e:
            self.logger.error("task_persist_failed", error=str(e))
