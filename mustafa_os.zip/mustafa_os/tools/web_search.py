"""
MUSTAFA OS - Web Search Tool
DuckDuckGo-powered web search. Auto-installs the required package on first use
so the system is self-healing — no manual pip install needed.
"""

from __future__ import annotations

import asyncio
import subprocess
import sys
from typing import Any, Dict, List, Optional

from tools.base import BaseTool, ToolResult
from core.logging_config import get_logger

logger = get_logger("web_search_tool")

_ddgs_available: Optional[bool] = None


async def _ensure_ddgs() -> bool:
    """
    Ensure duckduckgo_search is importable. If not, install it automatically
    using the same Python interpreter that's running MUSTAFA OS.
    Returns True if available after the attempt.
    """
    global _ddgs_available

    if _ddgs_available is True:
        return True
    if _ddgs_available is False:
        return False  # Already tried and failed this session

    try:
        import duckduckgo_search  # noqa: F401
        _ddgs_available = True
        return True
    except ImportError:
        pass

    # Not installed — try auto-install
    logger.info("ddgs_auto_installing", message="Installing duckduckgo-search...")
    try:
        proc = await asyncio.create_subprocess_exec(
            sys.executable, "-m", "pip", "install",
            "duckduckgo-search", "--quiet", "--no-warn-script-location",
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
        _, stderr = await asyncio.wait_for(proc.communicate(), timeout=120)
        if proc.returncode == 0:
            import importlib
            importlib.invalidate_caches()
            try:
                import duckduckgo_search  # noqa: F401
                _ddgs_available = True
                logger.info("ddgs_installed_successfully")
                return True
            except ImportError:
                pass
        else:
            logger.warning("ddgs_install_failed", stderr=stderr.decode()[:200])
    except Exception as e:
        logger.warning("ddgs_install_error", error=str(e))

    _ddgs_available = False
    return False


class WebSearchTool(BaseTool):
    """Search the web using DuckDuckGo. Auto-installs dependency on first use."""

    name = "web_search"
    description = "Search the web for real, current information using DuckDuckGo"
    permissions = ["network.read"]
    timeout = 60  # Includes potential install time on first run

    async def execute(self, params: Dict[str, Any]) -> ToolResult:
        query       = params.get("query", "")
        max_results = int(params.get("max_results", 5))

        if not query:
            return ToolResult(success=False, error="query parameter required")

        available = await _ensure_ddgs()
        if not available:
            return ToolResult(
                success=False,
                error=(
                    "duckduckgo-search could not be installed automatically. "
                    "Please run: pip install duckduckgo-search"
                ),
            )

        try:
            from duckduckgo_search import DDGS
            results = []

            # Run blocking DDGS call in thread pool to avoid blocking the event loop
            def _search():
                with DDGS() as ddgs:
                    return list(ddgs.text(query, max_results=max_results))

            raw = await asyncio.get_event_loop().run_in_executor(None, _search)

            for r in raw:
                results.append({
                    "title":   r.get("title", ""),
                    "url":     r.get("href", ""),
                    "snippet": r.get("body", ""),
                })

            logger.info("web_search_complete", query=query[:60], results=len(results))
            return ToolResult(success=True, data={"results": results, "query": query})

        except Exception as e:
            logger.error("web_search_failed", error=str(e))
            return ToolResult(success=False, error=f"Search failed: {e}")

    async def validate_params(self, params: Dict[str, Any]) -> Optional[str]:
        if not params.get("query"):
            return "query is required"
        return None
