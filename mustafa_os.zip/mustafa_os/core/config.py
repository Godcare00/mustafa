"""
MUSTAFA OS - Configuration Manager
Loads and validates all system configuration from YAML + .env files.
"""
from __future__ import annotations

import os
from functools import lru_cache
from pathlib import Path
from typing import Any, Dict, List, Optional

import yaml
from dotenv import load_dotenv
from pydantic import BaseModel, Field

# Load .env file
load_dotenv()

BASE_DIR = Path(__file__).parent.parent


def _load_yaml(filename: str) -> Dict[str, Any]:
    """Load a YAML config file."""
    path = BASE_DIR / "config" / filename
    if not path.exists():
        return {}
    with open(path, "r") as f:
        return yaml.safe_load(f) or {}


class LLMConfig(BaseModel):
    provider: str = "openrouter"
    base_url: str = "https://openrouter.ai/api/v1"
    api_key: str = Field(default_factory=lambda: os.getenv("OPENROUTER_API_KEY", ""))
    default_model: str = "arcee-ai/trinity-large-preview:free"
    max_tokens: int = 4096
    temperature: float = 0.7
    timeout: int = 120
    max_retries: int = 3
    retry_delay: float = 2.0


class RedisConfig(BaseModel):
    host: str = Field(default_factory=lambda: os.getenv("REDIS_HOST", "localhost"))
    port: int = Field(default_factory=lambda: int(os.getenv("REDIS_PORT", "6379")))
    db: int = 0
    password: Optional[str] = Field(default_factory=lambda: os.getenv("REDIS_PASSWORD") or None)
    max_connections: int = 50
    socket_timeout: int = 5
    decode_responses: bool = True


class DatabaseConfig(BaseModel):
    path: str = Field(
        default_factory=lambda: os.getenv("DATABASE_PATH", "data/mustafa_os.db")
    )
    echo: bool = False
    pool_size: int = 10


class MemoryConfig(BaseModel):
    chroma_path: str = "data/chroma_db"
    collection_name: str = "mustafa_memory"
    embedding_model: str = "all-MiniLM-L6-v2"
    short_term_ttl: int = 3600
    max_short_term_items: int = 1000


class ServerConfig(BaseModel):
    host: str = "0.0.0.0"
    port: int = 8000
    workers: int = 4
    log_level: str = "info"


class SecurityConfig(BaseModel):
    max_tool_execution_time: int = 30
    sandbox_enabled: bool = True
    audit_logging: bool = True
    secret_key: str = Field(
        default_factory=lambda: os.getenv("MUSTAFA_SECRET_KEY", "dev-secret-change-me")
    )


class TelegramConfig(BaseModel):
    enabled: bool = False
    bot_token: str = Field(default_factory=lambda: os.getenv("TELEGRAM_BOT_TOKEN", ""))
    authorized_users: List[int] = Field(
        default_factory=lambda: [
            int(u)
            for u in os.getenv("TELEGRAM_AUTHORIZED_USERS", "").split(",")
            if u.strip().isdigit()
        ]
    )
    polling_interval: float = 1.0


class CircuitBreakerConfig(BaseModel):
    failure_threshold: int = 5
    recovery_timeout: int = 60
    half_open_max_calls: int = 3


class TaskQueueConfig(BaseModel):
    max_concurrent_tasks: int = 20
    task_timeout: int = 300
    retry_limit: int = 3
    retry_backoff: float = 2.0


class Settings(BaseModel):
    """Complete MUSTAFA OS settings."""

    environment: str = Field(
        default_factory=lambda: os.getenv("MUSTAFA_ENV", "production")
    )
    debug: bool = False

    server: ServerConfig = Field(default_factory=ServerConfig)
    llm: LLMConfig = Field(default_factory=LLMConfig)
    redis: RedisConfig = Field(default_factory=RedisConfig)
    database: DatabaseConfig = Field(default_factory=DatabaseConfig)
    memory: MemoryConfig = Field(default_factory=MemoryConfig)
    security: SecurityConfig = Field(default_factory=SecurityConfig)
    telegram: TelegramConfig = Field(default_factory=TelegramConfig)
    circuit_breaker: CircuitBreakerConfig = Field(default_factory=CircuitBreakerConfig)
    task_queue: TaskQueueConfig = Field(default_factory=TaskQueueConfig)

    agents_config: Dict[str, Any] = Field(default_factory=dict)
    tools_config: Dict[str, Any] = Field(default_factory=dict)
    models_config: Dict[str, Any] = Field(default_factory=dict)

    class Config:
        arbitrary_types_allowed = True

    def get_agent_config(self, agent_name: str) -> Dict[str, Any]:
        """Get configuration for a specific agent."""
        return self.agents_config.get(agent_name, {})

    def get_tool_config(self, tool_name: str) -> Dict[str, Any]:
        """Get configuration for a specific tool."""
        return self.tools_config.get(tool_name, {})


@lru_cache(maxsize=1)
def get_settings() -> Settings:
    """Load and cache settings. Call this everywhere."""
    system_cfg = _load_yaml("system.yaml")
    agents_cfg = _load_yaml("agents.yaml")
    tools_cfg = _load_yaml("tools.yaml")
    models_cfg = _load_yaml("models.yaml")

    sys_data = system_cfg.get("system", {})
    srv_data = system_cfg.get("server", {})
    llm_data = system_cfg.get("llm", {})
    redis_data = system_cfg.get("redis", {})
    db_data = system_cfg.get("database", {})
    mem_data = system_cfg.get("memory", {})
    sec_data = system_cfg.get("security", {})
    tg_data = system_cfg.get("telegram", {})
    cb_data = system_cfg.get("circuit_breaker", {})
    tq_data = system_cfg.get("task_queue", {})

    settings = Settings(
        environment=sys_data.get("environment", "production"),
        debug=sys_data.get("debug", False),
        server=ServerConfig(**srv_data) if srv_data else ServerConfig(),
        llm=LLMConfig(**{k: v for k, v in llm_data.items() if k != "provider"}, **{"provider": llm_data.get("provider", "openrouter")}) if llm_data else LLMConfig(),
        redis=RedisConfig(**redis_data) if redis_data else RedisConfig(),
        database=DatabaseConfig(**db_data) if db_data else DatabaseConfig(),
        memory=MemoryConfig(**mem_data) if mem_data else MemoryConfig(),
        security=SecurityConfig(**sec_data) if sec_data else SecurityConfig(),
        telegram=TelegramConfig(**tg_data) if tg_data else TelegramConfig(),
        circuit_breaker=CircuitBreakerConfig(**cb_data) if cb_data else CircuitBreakerConfig(),
        task_queue=TaskQueueConfig(**tq_data) if tq_data else TaskQueueConfig(),
        agents_config=agents_cfg,
        tools_config=tools_cfg,
        models_config=models_cfg,
    )
    return settings
