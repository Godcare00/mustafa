"""
MUSTAFA OS - Specialized Agents
Planner, Research, Developer, Testing, and Critic agents.
"""

from __future__ import annotations

import json
from typing import Any, Dict, List, Optional

from agents.base import AgentResult, BaseAgent, TaskContext
from core.logging_config import get_logger

logger = get_logger("agents")


# ─── Planner Agent ────────────────────────────────────────────────────────────

class PlannerAgent(BaseAgent):
    """
    Decomposes complex goals into structured, executable step-by-step plans.
    Identifies dependencies, estimates durations, and maps tasks to agents.
    """

    def __init__(self) -> None:
        super().__init__(
            agent_id="planner",
            name="Planner Agent",
            capabilities=["task_planning", "dependency_analysis", "timeline_estimation"],
        )

    async def handle_task(self, task_type: str, context: TaskContext) -> AgentResult:
        if task_type == "create_plan":
            return await self._create_plan(context)
        if task_type == "execute_step":
            return await self._execute_step(context)
        return AgentResult.fail(f"Unknown task: {task_type}")

    async def _create_plan(self, context: TaskContext) -> AgentResult:
        """Generate a structured execution plan for a goal."""
        goal = context.goal
        self.logger.info("creating_plan", goal=goal[:100])

        try:
            plan = await self.think_json(
                f"""You are a master planner. Create a detailed, executable plan for:

GOAL: {goal}

Requirements:
- Break into 3-7 concrete steps maximum
- Assign each step to the most appropriate agent
- Available agents: orchestrator, planner, research, developer, testing, critic, memory_agent
- Identify step dependencies
- Be specific and actionable

Return ONLY this JSON structure:
{{
  "goal": "{goal}",
  "steps": [
    {{
      "step_id": 1,
      "description": "specific action to take",
      "agent": "agent_id",
      "tools": ["tool_name"],
      "depends_on": [],
      "timeout": 60,
      "retry_on_failure": true
    }}
  ],
  "estimated_duration_seconds": 120,
  "critical_path": [1, 2, 3],
  "complexity": "low|medium|high"
}}"""
            )
            self.logger.info("plan_created", steps=len(plan.get("steps", [])))
            return AgentResult.ok(plan)
        except Exception as e:
            self.logger.error("plan_creation_failed", error=str(e))
            return AgentResult.fail(str(e))

    async def _execute_step(self, context: TaskContext) -> AgentResult:
        """Execute a delegated step."""
        goal = context.goal
        response = await self.think(f"Complete this task concisely: {goal}")
        return AgentResult.ok({"response": response})


# ─── Research Agent ───────────────────────────────────────────────────────────

class ResearchAgent(BaseAgent):
    """
    Gathers, synthesizes, and structures information from multiple sources.
    Supports web search, document analysis, and knowledge extraction.
    """

    def __init__(self) -> None:
        super().__init__(
            agent_id="research",
            name="Research Agent",
            capabilities=["web_research", "document_analysis", "summarization", "knowledge_extraction"],
            allowed_tools=["web_search", "api_request", "file_manager", "data_analysis"],
        )
        self._tool_engine = None

    async def on_start(self) -> None:
        """Initialize tool access."""
        from tools import get_tool_engine
        self._tool_engine = get_tool_engine()

    async def handle_task(self, task_type: str, context: TaskContext) -> AgentResult:
        handlers = {
            "research": self._do_research,
            "execute_step": self._do_research,
            "web_search": self._web_search,
            "summarize": self._summarize,
            "extract_knowledge": self._extract_knowledge,
        }
        handler = handlers.get(task_type, self._do_research)
        return await handler(context)

    async def _do_research(self, context: TaskContext) -> AgentResult:
        """Perform comprehensive research on a topic."""
        goal = context.goal
        self.logger.info("researching", goal=goal[:100])

        # Try web search first
        search_results = await self._perform_web_search(goal)

        # Synthesize findings
        synthesis_prompt = f"""Research Goal: {goal}

Web Search Results:
{search_results}

Please provide:
1. A comprehensive answer to the research goal
2. Key findings and facts
3. Confidence level (high/medium/low)
4. Any important caveats or limitations

Be thorough, accurate, and well-structured."""

        response = await self.think(synthesis_prompt)

        return AgentResult.ok({
            "research_goal": goal,
            "findings": response,
            "search_results": search_results,
        })

    async def _perform_web_search(self, query: str) -> str:
        """Execute a web search and return formatted results."""
        try:
            if self._tool_engine:
                result = await self._tool_engine.execute(
                    tool_name="web_search",
                    agent_id=self.agent_id,
                    params={"query": query, "max_results": 5},
                )
                if result.success:
                    results = result.data.get("results", [])
                    return "\n".join([
                        f"[{i+1}] {r.get('title', '')}\n{r.get('snippet', '')}\nURL: {r.get('url', '')}"
                        for i, r in enumerate(results)
                    ])
        except Exception as e:
            self.logger.warning("web_search_failed", error=str(e))

        return "Web search unavailable. Using knowledge from training data."

    async def _web_search(self, context: TaskContext) -> AgentResult:
        results = await self._perform_web_search(context.goal)
        return AgentResult.ok({"results": results})

    async def _summarize(self, context: TaskContext) -> AgentResult:
        content = context.payload.get("content", context.goal)
        summary = await self.think(f"Provide a concise, accurate summary:\n\n{content}")
        return AgentResult.ok({"summary": summary})

    async def _extract_knowledge(self, context: TaskContext) -> AgentResult:
        content = context.payload.get("content", context.goal)
        knowledge = await self.think_json(
            f"""Extract structured knowledge from this content:
{content}

Return JSON with:
{{
  "key_facts": ["fact1", "fact2"],
  "entities": {{"people": [], "organizations": [], "concepts": []}},
  "relationships": [],
  "summary": "brief summary"
}}"""
        )
        return AgentResult.ok(knowledge)


# ─── Developer Agent ──────────────────────────────────────────────────────────

class DeveloperAgent(BaseAgent):
    """
    Writes, modifies, and improves code with production standards.
    Supports Python code generation, module modification, and architecture proposals.
    """

    def __init__(self) -> None:
        super().__init__(
            agent_id="developer",
            name="Developer Agent",
            capabilities=["code_generation", "code_modification", "architecture", "debugging"],
            allowed_tools=["file_manager", "code_executor", "database_query"],
        )
        self._tool_engine = None

    async def on_start(self) -> None:
        from tools import get_tool_engine
        self._tool_engine = get_tool_engine()

    async def handle_task(self, task_type: str, context: TaskContext) -> AgentResult:
        handlers = {
            "write_code": self._write_code,
            "modify_code": self._modify_code,
            "execute_step": self._handle_step,
            "create_tool": self._create_tool,
            "debug": self._debug_code,
            "propose_improvement": self._propose_improvement,
        }
        handler = handlers.get(task_type, self._handle_step)
        return await handler(context)

    async def _write_code(self, context: TaskContext) -> AgentResult:
        """Write production-quality Python code."""
        requirement = context.goal
        self.logger.info("writing_code", requirement=requirement[:100])

        code_spec = await self.think_json(
            f"""You are a senior Python engineer. Write production-quality code for:

REQUIREMENT: {requirement}

Requirements:
- Include type hints
- Add comprehensive docstrings
- Include error handling and logging
- Write clean, modular code
- Follow PEP 8

Return JSON:
{{
  "filename": "module_name.py",
  "code": "complete python code here",
  "description": "what this code does",
  "dependencies": ["package1", "package2"],
  "tests_needed": ["test description 1", "test description 2"]
}}"""
        )

        # Optionally save to file
        if context.payload.get("save_to_file") and self._tool_engine:
            file_path = f"./data/generated/{code_spec.get('filename', 'generated.py')}"
            await self._tool_engine.execute(
                tool_name="file_manager",
                agent_id=self.agent_id,
                params={
                    "operation": "write",
                    "path": file_path,
                    "content": code_spec.get("code", ""),
                },
            )
            code_spec["saved_to"] = file_path

        return AgentResult.ok(code_spec)

    async def _create_tool(self, context: TaskContext) -> AgentResult:
        """Create a new tool plugin for MUSTAFA OS."""
        tool_spec = context.payload.get("tool_spec", {})
        tool_name = tool_spec.get("name", "new_tool")

        code = await self.think(
            f"""Create a complete MUSTAFA OS tool plugin for:

Tool Name: {tool_name}
Description: {tool_spec.get('description', '')}
Inputs: {tool_spec.get('inputs', {})}
Outputs: {tool_spec.get('outputs', {})}

Write a complete Python class that inherits from BaseTool.
Include the execute() method, input validation, error handling, and docstrings.
Follow the exact same pattern as existing tools in tools/base.py."""
        )

        # Save to plugins directory
        if self._tool_engine:
            plugin_path = f"./plugins/{tool_name}.py"
            await self._tool_engine.execute(
                tool_name="file_manager",
                agent_id=self.agent_id,
                params={"operation": "write", "path": plugin_path, "content": code},
            )

        return AgentResult.ok({
            "tool_name": tool_name,
            "code": code,
            "plugin_path": f"./plugins/{tool_name}.py",
        })

    async def _modify_code(self, context: TaskContext) -> AgentResult:
        file_path = context.payload.get("file_path", "")
        change_request = context.goal

        # Read existing file
        existing_code = ""
        if self._tool_engine and file_path:
            result = await self._tool_engine.execute(
                tool_name="file_manager",
                agent_id=self.agent_id,
                params={"operation": "read", "path": file_path},
            )
            if result.success:
                existing_code = result.data.get("content", "")

        modified = await self.think(
            f"""Modify the following code as requested:

FILE: {file_path}
CHANGE REQUEST: {change_request}

EXISTING CODE:
{existing_code}

Provide the complete modified code. Maintain existing style and standards."""
        )

        return AgentResult.ok({"file_path": file_path, "modified_code": modified})

    async def _debug_code(self, context: TaskContext) -> AgentResult:
        code = context.payload.get("code", "")
        error = context.payload.get("error", "")

        fix = await self.think(
            f"""Debug and fix this Python code:

ERROR: {error}

CODE:
{code}

Identify the bug and provide the corrected code with explanation."""
        )

        return AgentResult.ok({"fix": fix})

    async def _propose_improvement(self, context: TaskContext) -> AgentResult:
        target = context.goal
        proposal = await self.think_json(
            f"""Propose a specific, measurable improvement for:
{target}

Return JSON:
{{
  "title": "improvement title",
  "description": "what to change and why",
  "expected_improvement_pct": 15,
  "implementation": "step by step how to implement",
  "risks": ["risk1"],
  "effort": "low|medium|high"
}}"""
        )
        return AgentResult.ok(proposal)

    async def _handle_step(self, context: TaskContext) -> AgentResult:
        """Handle a generic development step."""
        response = await self.think(
            f"""Complete this development task:
{context.goal}

Additional context: {context.payload}

Provide a complete, working solution with explanation."""
        )
        return AgentResult.ok({"response": response})


# ─── Testing Agent ────────────────────────────────────────────────────────────

class TestingAgent(BaseAgent):
    """
    Writes and executes unit tests, verifies code reliability, and generates coverage reports.
    """

    def __init__(self) -> None:
        super().__init__(
            agent_id="testing",
            name="Testing Agent",
            capabilities=["unit_testing", "code_verification", "load_testing", "coverage"],
            allowed_tools=["code_executor", "file_manager"],
        )
        self._tool_engine = None

    async def on_start(self) -> None:
        from tools import get_tool_engine
        self._tool_engine = get_tool_engine()

    async def handle_task(self, task_type: str, context: TaskContext) -> AgentResult:
        handlers = {
            "write_tests": self._write_tests,
            "run_tests": self._run_tests,
            "verify_code": self._verify_code,
            "execute_step": self._verify_code,
        }
        handler = handlers.get(task_type, self._verify_code)
        return await handler(context)

    async def _write_tests(self, context: TaskContext) -> AgentResult:
        code = context.payload.get("code", "")
        function_name = context.payload.get("function_name", "")

        tests = await self.think(
            f"""Write comprehensive pytest unit tests for:

CODE TO TEST:
{code}

Requirements:
- Test happy path
- Test edge cases
- Test error conditions
- Use pytest fixtures
- Include type hints
- Aim for >80% coverage

Write complete, runnable test code."""
        )

        return AgentResult.ok({"tests": tests, "function_name": function_name})

    async def _run_tests(self, context: TaskContext) -> AgentResult:
        test_code = context.payload.get("test_code", "")

        if not self._tool_engine:
            return AgentResult.fail("Code executor not available")

        result = await self._tool_engine.execute(
            tool_name="code_executor",
            agent_id=self.agent_id,
            params={"code": test_code, "language": "python"},
        )

        return AgentResult.ok({
            "passed": result.success,
            "stdout": result.data.get("stdout", "") if result.success else "",
            "stderr": result.data.get("stderr", "") if result.success else result.error,
        })

    async def _verify_code(self, context: TaskContext) -> AgentResult:
        code = context.payload.get("code", context.goal)
        verification = await self.think_json(
            f"""Analyze this code for correctness and quality:

{code}

Return JSON:
{{
  "syntax_valid": true,
  "logic_issues": [],
  "security_concerns": [],
  "performance_issues": [],
  "quality_score": 0.85,
  "recommendations": []
}}"""
        )
        return AgentResult.ok(verification)


# ─── Critic Agent ─────────────────────────────────────────────────────────────

class CriticAgent(BaseAgent):
    """
    Evaluates agent outputs for quality, correctness, and completeness.
    Provides scored assessments and actionable feedback.
    """

    def __init__(self) -> None:
        super().__init__(
            agent_id="critic",
            name="Critic Agent",
            capabilities=["quality_evaluation", "logic_verification", "security_review", "scoring"],
        )

    async def handle_task(self, task_type: str, context: TaskContext) -> AgentResult:
        handlers = {
            "evaluate": self._evaluate,
            "score_code": self._score_code,
            "validate_plan": self._validate_plan,
            "execute_step": self._evaluate,
        }
        handler = handlers.get(task_type, self._evaluate)
        return await handler(context)

    async def _evaluate(self, context: TaskContext) -> AgentResult:
        """Evaluate an agent output."""
        goal = context.payload.get("goal", context.goal)
        answer = context.payload.get("answer", "")

        evaluation = await self.think_json(
            f"""Critically evaluate this output:

ORIGINAL GOAL: {goal}

OUTPUT TO EVALUATE:
{answer}

Provide a rigorous, honest evaluation. Return JSON:
{{
  "score": 0.85,
  "correctness": 0.9,
  "completeness": 0.8,
  "clarity": 0.85,
  "safety": 1.0,
  "strengths": ["strength1", "strength2"],
  "weaknesses": ["weakness1"],
  "critical_issues": [],
  "suggestions": ["suggestion1"],
  "verdict": "accept|revise|reject"
}}"""
        )

        self.logger.info(
            "evaluation_complete",
            score=evaluation.get("score"),
            verdict=evaluation.get("verdict"),
        )

        return AgentResult.ok(evaluation)

    async def _score_code(self, context: TaskContext) -> AgentResult:
        code = context.payload.get("code", "")
        score = await self.think_json(
            f"""Score this Python code:

{code}

Return JSON:
{{
  "overall_score": 0.8,
  "readability": 0.9,
  "correctness": 0.85,
  "security": 0.9,
  "performance": 0.75,
  "test_coverage_estimate": 0.0,
  "issues": [],
  "passes_production_standards": true
}}"""
        )
        return AgentResult.ok(score)

    async def _validate_plan(self, context: TaskContext) -> AgentResult:
        plan = context.payload.get("plan", {})
        validation = await self.think_json(
            f"""Validate this execution plan:

{json.dumps(plan, indent=2)}

Return JSON:
{{
  "is_valid": true,
  "missing_dependencies": [],
  "circular_dependencies": [],
  "unreachable_steps": [],
  "agent_availability_issues": [],
  "estimated_success_probability": 0.85,
  "recommendations": []
}}"""
        )
        return AgentResult.ok(validation)
