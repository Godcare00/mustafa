"""
MUSTAFA OS - Web Search Tool
DuckDuckGo-powered web search with result parsing.
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional

from tools.base import BaseTool, ToolResult


class WebSearchTool(BaseTool):
    """Search the web using DuckDuckGo."""

    name = "web_search"
    description = "Search the web for information using DuckDuckGo"
    permissions = ["network.read"]
    timeout = 30

    async def execute(self, params: Dict[str, Any]) -> ToolResult:
        query = params.get("query", "")
        max_results = int(params.get("max_results", 5))

        if not query:
            return ToolResult(success=False, error="query parameter required")

        try:
            from duckduckgo_search import DDGS
            results = []
            with DDGS() as ddgs:
                for r in ddgs.text(query, max_results=max_results):
                    results.append({
                        "title": r.get("title", ""),
                        "url": r.get("href", ""),
                        "snippet": r.get("body", ""),
                    })

            return ToolResult(success=True, data={"results": results, "query": query})

        except ImportError:
            return ToolResult(
                success=False,
                error="duckduckgo_search package not installed. Run: pip install duckduckgo-search",
            )
        except Exception as e:
            return ToolResult(success=False, error=f"Search failed: {e}")

    async def validate_params(self, params: Dict[str, Any]) -> Optional[str]:
        if not params.get("query"):
            return "query is required"
        return None
