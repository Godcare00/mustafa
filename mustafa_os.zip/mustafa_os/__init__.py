# MUSTAFA OS
__version__ = "1.0.0"
__author__ = "MUSTAFA OS"
