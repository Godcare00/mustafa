"""
MUSTAFA OS - FastAPI Application
REST API interface for MUSTAFA OS with async request handling,
health endpoints, task management, and streaming responses.
"""
from __future__ import annotations

import time
import uuid
from contextlib import asynccontextmanager
from typing import Any, AsyncGenerator, Dict, List, Optional

from fastapi import FastAPI, HTTPException, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from pydantic import BaseModel, Field

from core.database import get_db
from core.kernel import get_kernel
from core.logger import get_logger

logger = get_logger("api")


# ─── Pydantic Models ──────────────────────────────────────────────────────────

class ProcessRequest(BaseModel):
    goal: str = Field(..., description="The task or goal to accomplish", min_length=1)
    session_id: Optional[str] = Field(None, description="Session ID for conversation continuity")
    context: Optional[Dict[str, Any]] = Field(None, description="Additional context")
    task_id: Optional[str] = Field(None, description="Custom task ID")


class ProcessResponse(BaseModel):
    status: str
    task_id: Optional[str] = None
    result: Optional[Any] = None
    message: Optional[str] = None
    error: Optional[str] = None
    iterations: Optional[int] = None
    steps_taken: Optional[List] = None
    alternatives: Optional[List] = None
    processing_time_ms: Optional[float] = None


class HealthResponse(BaseModel):
    overall: str
    checks: Dict[str, Any]
    uptime_seconds: float


class StatusResponse(BaseModel):
    status: str
    uptime_seconds: float
    requests_processed: int
    agents: List[Dict]
    tools_count: int
    redis_connected: bool


class TaskListResponse(BaseModel):
    tasks: List[Dict]
    total: int


class ToolListResponse(BaseModel):
    tools: List[Dict]
    total: int


# ─── App Lifecycle ────────────────────────────────────────────────────────────

@asynccontextmanager
async def lifespan(app: FastAPI) -> AsyncGenerator:
    """Boot on startup, shutdown gracefully."""
    kernel = get_kernel()
    try:
        await kernel.boot()
        logger.info("FastAPI server started")
        yield
    finally:
        await kernel.shutdown()
        logger.info("FastAPI server stopped")


# ─── App Initialization ────────────────────────────────────────────────────────

app = FastAPI(
    title="MUSTAFA OS",
    description="Modular Unified System for Task Automation and Autonomous Intelligence",
    version="1.0.0",
    lifespan=lifespan,
    docs_url="/docs",
    redoc_url="/redoc",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# ─── Middleware ───────────────────────────────────────────────────────────────

@app.middleware("http")
async def log_requests(request: Request, call_next: Any) -> Any:
    """Log all API requests with timing."""
    start = time.monotonic()
    trace_id = str(uuid.uuid4())[:8]
    logger.info(
        "API request",
        method=request.method,
        path=request.url.path,
        trace_id=trace_id,
    )
    response = await call_next(request)
    duration_ms = (time.monotonic() - start) * 1000
    logger.info(
        "API response",
        method=request.method,
        path=request.url.path,
        status=response.status_code,
        duration_ms=round(duration_ms, 1),
        trace_id=trace_id,
    )
    return response


# ─── Endpoints ────────────────────────────────────────────────────────────────

@app.get("/", tags=["system"])
async def root() -> Dict:
    """MUSTAFA OS root endpoint."""
    return {
        "system": "MUSTAFA OS",
        "version": "1.0.0",
        "description": "Modular Unified System for Task Automation and Autonomous Intelligence",
        "docs": "/docs",
        "health": "/health",
        "status": "/status",
    }


@app.get("/health", response_model=HealthResponse, tags=["system"])
async def health_check() -> Dict:
    """System health check."""
    kernel = get_kernel()
    return await kernel.health_check()


@app.get("/status", response_model=StatusResponse, tags=["system"])
async def system_status() -> Dict:
    """Full system status including agents, tools, and metrics."""
    kernel = get_kernel()
    return await kernel.get_status()


@app.post("/process", tags=["core"])
async def process_goal(request: ProcessRequest) -> JSONResponse:
    """
    Process a goal through the MUSTAFA OS orchestrator.
    This is the primary endpoint — send any task here.
    """
    kernel = get_kernel()
    start = time.monotonic()

    result = await kernel.process(
        goal=request.goal,
        session_id=request.session_id,
        context=request.context,
        task_id=request.task_id,
    )

    processing_time_ms = (time.monotonic() - start) * 1000
    if isinstance(result, dict):
        result["processing_time_ms"] = round(processing_time_ms, 1)

    return JSONResponse(content=result)


@app.get("/tasks", response_model=TaskListResponse, tags=["tasks"])
async def list_tasks(
    status: Optional[str] = None,
    limit: int = 50,
    offset: int = 0,
) -> Dict:
    """List all tasks with optional status filter."""
    db = await get_db()
    tasks = await db.list_tasks(status=status, limit=limit, offset=offset)
    return {"tasks": tasks, "total": len(tasks)}


@app.get("/tasks/{task_id}", tags=["tasks"])
async def get_task(task_id: str) -> Dict:
    """Get a specific task by ID."""
    db = await get_db()
    task = await db.get_task(task_id)
    if not task:
        raise HTTPException(status_code=404, detail=f"Task {task_id} not found")
    return task


@app.get("/agents", tags=["agents"])
async def list_agents() -> Dict:
    """List all registered agents and their status."""
    kernel = get_kernel()
    if not kernel._registry:
        raise HTTPException(status_code=503, detail="System not initialized")
    agents = kernel._registry.list_agents()
    return {"agents": agents, "total": len(agents)}


@app.get("/tools", response_model=ToolListResponse, tags=["tools"])
async def list_tools(category: Optional[str] = None) -> Dict:
    """List all registered tools."""
    from core.tool_engine import get_tool_engine
    engine = get_tool_engine()
    tools = await engine.list_all_tools()
    if category:
        tools = [t for t in tools if t.get("category") == category]
    return {"tools": tools, "total": len(tools)}


class ToolExecuteRequest(BaseModel):
    tool_name: str = Field(..., description="Name of the tool to execute")
    params: Dict[str, Any] = Field(default_factory=dict, description="Tool input parameters")


@app.post("/tools/execute", tags=["tools"])
async def execute_tool(request: ToolExecuteRequest) -> Dict:
    """Execute a specific tool directly."""
    from core.tool_engine import get_tool_engine
    engine = get_tool_engine()
    result = await engine.execute(tool_name=request.tool_name, params=request.params)
    return result.to_dict()


@app.post("/memory/search", tags=["memory"])
async def search_memory(query: str, top_k: int = 5, memory_type: Optional[str] = None) -> Dict:
    """Search long-term memory using semantic search."""
    from memory.memory_system import get_memory_system
    memory = get_memory_system()
    memories = await memory.recall(query=query, top_k=top_k, memory_type=memory_type)
    return {
        "query": query,
        "results": [
            {
                "id": m.id,
                "content": m.content,
                "type": m.memory_type,
                "relevance": m.relevance_score,
            }
            for m in memories
        ],
        "total": len(memories),
    }


@app.post("/memory/store", tags=["memory"])
async def store_memory(
    content: str,
    memory_type: str = "knowledge",
    metadata: Optional[Dict] = None,
) -> Dict:
    """Store content in long-term memory."""
    from memory.memory_system import get_memory_system
    memory = get_memory_system()
    memory_id = await memory.remember(
        content=content,
        memory_type=memory_type,
        metadata=metadata,
    )
    return {"memory_id": memory_id, "success": True}


@app.get("/metrics", tags=["monitoring"])
async def get_metrics(metric_name: Optional[str] = None, window_seconds: int = 3600) -> Dict:
    """Get system metrics."""
    db = await get_db()
    if metric_name:
        summary = await db.get_metrics_summary(metric_name, window_seconds)
        return {"metric": metric_name, "summary": summary, "window_seconds": window_seconds}
    return {"message": "Specify metric_name parameter for detailed metrics"}


@app.get("/events", tags=["monitoring"])
async def get_events(limit: int = 50) -> Dict:
    """Get recent system events."""
    db = await get_db()
    async with db._cursor() as cur:
        await cur.execute(
            "SELECT * FROM system_events ORDER BY occurred_at DESC LIMIT ?", (limit,)
        )
        rows = await cur.fetchall()
        events = [dict(r) for r in rows]
    return {"events": events, "total": len(events)}


# ─── Exception Handlers ────────────────────────────────────────────────────────

@app.exception_handler(Exception)
async def global_exception_handler(request: Request, exc: Exception) -> JSONResponse:
    """Global exception handler — system never crashes."""
    logger.error(
        "Unhandled exception",
        path=request.url.path,
        error=str(exc),
        error_type=type(exc).__name__,
    )
    return JSONResponse(
        status_code=500,
        content={
            "status": "error",
            "error": "Internal server error",
            "detail": str(exc),
            "path": str(request.url.path),
        },
    )
