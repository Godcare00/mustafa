"""
MUSTAFA OS - Main Entry Point
Starts the full system: API server, agent kernel, and optional Telegram bot.
"""

from __future__ import annotations

import asyncio
import sys

import uvicorn

from core.logging_config import configure_logging
from core.settings import settings


async def run_system() -> None:
    """Boot kernel, start Telegram bot, then serve the API (lifespan handles boot)."""
    configure_logging(settings.log_level, settings.log_format)

    from telegram_bot.bot import telegram_bot

    # Boot the kernel first so Telegram bot can reference it
    from core.kernel import kernel
    await kernel.boot()

    # Start Telegram bot if configured
    await telegram_bot.start(kernel)

    # Start FastAPI — lifespan will see kernel already running and skip re-boot
    config = uvicorn.Config(
        "api.app:app",
        host=settings.api_host,
        port=settings.api_port,
        log_level=settings.log_level.lower(),
        access_log=not settings.is_production,
    )
    server = uvicorn.Server(config)

    try:
        await server.serve()
    finally:
        await telegram_bot.stop()
        if kernel.is_running:
            await kernel.shutdown()


def main() -> None:
    """Main entry point."""
    # Handle CLI sub-commands
    if len(sys.argv) > 1:
        cmd = sys.argv[1]

        if cmd == "chat":
            # Interactive CLI
            from cli.interface import MustafaOSCLI
            interface = MustafaOSCLI()
            asyncio.run(interface.start())

        elif cmd == "server":
            # API server only (no CLI)
            from api.app import app
            uvicorn.run(
                app,
                host=settings.api_host,
                port=settings.api_port,
                log_level=settings.log_level.lower(),
            )

        elif cmd == "run" and len(sys.argv) > 2:
            # Single goal execution
            goal = " ".join(sys.argv[2:])
            from cli.interface import cli
            sys.argv = ["mustafa", "run", goal]
            cli()

        elif cmd == "worker":
            # Celery worker
            from orchestration.celery_app import celery_app
            celery_app.worker_main(["worker", "--loglevel=info"])

        else:
            print(f"Unknown command: {cmd}")
            print("Usage: python main.py [chat|server|run <goal>|worker]")
            sys.exit(1)
    else:
        # Default: start full system (API + kernel + bots)
        asyncio.run(run_system())


if __name__ == "__main__":
    main()
